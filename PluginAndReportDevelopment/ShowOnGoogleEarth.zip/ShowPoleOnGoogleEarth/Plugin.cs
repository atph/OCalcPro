﻿using System;
using System.Collections.Generic;
using System.Text;
using PPL_Lib;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.IO.Compression;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Media.Media3D;
using Microsoft.Win32;

namespace OCalcProPlugin
{
    public class Plugin : PPLPluginInterface
    {

        #region HOUSEKEEPING
        PPL_Lib.PPLMain cPPLMain = null;
        public PLUGIN_TYPE Type
        {
            get
            {
                return PLUGIN_TYPE.MENU_ITEM;
            }
        }
        public String Name
        {
            get
            {
                return "Show on Google Earth";
            }
        }
        public String Description
        {
            get
            {
                return "Show on Google Earth";
            }
        }
        public void AddForm(PPL_Lib.PPLMain pPPLMain)
        {
            throw new NotImplementedException("Show on Google Earth is not a docked plugin.");
        }


        ToolStripMenuItem cShowOnGoogleEarthButton = null;
        ToolStripMenuItem cShowMarkerButton = null;
        ToolStripMenuItem cRenderStructureButton = null;
        ToolStripMenuItem cCreateIndexeButton = null;
        ToolStripMenuItem cHelpButton = null;

        public void AddToMenu(PPL_Lib.PPLMain pPPLMain, System.Windows.Forms.ToolStrip pToolStrip)
        {
            cPPLMain = pPPLMain;
            cShowOnGoogleEarthButton = new ToolStripMenuItem("Show on Google Earth");
            int itemindex = 0;
            System.Diagnostics.Debug.Assert(pToolStrip.Items[itemindex] is ToolStripDropDownButton);
            if (pToolStrip.Items[itemindex] is ToolStripDropDownButton)
            {
                ToolStripDropDownButton tsb = pToolStrip.Items[itemindex] as ToolStripDropDownButton;
                System.Diagnostics.Debug.Assert(tsb.Text == "&File");
                tsb.DropDownItems.Insert(tsb.DropDownItems.Count - 1, cShowOnGoogleEarthButton);
                tsb.DropDownItems.Insert(tsb.DropDownItems.Count - 1, new ToolStripSeparator());
                tsb.DropDownOpened += tsb_DropDownOpened;
            }
            cShowMarkerButton = new ToolStripMenuItem("Show Marker");
            cRenderStructureButton = new ToolStripMenuItem("Render Structure");
            cCreateIndexeButton = new ToolStripMenuItem("Batch Create Index");
            cHelpButton = new ToolStripMenuItem("Help");
            cShowOnGoogleEarthButton.DropDownItems.Add(cShowMarkerButton);
            cShowMarkerButton.Click += cShowMarkerButton_Click;
            cShowOnGoogleEarthButton.DropDownItems.Add(cRenderStructureButton);
            cRenderStructureButton.Click += cRenderStructureButton_Click;
            cShowOnGoogleEarthButton.DropDownItems.Add(new ToolStripSeparator());
            cShowOnGoogleEarthButton.DropDownItems.Add(cCreateIndexeButton);
            cCreateIndexeButton.Click += cCreateIndexeButton_Click;
            cShowOnGoogleEarthButton.DropDownItems.Add(cHelpButton);
            cHelpButton.Click += cHelpButton_Click;
        }

        void cHelpButton_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("This plugin requires that Google Earth Pro be installed.");
            sb.AppendLine();
            sb.AppendLine("In Google Earth Pro set the following options:");
            sb.AppendLine("  General:");
            sb.AppendLine("    Show web results in external browser (on)");
            sb.AppendLine("    Allow access to local files (on)");
            PPLMessageBox.Show(sb.ToString(), "Show on Google Earth");
        }

        void tsb_DropDownOpened(object sender, EventArgs e)
        {
            bool enabled = false;
            if (cPPLMain != null)
            {
                enabled = (cPPLMain.GetMainStructure() is PPLPole);
            }
            cShowOnGoogleEarthButton.Enabled = true;
            cHelpButton.Enabled = true;
            cShowMarkerButton.Enabled = enabled;
            cRenderStructureButton.Enabled = enabled;
            cCreateIndexeButton.Enabled = !enabled;
        }

        public PPLClearance.ClearanceSagProvider GetClearanceSagProvider(PPL_Lib.PPLMain pMain)
        {
            System.Diagnostics.Debug.Assert(false, "Show on Google Earth is not a clearance provider plugin.");
            return null;
        }
        #endregion


        void cRenderStructureButton_Click(object sender, EventArgs e)
        {
            ExportToCollada();
        }

        void cShowMarkerButton_Click(object sender, EventArgs e)
        {
            ShowLocation();
        }

        void cCreateIndexeButton_Click(object sender, EventArgs e)
        {
            CreateIndex();
        }

        private class Mesh
        {
            public int cMeshID = 0;
            public System.Drawing.Color cColor = System.Drawing.Color.Blue;
            public List<Point3D> cPoints = new List<Point3D>();
            public List<int> cTrangles = new List<int>();
        }
        private List<Mesh> cMeshes = null;

        private String Token(String pKey, Mesh pMesh)
        {
            return pKey + pMesh.cMeshID.ToString();
        }

        public string MakeLegalFileName(string pstrSource)
        {
            pstrSource = pstrSource.Trim();

            char[] arr;
            arr = pstrSource.ToCharArray();
            for (int i = 0; i < pstrSource.Length; i++)
            {
                char c = arr[i];
                if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                   (c >= '0' && c <= '9') || (c == '$') || (c == '-') || (c == ' ')))
                {
                    arr[i] = '_';
                }
            }
            return new String(arr);
        }


        private void ExportToCollada()
        {
            try
            {
                String poleId = PPLMain.MakeLegalFileName(cPPLMain.GetMainStructure().GetValueAndConvertToString("Pole Number"));
                String path = System.IO.Path.GetTempPath() + MakeLegalFileName(poleId) + ".kmz";
                PPLMain.FileDelete(path);
                PPLGroundLine gl = cPPLMain.GetMainStructure().Parent as PPLGroundLine;
                if (gl.cPoleLocation.Latitude == 0 && gl.cPoleLocation.Longitude == 0)
                {
                    PPLMessageBox.Show("GeoCoordinates are not set for this structure.");
                    return;
                }

                using (FileStream zipToOpen = new FileStream(path, FileMode.CreateNew))
                {
                    using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Update))
                    {

                        ZipArchiveEntry kmlEntry = archive.CreateEntry("doc.kml");
                        using (StreamWriter sw = new StreamWriter(kmlEntry.Open()))
                        {
                            sw.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                            sw.WriteLine("<kml xmlns=\"http://earth.google.com/kml/2.0\">");
                            sw.WriteLine("  <Document>");
                            sw.WriteLine("  <Placemark>");
                            sw.WriteLine("   <name>" + poleId + "</name>");
                            sw.WriteLine("   <LookAt>");
                            sw.WriteLine("     <longitude>" + gl.cPoleLocation.Longitude.ToString() + "</longitude>");
                            sw.WriteLine("     <latitude>" + gl.cPoleLocation.Latitude.ToString() + "</latitude>");
                            sw.WriteLine("     <altitude>0</altitude>");
                            sw.WriteLine("     <heading>0</heading>");
                            sw.WriteLine("     <tilt>70</tilt>");
                            sw.WriteLine("     <range>60</range>");
                            sw.WriteLine("   </LookAt>");
                            sw.WriteLine("   <Model id=\"model_1\">");
                            sw.WriteLine("   	<Location>");
                            sw.WriteLine("          <longitude>" + (gl.cPoleLocation.Longitude).ToString() + "</longitude>");
                            sw.WriteLine("          <latitude>" + (gl.cPoleLocation.Latitude).ToString() + "</latitude>");
                            sw.WriteLine("   		<altitude>0</altitude>");
                            sw.WriteLine("   	</Location>");
                            sw.WriteLine("   	<Link>");
                            sw.WriteLine("   		<href>files/TempPole.dae</href>");
                            sw.WriteLine("   	</Link>");
                            sw.WriteLine("   </Model>");
                            sw.WriteLine("  </Placemark>");
                            sw.WriteLine(" </Document>");
                            sw.WriteLine("</kml>");
                        }
                        String shellPath = path;


                        ZipArchiveEntry daeEntry = archive.CreateEntry("files/TempPole.dae");
                        using (StreamWriter sw = new StreamWriter(daeEntry.Open()))
                        {
                            PPLElement elem = cPPLMain.GetMainStructure();
                            cMeshes = new List<Mesh>();
                            BuildMesh(elem);
                            BoundingMeshes();

                            int midx = 1;
                            foreach (Mesh mesh in cMeshes)
                            {
                                mesh.cMeshID = midx;
                                midx++;
                            }

                            //setup
                            sw.WriteLine(@"<?xml version='1.0' encoding='utf-8'?>");
                            sw.WriteLine(@"<COLLADA xmlns='http://www.collada.org/2005/11/COLLADASchema' version='1.4.1'>");
                            sw.WriteLine(@"<asset>");
                            sw.WriteLine(@"  <contributor>");
                            sw.WriteLine(@"    <authoring_tool>OCalcPro</authoring_tool>");
                            sw.WriteLine(@"  </contributor>");
                            sw.WriteLine(@"  <unit name='inches' meter='0.0254'/>");
                            sw.WriteLine(@"  <up_axis>Y_UP</up_axis>");
                            sw.WriteLine(@"</asset>");

                            //materials
                            sw.WriteLine(@"<library_materials>");
                            foreach (Mesh mesh in cMeshes)
                            {

                                sw.WriteLine(@"  <material id='" + Token("Material", mesh) + "' name='" + Token("Material", mesh) + "'>");
                                sw.WriteLine(@"    <instance_effect url='#" + Token("Effect", mesh) + "' />");
                                sw.WriteLine(@"  </material>");
                            }
                            sw.WriteLine(@"</library_materials>");

                            //effects
                            sw.WriteLine(@"<library_effects>");
                            foreach (Mesh mesh in cMeshes)
                            {
                                sw.WriteLine(@"<effect id='" + Token("Effect", mesh) + "'>");
                                sw.WriteLine(@"    <profile_COMMON>");
                                sw.WriteLine(@"    <technique sid='COMMON'>");
                                sw.WriteLine(@"        <lambert>");
                                sw.WriteLine(@"        <diffuse>");
                                sw.Write(@"            <color>");
                                sw.Write((((double)mesh.cColor.R) / 255.0).ToString());
                                sw.Write(" ");
                                sw.Write((((double)mesh.cColor.G) / 255.0).ToString());
                                sw.Write(" ");
                                sw.Write((((double)mesh.cColor.B) / 255.0).ToString());
                                sw.Write(" ");
                                sw.Write((((double)mesh.cColor.A) / 255.0).ToString());
                                sw.WriteLine(@"</color>");
                                sw.WriteLine(@"        </diffuse>");
                                sw.WriteLine(@"        </lambert>");
                                sw.WriteLine(@"    </technique>");
                                sw.WriteLine(@"    <extra>");
                                sw.WriteLine(@"        <technique profile='GOOGLEEARTH'>");
                                sw.WriteLine(@"        <double_sided>1</double_sided>");
                                sw.WriteLine(@"        </technique>");
                                sw.WriteLine(@"    </extra>");
                                sw.WriteLine(@"    </profile_COMMON>");
                                sw.WriteLine(@"</effect>");
                            }
                            sw.WriteLine(@"</library_effects>");

                            //geometries
                            sw.WriteLine(@"<library_geometries>");
                            foreach (Mesh mesh in cMeshes)
                            {


                                sw.WriteLine(@"    <geometry id='" + Token("Geometry", mesh) + "'>");
                                sw.WriteLine(@"      <mesh>");
                                sw.WriteLine(@"        <source id='" + Token("VSource", mesh) + "'>");
                                sw.Write(@"          <float_array id='" + Token("VData", mesh) + "' count='" + (mesh.cPoints.Count * 3).ToString() + "'>");
                                foreach (Point3D pt in mesh.cPoints)
                                {
                                    sw.Write((-(pt.X)).ToString());
                                    sw.Write(" ");
                                    sw.Write(pt.Y.ToString());
                                    sw.Write(" ");
                                    sw.Write((-(pt.Z)).ToString());
                                    sw.Write("  ");
                                }
                                sw.WriteLine(@"</float_array>");
                                sw.WriteLine(@"          <technique_common>");
                                sw.WriteLine(@"            <accessor count='4' source='#" + Token("VData", mesh) + "' stride='3'>");
                                sw.WriteLine(@"              <param name='X' type='float' />");
                                sw.WriteLine(@"              <param name='Y' type='float' />");
                                sw.WriteLine(@"              <param name='Z' type='float' />");
                                sw.WriteLine(@"            </accessor>");
                                sw.WriteLine(@"          </technique_common>");
                                sw.WriteLine(@"        </source>");
                                sw.WriteLine(@"        <vertices id='" + Token("Vertices", mesh) + "'>");
                                sw.WriteLine(@"          <input semantic='POSITION' source='#" + Token("VSource", mesh) + "' />");
                                sw.WriteLine(@"        </vertices>");
                                sw.WriteLine(@"        <triangles count='" + (mesh.cTrangles.Count / 3).ToString() + @"' material='" + Token("Material", mesh) + "'>");
                                sw.WriteLine(@"          <input offset='0' semantic='VERTEX' source='#" + Token("Vertices", mesh) + "' />");
                                sw.Write(@"          <p>");
                                foreach (int idx in mesh.cTrangles)
                                {
                                    sw.Write(idx.ToString());
                                    sw.Write(" ");
                                }
                                sw.WriteLine(@"</p>");
                                sw.WriteLine(@"        </triangles>");
                                sw.WriteLine(@"      </mesh>");
                                sw.WriteLine(@"    </geometry>");
                            }
                            sw.WriteLine(@"</library_geometries>");


                            //scene
                            sw.WriteLine(@"<library_visual_scenes>");
                            sw.WriteLine(@"  <visual_scene id='OCalcProScene' name='OCalcProScene'>");
                            sw.WriteLine(@"    <node id='OCalcProModel' name='OCalcProModel'>");

                            foreach (Mesh mesh in cMeshes)
                            {
                                sw.WriteLine(@"        <instance_geometry url='#" + Token("Geometry", mesh) + "'>");
                                sw.WriteLine(@"          <bind_material>");
                                sw.WriteLine(@"            <technique_common>");
                                sw.WriteLine(@"              <instance_material symbol='" + Token("Material", mesh) + "' target='#" + Token("Material", mesh) + "'>");
                                sw.WriteLine(@"                <bind_vertex_input semantic='UVSET0' input_semantic='TEXCOORD' input_set='0' />");
                                sw.WriteLine(@"              </instance_material>");
                                sw.WriteLine(@"            </technique_common>");
                                sw.WriteLine(@"          </bind_material>");
                                sw.WriteLine(@"        </instance_geometry>");
                            }

                            sw.WriteLine(@"    </node>");
                            sw.WriteLine(@"  </visual_scene>");
                            sw.WriteLine(@"</library_visual_scenes>");

                            //final total scene
                            sw.WriteLine(@"<scene>");
                            sw.WriteLine(@"  <instance_visual_scene url='#OCalcProScene'/>");
                            sw.WriteLine(@"</scene>");
                            sw.WriteLine(@"</COLLADA>");

                            cMeshes.Clear();
                            cMeshes = null;
                        }
                    }
                }

                var psi = new System.Diagnostics.ProcessStartInfo();
                psi.UseShellExecute = true;
                psi.FileName = path;
                System.Diagnostics.Process.Start(psi);
            }
            catch { }
        }

        private void BoundingMeshes()
        {
            double rangeX = 0;
            double rangeZ = 0;
            foreach (Mesh mesh in cMeshes)
            {
                foreach (Point3D pt in mesh.cPoints)
                {
                    rangeX = Math.Max(Math.Abs(pt.X), rangeX);
                    rangeZ = Math.Max(Math.Abs(pt.Z), rangeZ);
                }
            }

            Mesh result = new Mesh();
            //add corner markers to make it center on the pole
            for (int xi = -1; xi <= 1; xi += 2)
            {
                for (int zi = -1; zi <= 1; zi += 2)
                {
                    result.cTrangles.Add(result.cPoints.Count);
                    result.cPoints.Add(new Point3D((xi * rangeX) - 1, 0, zi * rangeZ));
                    result.cTrangles.Add(result.cPoints.Count);
                    result.cPoints.Add(new Point3D((xi * rangeX), 0, zi * rangeZ));
                    result.cTrangles.Add(result.cPoints.Count);
                    result.cPoints.Add(new Point3D(xi * rangeX, 0, (zi * rangeZ) + 1));
                }
            }
            cMeshes.Add(result);
        }

        private void BuildMesh(PPLElement pElem)
        {
            if (pElem.DisplayedGeometries.Count > 0)
            {
                foreach (GeometryModel3D gm in pElem.DisplayedGeometries)
                {
                    if (gm.Geometry is MeshGeometry3D)
                    {
                        Mesh mesh = new Mesh();
                        cMeshes.Add(mesh);
                        MeshGeometry3D m3d = (gm.Geometry as MeshGeometry3D);
                        System.Diagnostics.Debug.Assert(gm.Material is DiffuseMaterial);
                        if (gm.Material is DiffuseMaterial)
                        {
                            DiffuseMaterial dm = gm.Material as DiffuseMaterial;
                            System.Windows.Media.SolidColorBrush sb = dm.Brush as System.Windows.Media.SolidColorBrush;
                            mesh.cColor = System.Drawing.Color.FromArgb(sb.Color.R, sb.Color.G, sb.Color.B);
                        }
                        foreach (Point3D pt in m3d.Positions)
                        {
                            mesh.cPoints.Add(pt);
                        }
                        foreach (int tidx in m3d.TriangleIndices)
                        {
                            mesh.cTrangles.Add(tidx);
                        }
                    }
                }
            }
            foreach (PPLElement elem in pElem.Children)
            {
                BuildMesh(elem);
            }
        }

        private void ShowLocation()
        {
            try
            {
                String poleId = PPLMain.MakeLegalFileName(cPPLMain.GetMainStructure().GetValueAndConvertToString("Pole Number"));
                String path = System.IO.Path.GetTempPath() + MakeLegalFileName(poleId) + ".kml";
                PPLMain.FileDelete(path);
                PPLGroundLine gl = cPPLMain.GetMainStructure().Parent as PPLGroundLine;

                if (gl.cPoleLocation.Latitude == 0 && gl.cPoleLocation.Longitude == 0)
                {
                    PPLMessageBox.Show("GeoCoordinates are not set for this structure.");
                    return;
                }

                using (StreamWriter sw = new StreamWriter(path))
                {
                    sw.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                    sw.WriteLine("<kml xmlns=\"http://earth.google.com/kml/2.0\">");
                    sw.WriteLine("  <Document>");
                    sw.WriteLine("  <Placemark>");
                    sw.WriteLine("   <name>" + poleId + "</name>");
                    sw.WriteLine("   <Point>");
                    sw.WriteLine("     <coordinates>" + gl.cPoleLocation.Longitude.ToString() + "," +
                                                        gl.cPoleLocation.Latitude.ToString() + "," +
                                                        gl.cPoleLocation.Elevation.ToString() + "</coordinates>");
                    sw.WriteLine("   </Point>");
                    sw.WriteLine("   <description>");
                    sw.Write("     <![CDATA[<a href=\"file:///");
                    sw.Write(cPPLMain.LoadedPolePath.Replace(" ", "%20").Replace("\\", "/").Trim());
                    sw.WriteLine("\">O-Calc Pro</a>]]>");
                    sw.WriteLine("   </description>");
                    sw.WriteLine("  </Placemark>");
                    sw.WriteLine(" </Document>");
                    sw.WriteLine("</kml>");
                }

                var psi = new System.Diagnostics.ProcessStartInfo();
                psi.UseShellExecute = true;
                psi.FileName = path;
                System.Diagnostics.Process.Start(psi);

            }
            catch { }
        }

        private void CreateIndex()
        {

            using (FolderBrowserDialog fd = new FolderBrowserDialog())
            {
                String reg = PPLMain.cRegistryBase + @"KmlIndex";
                String var = "Last";
                RegistryKey key = Registry.CurrentUser.OpenSubKey(reg);
                if (key == null)
                {
                    key = Registry.CurrentUser.CreateSubKey(reg);
                }
                fd.SelectedPath = key.GetValue(var, fd.SelectedPath).ToString();
                fd.Description = "Select Folder to Create Index of";
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    key = Registry.CurrentUser.CreateSubKey(reg);
                    if (key != null)
                    {
                        key.SetValue(var, fd.SelectedPath);
                    }
                    string directory = fd.SelectedPath;

                    System.Windows.Forms.SaveFileDialog ofd = new System.Windows.Forms.SaveFileDialog();
                    ofd.Filter = "KML file (.kml)|*.kml";
                    ofd.Title = "Output KML file";

                    var = "IndexFilePath";
                    key = Registry.CurrentUser.OpenSubKey(reg);
                    if (key == null)
                    {
                        key = Registry.CurrentUser.CreateSubKey(reg);
                    }

                    ofd.InitialDirectory = key.GetValue(var, Path.GetTempPath()).ToString();

                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        key = Registry.CurrentUser.CreateSubKey(reg);
                        String pr = System.IO.Path.GetDirectoryName(ofd.FileName);
                        key.SetValue(var, pr);
                        String path = ofd.FileName;
                        PPLMain.FileDelete(path);

                        try
                        {

                            String[] files = Directory.GetFiles(directory, "*.pplx");
                            using (PPL_Lib.PPLWorkingDialog working = new PPL_Lib.PPLWorkingDialog(false, cPPLMain))
                            {
                                working.textBox1.Text = "Creating Index";
                                working.TopMost = true;
                                working.progressBar1.Visible = true;
                                working.progressBar1.Maximum = files.Length + 1;
                                working.progressBar1.Value = 0;
                                working.Show();

                                using (StreamWriter sw = new StreamWriter(path))
                                {
                                    sw.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                                    sw.WriteLine("<kml xmlns=\"http://earth.google.com/kml/2.0\">");
                                    sw.WriteLine("  <Document>");

                                    foreach (String file in files)
                                    {

                                        working.progressBar1.Value++;
                                        working.progressBar1.Update();
                                        //load up the pole
                                        cPPLMain.LoadPoleFromFile(file, false, false);

                                        //Get the list of unique span angles and distances
                                        PPLPole pole = cPPLMain.GetPole();
                                        String poleId = PPLMain.MakeLegalFileName(cPPLMain.GetMainStructure().GetValueAndConvertToString("Pole Number"));
                                        working.textBox1.Text = poleId;
                                        working.textBox1.Update();
                                        PPLGroundLine gl = cPPLMain.GetMainStructure().Parent as PPLGroundLine;
                                        if (gl.cPoleLocation.Latitude != 0 && gl.cPoleLocation.Longitude != 0)
                                        {
                                            sw.WriteLine("  <Placemark>");
                                            sw.WriteLine("   <name>" + poleId + "</name>");
                                            sw.WriteLine("   <Point>");
                                            sw.WriteLine("     <coordinates>" + gl.cPoleLocation.Longitude.ToString() + "," +
                                                                                gl.cPoleLocation.Latitude.ToString() + "," +
                                                                                gl.cPoleLocation.Elevation.ToString() + "</coordinates>");
                                            sw.WriteLine("   </Point>");
                                            sw.WriteLine("   <description>");
                                            sw.Write("     <![CDATA[<a href=\"file:///");
                                            sw.Write(file.Replace(" ", "%20").Replace("\\", "/").Trim());
                                            sw.WriteLine("\">O-Calc Pro</a>]]>");
                                            sw.WriteLine("   </description>");
                                            sw.WriteLine("  </Placemark>");
                                        }

                                        //close pole
                                        cPPLMain.DoClosePole();

                                    }
                                    sw.WriteLine(" </Document>");
                                    sw.WriteLine("</kml>");
                                }
                            }

                            var psi = new System.Diagnostics.ProcessStartInfo();
                            psi.UseShellExecute = true;
                            psi.FileName = path;
                            System.Diagnostics.Process.Start(psi);

                        }
                        catch { }
                    }
                }
            }
        }
    }
}
