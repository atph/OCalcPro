//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: WoodPoleDamageOrDecay
// Mirrors: PPLWoodPoleDamageOrDecay : PPLElement
//--------------------------------------------------------------------------------------------
public class WoodPoleDamageOrDecay  extends ElementBase 
{
    public static String gXMLkey = "WoodPoleDamageOrDecay";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public WoodPoleDamageOrDecay(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Type = Type_val.Void;
            m_Description = "";
            m_Owner = "<Undefined>";
            m_WidthInInches = 1;
            m_HeightInInches = 1;
            m_DepthInInches = 1;
            m_ShellThicknessInInches = 4;
            m_ReducedCircumference = 1;
            m_EntryWidthInInches = 1;
            m_CoordinateZ = 120;
            m_CoordinateA = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Type of damage or decay
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Void
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Saw Cut  (Saw Cut)
        //        Mower Cut  (Mower Cut)
        //        Exposed Pocket  (Exposed Pocket)
        //        Enclosed Pocket  (Enclosed Pocket)
        //        Void  (Void)
        //        Heart Rot  (Heart Rot)
        //        Shell Reduction  (Shell Reduction)
        //        Woodpecker Hole  (Woodpecker Hole)
        //        Woodpecker Nest  (Woodpecker Nest)
        Vehicle_Scrape,
        //Vehicle Scrape
        Saw_Cut,
        //Saw Cut
        Mower_Cut,
        //Mower Cut
        Exposed_Pocket,
        //Exposed Pocket
        Enclosed_Pocket,
        //Enclosed Pocket
        Void,
        //Void
        Heart_Rot,
        //Heart Rot
        Shell_Reduction,
        //Shell Reduction
        Woodpecker_Hole,
        //Woodpecker Hole
        Woodpecker_Nest
    }
    //Woodpecker Nest
    private Type_val m_Type = Type_val.Vehicle_Scrape;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Vehicle Scrape"))
        {
            return Type_val.Vehicle_Scrape;
        }
        else //Vehicle Scrape
        if (__dummyScrutVar0.equals("Saw Cut"))
        {
            return Type_val.Saw_Cut;
        }
        else //Saw Cut
        if (__dummyScrutVar0.equals("Mower Cut"))
        {
            return Type_val.Mower_Cut;
        }
        else //Mower Cut
        if (__dummyScrutVar0.equals("Exposed Pocket"))
        {
            return Type_val.Exposed_Pocket;
        }
        else //Exposed Pocket
        if (__dummyScrutVar0.equals("Enclosed Pocket"))
        {
            return Type_val.Enclosed_Pocket;
        }
        else //Enclosed Pocket
        if (__dummyScrutVar0.equals("Void"))
        {
            return Type_val.Void;
        }
        else //Void
        if (__dummyScrutVar0.equals("Heart Rot"))
        {
            return Type_val.Heart_Rot;
        }
        else //Heart Rot
        if (__dummyScrutVar0.equals("Shell Reduction"))
        {
            return Type_val.Shell_Reduction;
        }
        else //Shell Reduction
        if (__dummyScrutVar0.equals("Woodpecker Hole"))
        {
            return Type_val.Woodpecker_Hole;
        }
        else //Woodpecker Hole
        if (__dummyScrutVar0.equals("Woodpecker Nest"))
        {
            return Type_val.Woodpecker_Nest;
        }
        else
        {
        }          
        throw new Exception("string does not match enum value");
    }

    //Woodpecker Nest
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Vehicle_Scrape: 
                return "Vehicle Scrape";
            case Saw_Cut: 
                return "Saw Cut";
            case Mower_Cut: 
                return "Mower Cut";
            case Exposed_Pocket: 
                return "Exposed Pocket";
            case Enclosed_Pocket: 
                return "Enclosed Pocket";
            case Void: 
                return "Void";
            case Heart_Rot: 
                return "Heart Rot";
            case Shell_Reduction: 
                return "Shell Reduction";
            case Woodpecker_Hole: 
                return "Woodpecker Hole";
            case Woodpecker_Nest: 
                return "Woodpecker Nest";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Vehicle Scrape
    //Saw Cut
    //Mower Cut
    //Exposed Pocket
    //Enclosed Pocket
    //Void
    //Heart Rot
    //Shell Reduction
    //Woodpecker Hole
    //Woodpecker Nest
    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Brief description of the damage
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   WidthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Width (in)
    //   Description:   The width in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WidthInInches;
    public double getWidthInInches() throws Exception {
        return m_WidthInInches;
    }

    public void setWidthInInches(double value) throws Exception {
        m_WidthInInches = value;
    }

    //   Attr Name:   HeightInInches
    //   Attr Group:Standard
    //   Alt Display Name:Height (in)
    //   Description:   The height in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HeightInInches;
    public double getHeightInInches() throws Exception {
        return m_HeightInInches;
    }

    public void setHeightInInches(double value) throws Exception {
        m_HeightInInches = value;
    }

    //   Attr Name:   DepthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Depth (in)
    //   Description:   The depth in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DepthInInches;
    public double getDepthInInches() throws Exception {
        return m_DepthInInches;
    }

    public void setDepthInInches(double value) throws Exception {
        m_DepthInInches = value;
    }

    //   Attr Name:   ShellThicknessInInches
    //   Attr Group:Standard
    //   Alt Display Name:Shell Thick (in)
    //   Description:   Shell thickness in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   4.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShellThicknessInInches;
    public double getShellThicknessInInches() throws Exception {
        return m_ShellThicknessInInches;
    }

    public void setShellThicknessInInches(double value) throws Exception {
        m_ShellThicknessInInches = value;
    }

    //   Attr Name:   ReducedCircumference
    //   Attr Group:Standard
    //   Alt Display Name:Reduced Circum (in)
    //   Description:   Shell reduced circumference in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ReducedCircumference;
    public double getReducedCircumference() throws Exception {
        return m_ReducedCircumference;
    }

    public void setReducedCircumference(double value) throws Exception {
        m_ReducedCircumference = value;
    }

    //   Attr Name:   EntryWidthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Entry Width (in)
    //   Description:   The entry width in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_EntryWidthInInches;
    public double getEntryWidthInInches() throws Exception {
        return m_EntryWidthInInches;
    }

    public void setEntryWidthInInches(double value) throws Exception {
        m_EntryWidthInInches = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Location (ft)
    //   Description:   Distance from the butt of the pole to center of damage or decay
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   120.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation angle around the center of the pole
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


