//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import CS2JNet.System.Text.EncodingSupport;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import PPL_Model_Wrapper.Scene;

//--------------------------------------------------------------------------------------------
//   Class: PPLX
//--------------------------------------------------------------------------------------------
public class PPLX   
{
    private Scene m_Scene = new Scene();
    public void setScene(Scene value) throws Exception {
        m_Scene = value;
    }

    public Scene getScene() throws Exception {
        return m_Scene;
    }

    //Write to PPLX
    public void savePPLX(String pFullPath) throws Exception {
        XmlTextWriter writer = new XmlTextWriter(pFullPath, EncodingSupport.GetEncoder("UTF-8"));
        try
        {
            {
                writer.Formatting = Formatting.Indented;
                writer.WriteStartDocument();
                writer.WriteStartElement("PPL");
                try
                {
                    writer.WriteAttributeString("DATE", (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a")).format(Calendar.getInstance().getTime()));
                    writer.WriteAttributeString("USER", Environment.UserName.toString());
                    writer.WriteAttributeString("WORKSTATION", InetAddress.getLocalHost().getHostName().toString());
                }
                catch (Exception __dummyCatchVar0)
                {
                }

                m_Scene.saveToXML(writer);
                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
            }
        }
        finally
        {
            if (writer != null)
                Disposable.mkDisposable(writer).dispose();
             
        }
    }

}


