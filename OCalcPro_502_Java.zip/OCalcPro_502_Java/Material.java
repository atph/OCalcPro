//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Material
// Mirrors: PPLMaterial : PPLElement
//--------------------------------------------------------------------------------------------
public class Material  extends ElementBase 
{
    public static String gXMLkey = "Material";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Material(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Material";
            m_Name = "<tbd>";
            m_YoungsModulus = 20000000;
            m_PoissonsRatio = 0.3;
            m_Density = 0.0347222222222222;
            m_ThermalCoefficient = 1.06E-05;
            m_ShearAreaY = 8;
            m_ShearAreaZ = 8;
            m_ShearModulus = 8000000;
            m_ShearStrengthY = 45000;
            m_ShearStrengthZ = 45000;
            m_BucklingStrength = 45000;
            m_TensionStrength = 45000;
            m_MomentCapacityY = 2000;
            m_MomentCapacityZ = 2000;
            m_MomentCapacityX = 2000;
            m_Area = 11;
            m_DimensionY = 6;
            m_DimensionZ = 6;
            m_IcePerimiter = 6;
            m_WindArea = 11;
            m_Iyy = 400;
            m_Izz = 400;
            m_Jxx = 200;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the material
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Material
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the material
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <tbd>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   YoungsModulus
    //   Attr Group:Constants
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   YoungsModulus
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   20000000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_YoungsModulus;
    public double getYoungsModulus() throws Exception {
        return m_YoungsModulus;
    }

    public void setYoungsModulus(double value) throws Exception {
        m_YoungsModulus = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Constants
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.3
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   Density
    //   Attr Group:Constants
    //   Alt Display Name:Density (lb/ft^3)
    //   Description:   Density for the material in lbs per cubic inch
    //   Displayed Units:   store as POUNDS PER CUBIC INCH display as POUNDS PER CUBIC FOOT or KILOGRAMS PER CUBIC METER
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0347222222222222
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Density;
    public double getDensity() throws Exception {
        return m_Density;
    }

    public void setDensity(double value) throws Exception {
        m_Density = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Constants
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000106
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   ShearAreaY
    //   Attr Group:Shear
    //   Alt Display Name:Shear Area Y (in^2)
    //   Description:   Shear Area Y
    //   Displayed Units:   store as IN2 display as IN2 or CM2
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   8
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearAreaY;
    public double getShearAreaY() throws Exception {
        return m_ShearAreaY;
    }

    public void setShearAreaY(double value) throws Exception {
        m_ShearAreaY = value;
    }

    //   Attr Name:   ShearAreaZ
    //   Attr Group:Shear
    //   Alt Display Name:Shear Area Z (in^2)
    //   Description:   Shear Area Z
    //   Displayed Units:   store as IN2 display as IN2 or CM2
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   8
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearAreaZ;
    public double getShearAreaZ() throws Exception {
        return m_ShearAreaZ;
    }

    public void setShearAreaZ(double value) throws Exception {
        m_ShearAreaZ = value;
    }

    //   Attr Name:   ShearModulus
    //   Attr Group:Shear
    //   Alt Display Name:Shear Modulus (psi)
    //   Description:   Shear Modulus
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   8000000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearModulus;
    public double getShearModulus() throws Exception {
        return m_ShearModulus;
    }

    public void setShearModulus(double value) throws Exception {
        m_ShearModulus = value;
    }

    //   Attr Name:   ShearStrengthY
    //   Attr Group:Shear
    //   Alt Display Name:Shear Strength Y (lbs)
    //   Description:   The shear strength of the beam
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearStrengthY;
    public double getShearStrengthY() throws Exception {
        return m_ShearStrengthY;
    }

    public void setShearStrengthY(double value) throws Exception {
        m_ShearStrengthY = value;
    }

    //   Attr Name:   ShearStrengthZ
    //   Attr Group:Shear
    //   Alt Display Name:Shear Strength Z (lbs)
    //   Description:   The shear strength of the beam
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearStrengthZ;
    public double getShearStrengthZ() throws Exception {
        return m_ShearStrengthZ;
    }

    public void setShearStrengthZ(double value) throws Exception {
        m_ShearStrengthZ = value;
    }

    //   Attr Name:   BucklingStrength
    //   Attr Group:Capacity
    //   Alt Display Name:Buckling Strength (lbs)
    //   Description:   The buckling strength of the beam
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingStrength;
    public double getBucklingStrength() throws Exception {
        return m_BucklingStrength;
    }

    public void setBucklingStrength(double value) throws Exception {
        m_BucklingStrength = value;
    }

    //   Attr Name:   TensionStrength
    //   Attr Group:Capacity
    //   Alt Display Name:Tensile Strength (lbs)
    //   Description:   The tensile strength of the beam
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TensionStrength;
    public double getTensionStrength() throws Exception {
        return m_TensionStrength;
    }

    public void setTensionStrength(double value) throws Exception {
        m_TensionStrength = value;
    }

    //   Attr Name:   MomentCapacityY
    //   Attr Group:Capacity
    //   Alt Display Name:Moment Capacity Y (ft-lbs)
    //   Description:   Total allowable bending moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   2000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentCapacityY;
    public double getMomentCapacityY() throws Exception {
        return m_MomentCapacityY;
    }

    public void setMomentCapacityY(double value) throws Exception {
        m_MomentCapacityY = value;
    }

    //   Attr Name:   MomentCapacityZ
    //   Attr Group:Capacity
    //   Alt Display Name:Moment Capacity Z (ft-lbs)
    //   Description:   Total allowable bending moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   2000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentCapacityZ;
    public double getMomentCapacityZ() throws Exception {
        return m_MomentCapacityZ;
    }

    public void setMomentCapacityZ(double value) throws Exception {
        m_MomentCapacityZ = value;
    }

    //   Attr Name:   MomentCapacityX
    //   Attr Group:Capacity
    //   Alt Display Name:Torque Capacity (ft-lbs)
    //   Description:   Total allowable bending moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   2000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentCapacityX;
    public double getMomentCapacityX() throws Exception {
        return m_MomentCapacityX;
    }

    public void setMomentCapacityX(double value) throws Exception {
        m_MomentCapacityX = value;
    }

    //   Attr Name:   Area
    //   Attr Group:Dimensions
    //   Alt Display Name:Area (in^2)
    //   Description:   Cross sectional area
    //   Displayed Units:   store as IN2 display as IN2 or CM2
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   11
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Area;
    public double getArea() throws Exception {
        return m_Area;
    }

    public void setArea(double value) throws Exception {
        m_Area = value;
    }

    //   Attr Name:   DimensionY
    //   Attr Group:Dimensions
    //   Alt Display Name:Dimension Y (in)
    //   Description:   Dimension in the Y axis
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   6
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DimensionY;
    public double getDimensionY() throws Exception {
        return m_DimensionY;
    }

    public void setDimensionY(double value) throws Exception {
        m_DimensionY = value;
    }

    //   Attr Name:   DimensionZ
    //   Attr Group:Dimensions
    //   Alt Display Name:Dimension Z (in)
    //   Description:   Dimension in the Z axis
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   6
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DimensionZ;
    public double getDimensionZ() throws Exception {
        return m_DimensionZ;
    }

    public void setDimensionZ(double value) throws Exception {
        m_DimensionZ = value;
    }

    //   Attr Name:   IcePerimiter
    //   Attr Group:Dimensions
    //   Alt Display Name:Ice Perimiter (in)
    //   Description:   Ice accumulation perimiter (effective)
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   6
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_IcePerimiter;
    public double getIcePerimiter() throws Exception {
        return m_IcePerimiter;
    }

    public void setIcePerimiter(double value) throws Exception {
        m_IcePerimiter = value;
    }

    //   Attr Name:   WindArea
    //   Attr Group:Dimensions
    //   Alt Display Name:Wind Area (in^2/ft)
    //   Description:   Wind area per unit length
    //   Displayed Units:   store as SQINPERIN display as SQINPERFOOT or SQCMPERMETER
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   11
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindArea;
    public double getWindArea() throws Exception {
        return m_WindArea;
    }

    public void setWindArea(double value) throws Exception {
        m_WindArea = value;
    }

    //   Attr Name:   Iyy
    //   Attr Group:Moments
    //   Alt Display Name:Ixx - 2nd MOA (in^4)
    //   Description:   Second moment of area in the horizontal axis
    //   Displayed Units:   store as IN4 display as IN4 or CM4
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   400
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Iyy;
    public double getIyy() throws Exception {
        return m_Iyy;
    }

    public void setIyy(double value) throws Exception {
        m_Iyy = value;
    }

    //   Attr Name:   Izz
    //   Attr Group:Moments
    //   Alt Display Name:Izz - 2nd MOA (in^4)
    //   Description:   Second moment of area in the vertical axis
    //   Displayed Units:   store as IN4 display as IN4 or CM4
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   400
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Izz;
    public double getIzz() throws Exception {
        return m_Izz;
    }

    public void setIzz(double value) throws Exception {
        m_Izz = value;
    }

    //   Attr Name:   Jxx
    //   Attr Group:Moments
    //   Alt Display Name:Jyy - 2nd MOA (in^4)
    //   Description:   Second moment of area in the radial axis
    //   Displayed Units:   store as IN4 display as IN4 or CM4
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   200
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Jxx;
    public double getJxx() throws Exception {
        return m_Jxx;
    }

    public void setJxx(double value) throws Exception {
        m_Jxx = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


