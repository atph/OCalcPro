//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: BeamLoad
// Mirrors: PPLBeamLoad : PPLElement
//--------------------------------------------------------------------------------------------
public class BeamLoad  extends ElementBase 
{
    public static String gXMLkey = "BeamLoad";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public BeamLoad(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Applied Load";
            m_Name = "";
            m_Type = Type_val.Uniform;
            m_LoadX = 0;
            m_LoadY = 0;
            m_LoadZ = 0;
            m_Offset = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Applied Load
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the load
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Type of the load
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Uniform
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Point  (Point)
        Uniform,
        //Uniform
        Point
    }
    //Point
    private Type_val m_Type = Type_val.Uniform;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Uniform"))
        {
            return Type_val.Uniform;
        }
        else //Uniform
        if (__dummyScrutVar0.equals("Point"))
        {
            return Type_val.Point;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Point
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Uniform: 
                return "Uniform";
            case Point: 
                return "Point";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Uniform
    //Point
    //   Attr Name:   LoadX
    //   Attr Group:Standard
    //   Alt Display Name:Load X lbs
    //   Description:   Applied load in the X axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadX;
    public double getLoadX() throws Exception {
        return m_LoadX;
    }

    public void setLoadX(double value) throws Exception {
        m_LoadX = value;
    }

    //   Attr Name:   LoadY
    //   Attr Group:Standard
    //   Alt Display Name:Load Y lbs
    //   Description:   Applied load in the Y axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadY;
    public double getLoadY() throws Exception {
        return m_LoadY;
    }

    public void setLoadY(double value) throws Exception {
        m_LoadY = value;
    }

    //   Attr Name:   LoadZ
    //   Attr Group:Standard
    //   Alt Display Name:Load Z lbs
    //   Description:   Applied load in the Z axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadZ;
    public double getLoadZ() throws Exception {
        return m_LoadZ;
    }

    public void setLoadZ(double value) throws Exception {
        m_LoadZ = value;
    }

    //   Attr Name:   Offset
    //   Attr Group:Standard
    //   Alt Display Name:Offset (in)
    //   Description:   Offset from node 1
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Offset;
    public double getOffset() throws Exception {
        return m_Offset;
    }

    public void setOffset(double value) throws Exception {
        m_Offset = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


