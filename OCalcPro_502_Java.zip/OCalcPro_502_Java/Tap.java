//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.Span;
import PPL_Model_Wrapper.SpanBundle;

//--------------------------------------------------------------------------------------------
//   Class: Tap
// Mirrors: PPLTap : PPLElement
//--------------------------------------------------------------------------------------------
public class Tap  extends ElementBase 
{
    public static String gXMLkey = "Tap";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Tap(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Flying Tap";
            m_Owner = "<Undefined>";
            m_CoordinateA = 0;
            m_OffsetInches = 60;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Span)
            return true;
         
        if (pChildCandidate instanceof SpanBundle)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the tap
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Flying Tap
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Base Angle (Â°)
    //   Description:   Angle
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   OffsetInches
    //   Attr Group:Standard
    //   Alt Display Name:Offset (ft)
    //   Description:   Offset from start of pole
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERX
    //   Default Value:   60
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OffsetInches;
    public double getOffsetInches() throws Exception {
        return m_OffsetInches;
    }

    public void setOffsetInches(double value) throws Exception {
        m_OffsetInches = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


