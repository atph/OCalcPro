//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Streetlight
// Mirrors: PPLStreetlight : PPLElement
//--------------------------------------------------------------------------------------------
public class Streetlight  extends ElementBase 
{
    public static String gXMLkey = "Streetlight";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Streetlight(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_CoordinateX = 0;
            m_Description = "Streetlight";
            m_Owner = "<Undefined>";
            m_Type = Type_val.General;
            m_CoordinateZ = 300;
            m_CoordinateA = 0;
            m_LengthInInches = 96;
            m_ArmDiameterInInches = 3;
            m_ArmRiseInInches = 25;
            m_CanDiameterInInches = 22;
            m_CanHeightInInches = 9;
            m_Weight = 40;
            m_WindDragCoef = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Description:   The horizontal position of the base plate relative to the center of the pole in inches
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of streetlight
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Streetlight
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   General type of light to model.
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   General
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Decorative  (Decorative)
        //        Spot Light  (Spot Light)
        //        Flood Light  (Flood Light)
        //        Traffic Signal  (Traffic Signal)
        General,
        //General
        Decorative,
        //Decorative
        Spot_Light,
        //Spot Light
        Flood_Light,
        //Flood Light
        Traffic_Signal
    }
    //Traffic Signal
    private Type_val m_Type = Type_val.General;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("General"))
        {
            return Type_val.General;
        }
        else //General
        if (__dummyScrutVar0.equals("Decorative"))
        {
            return Type_val.Decorative;
        }
        else //Decorative
        if (__dummyScrutVar0.equals("Spot Light"))
        {
            return Type_val.Spot_Light;
        }
        else //Spot Light
        if (__dummyScrutVar0.equals("Flood Light"))
        {
            return Type_val.Flood_Light;
        }
        else //Flood Light
        if (__dummyScrutVar0.equals("Traffic Signal"))
        {
            return Type_val.Traffic_Signal;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Traffic Signal
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case General: 
                return "General";
            case Decorative: 
                return "Decorative";
            case Spot_Light: 
                return "Spot Light";
            case Flood_Light: 
                return "Flood Light";
            case Traffic_Signal: 
                return "Traffic Signal";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //General
    //Decorative
    //Spot Light
    //Flood Light
    //Traffic Signal
    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:   The distance from the center of the base plate to the butt of the pole in inches
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   300.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The angle of the streetlight relative to the parent structure in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Arm Length (in)
    //   Description:   The horizontal length from the face of the pole to the tip of the streetlight
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   96.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   ArmDiameterInInches
    //   Attr Group:Standard
    //   Alt Display Name:Arm Diameter (in)
    //   Description:   The diameter or thickness of the arm of the streetlight assembly
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ArmDiameterInInches;
    public double getArmDiameterInInches() throws Exception {
        return m_ArmDiameterInInches;
    }

    public void setArmDiameterInInches(double value) throws Exception {
        m_ArmDiameterInInches = value;
    }

    //   Attr Name:   ArmRiseInInches
    //   Attr Group:Standard
    //   Alt Display Name:Arm Rise (in)
    //   Description:   The horizontal length from the face of the pole to the tip of the streetlight
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   25.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ArmRiseInInches;
    public double getArmRiseInInches() throws Exception {
        return m_ArmRiseInInches;
    }

    public void setArmRiseInInches(double value) throws Exception {
        m_ArmRiseInInches = value;
    }

    //   Attr Name:   CanDiameterInInches
    //   Attr Group:Standard
    //   Alt Display Name:Can Diameter (in)
    //   Description:   The diameter or thickness of the light fixture at the tip of the streetlight assempbly
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   22.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_CanDiameterInInches;
    public double getCanDiameterInInches() throws Exception {
        return m_CanDiameterInInches;
    }

    public void setCanDiameterInInches(double value) throws Exception {
        m_CanDiameterInInches = value;
    }

    //   Attr Name:   CanHeightInInches
    //   Attr Group:Standard
    //   Alt Display Name:Can Height (in)
    //   Description:   The height of the can of the light fixture
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   9.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_CanHeightInInches;
    public double getCanHeightInInches() throws Exception {
        return m_CanHeightInInches;
    }

    public void setCanHeightInInches(double value) throws Exception {
        m_CanHeightInInches = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Standard
    //   Alt Display Name:Equip Weight(lbs)
    //   Description:   Weight of the streetlight in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   40.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Standard
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


