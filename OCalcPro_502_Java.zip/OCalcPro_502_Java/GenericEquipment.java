//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: GenericEquipment
// Mirrors: PPLGenericEquipment : PPLElement
//--------------------------------------------------------------------------------------------
public class GenericEquipment  extends ElementBase 
{
    public static String gXMLkey = "GenericEquipment";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public GenericEquipment(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_CoordinateX = 10;
            m_Description = "Generic Equipment";
            m_Owner = "<Undefined>";
            m_CoordinateZ = 0;
            m_CoordinateZ_Rel = 0;
            m_CoordinateA = 0;
            m_Parent_Gap = 6;
            m_Shape = Shape_val.Box;
            m_Points = "12";
            m_DiameterOrWidthInInches = 12;
            m_DepthInInches = 12;
            m_HeightInInches = 12;
            m_Pitch = 0;
            m_Roll = 0;
            m_Yaw = 0;
            m_Weight = 10;
            m_WindDragCoef = 0;
            m_Color = "#FF4682B4";
            m_ShowLabel = false;
            m_TextColor = "#FFFFFF00";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof GenericEquipment)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Description:   The distance in inches from the center of the parent pole to the point where the bracket is bolted to the pole
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of equipment
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Generic Equipment
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Height (ft)
    //   Description:   The distance in inches from the bottom of the parent (butt of the pole for example) to the center of the equipment
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateZ_Rel
    //   Attr Group:Standard
    //   Alt Display Name:Relative Height (in)
    //   Description:   The distance in inches from the bottom of the parent (butt of the pole for example) to the center of the equipment
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ_Rel;
    public double getCoordinateZ_Rel() throws Exception {
        return m_CoordinateZ_Rel;
    }

    public void setCoordinateZ_Rel(double value) throws Exception {
        m_CoordinateZ_Rel = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   Angle of equipment relative to the parent structure (typically pole)
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   Parent Gap
    //   Attr Group:Standard
    //   Alt Display Name:Relative Gap (in)
    //   Description:   Distance between parent and equipment in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   6
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Parent_Gap;
    public double getParent_Gap() throws Exception {
        return m_Parent_Gap;
    }

    public void setParent_Gap(double value) throws Exception {
        m_Parent_Gap = value;
    }

    public enum Shape_val
    {
        //   Attr Name:   Shape
        //   Attr Group:Specifications
        //   Description:   Shape of equipment
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Box
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Cylinder  (Cylinder)
        //        Imported  (Imported)
        Box,
        //Box
        Cylinder,
        //Cylinder
        Imported
    }
    //Imported
    private Shape_val m_Shape = Shape_val.Box;
    public Shape_val getShape() throws Exception {
        return m_Shape;
    }

    public void setShape(Shape_val value) throws Exception {
        m_Shape = value;
    }

    public Shape_val string_to_Shape_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Box"))
        {
            return Shape_val.Box;
        }
        else //Box
        if (__dummyScrutVar0.equals("Cylinder"))
        {
            return Shape_val.Cylinder;
        }
        else //Cylinder
        if (__dummyScrutVar0.equals("Imported"))
        {
            return Shape_val.Imported;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Imported
    public String shape_val_to_String(Shape_val pKey) throws Exception {
        switch(pKey)
        {
            case Box: 
                return "Box";
            case Cylinder: 
                return "Cylinder";
            case Imported: 
                return "Imported";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Box
    //Cylinder
    //Imported
    //   Attr Name:   Points
    //   Attr Group:Specifications
    //   Description:   The points defining the shape
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   SHAPE_DEFINITION
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Points;
    public String getPoints() throws Exception {
        return m_Points;
    }

    public void setPoints(String value) throws Exception {
        m_Points = value;
    }

    //   Attr Name:   DiameterOrWidthInInches
    //   Attr Group:Specifications
    //   Alt Display Name:Unit Width/Diameter (in)
    //   Description:   The Diameter or Width in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DiameterOrWidthInInches;
    public double getDiameterOrWidthInInches() throws Exception {
        return m_DiameterOrWidthInInches;
    }

    public void setDiameterOrWidthInInches(double value) throws Exception {
        m_DiameterOrWidthInInches = value;
    }

    //   Attr Name:   DepthInInches
    //   Attr Group:Specifications
    //   Alt Display Name:Unit Depth (in)
    //   Description:   The Depth in inches which is only used if the shape of the equipment is a box
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DepthInInches;
    public double getDepthInInches() throws Exception {
        return m_DepthInInches;
    }

    public void setDepthInInches(double value) throws Exception {
        m_DepthInInches = value;
    }

    //   Attr Name:   HeightInInches
    //   Attr Group:Specifications
    //   Alt Display Name:Unit Height (in)
    //   Description:   The Height in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HeightInInches;
    public double getHeightInInches() throws Exception {
        return m_HeightInInches;
    }

    public void setHeightInInches(double value) throws Exception {
        m_HeightInInches = value;
    }

    //   Attr Name:   Pitch
    //   Attr Group:Standard
    //   Alt Display Name:Pitch (Â°)
    //   Description:   Pitch in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Pitch;
    public double getPitch() throws Exception {
        return m_Pitch;
    }

    public void setPitch(double value) throws Exception {
        m_Pitch = value;
    }

    //   Attr Name:   Roll
    //   Attr Group:Standard
    //   Alt Display Name:Roll (Â°)
    //   Description:   Roll in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Roll;
    public double getRoll() throws Exception {
        return m_Roll;
    }

    public void setRoll(double value) throws Exception {
        m_Roll = value;
    }

    //   Attr Name:   Yaw
    //   Attr Group:Standard
    //   Alt Display Name:Yaw (Â°)
    //   Description:   Yaw in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Yaw;
    public double getYaw() throws Exception {
        return m_Yaw;
    }

    public void setYaw(double value) throws Exception {
        m_Yaw = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Specifications
    //   Alt Display Name:Unit Weight (lbs)
    //   Description:   The weight of the element in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   10.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Specifications
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   Color
    //   Attr Group:Specifications
    //   Alt Display Name:Display Color
    //   Description:   The color of the element
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   COLOR
    //   Default Value:   #FF4682B4
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Color;
    public String getColor() throws Exception {
        return m_Color;
    }

    public void setColor(String value) throws Exception {
        m_Color = value;
    }

    //   Attr Name:   ShowLabel
    //   Attr Group:Specifications
    //   Alt Display Name:Show Label
    //   Description:   Indicates if the label is displayed
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_ShowLabel;
    public boolean getShowLabel() throws Exception {
        return m_ShowLabel;
    }

    public void setShowLabel(boolean value) throws Exception {
        m_ShowLabel = value;
    }

    //   Attr Name:   TextColor
    //   Attr Group:Specifications
    //   Alt Display Name:Label Color
    //   Description:   The color of the element's text
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   COLOR
    //   Default Value:   #FFFFFF00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_TextColor;
    public String getTextColor() throws Exception {
        return m_TextColor;
    }

    public void setTextColor(String value) throws Exception {
        m_TextColor = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


