//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Riser
// Mirrors: PPLRiser : PPLElement
//--------------------------------------------------------------------------------------------
public class Riser  extends ElementBase 
{
    public static String gXMLkey = "Riser";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Riser(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Riser";
            m_Owner = "<Undefined>";
            m_CoordinateA = 1.5707963267949;
            m_DiameterInInches = 3.5;
            m_OffsetInInches = 0;
            m_LengthAboveGLInInches = 300;
            m_PoundsPerInch = 0.0833333;
            m_Apply_Wind = false;
            m_WindDragCoef = 0;
            m_Wind_Shadowing = false;
            m_Self_Supporting = false;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the riser
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Riser
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Install Angle (Â°)
    //   Description:   Install Angle
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   1.5707963267949
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   DiameterInInches
    //   Attr Group:Standard
    //   Alt Display Name:Diameter (in)
    //   Description:   The diameter of the riser
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   3.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DiameterInInches;
    public double getDiameterInInches() throws Exception {
        return m_DiameterInInches;
    }

    public void setDiameterInInches(double value) throws Exception {
        m_DiameterInInches = value;
    }

    //   Attr Name:   OffsetInInches
    //   Attr Group:Standard
    //   Alt Display Name:Standoff (in)
    //   Description:   The offset if the riser is on standoffs
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   TRACKERX
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OffsetInInches;
    public double getOffsetInInches() throws Exception {
        return m_OffsetInInches;
    }

    public void setOffsetInInches(double value) throws Exception {
        m_OffsetInInches = value;
    }

    //   Attr Name:   LengthAboveGLInInches
    //   Attr Group:Standard
    //   Alt Display Name:Length AGL (ft)
    //   Description:   The length above GL
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERZ
    //   Default Value:   300
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthAboveGLInInches;
    public double getLengthAboveGLInInches() throws Exception {
        return m_LengthAboveGLInInches;
    }

    public void setLengthAboveGLInInches(double value) throws Exception {
        m_LengthAboveGLInInches = value;
    }

    //   Attr Name:   PoundsPerInch
    //   Attr Group:Load Analysis
    //   Alt Display Name:Weight (lbs/ft)
    //   Description:   The weight in pounds per inch of running length
    //   Displayed Units:   store as POUNDS PER IN display as POUNDS PER FT or KILOGRAMS PER METER
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0833333
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoundsPerInch;
    public double getPoundsPerInch() throws Exception {
        return m_PoundsPerInch;
    }

    public void setPoundsPerInch(double value) throws Exception {
        m_PoundsPerInch = value;
    }

    //   Attr Name:   Apply Wind
    //   Attr Group:Load Analysis
    //   Description:   Apply wind to the riser?
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Apply_Wind;
    public boolean getApply_Wind() throws Exception {
        return m_Apply_Wind;
    }

    public void setApply_Wind(boolean value) throws Exception {
        m_Apply_Wind = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Load Analysis
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   Wind Shadowing
    //   Attr Group:Load Analysis
    //   Description:   Does the pole shadow wind on the riser?
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Wind_Shadowing;
    public boolean getWind_Shadowing() throws Exception {
        return m_Wind_Shadowing;
    }

    public void setWind_Shadowing(boolean value) throws Exception {
        m_Wind_Shadowing = value;
    }

    //   Attr Name:   Self Supporting
    //   Attr Group:Load Analysis
    //   Description:   Is the riser vertically self supporting?
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Self_Supporting;
    public boolean getSelf_Supporting() throws Exception {
        return m_Self_Supporting;
    }

    public void setSelf_Supporting(boolean value) throws Exception {
        m_Self_Supporting = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


