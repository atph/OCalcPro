//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: CapacityAdjustment
// Mirrors: PPLCapacityAdjustment : PPLElement
//--------------------------------------------------------------------------------------------
public class CapacityAdjustment  extends ElementBase 
{
    public static String gXMLkey = "CapacityAdjustment";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public CapacityAdjustment(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "";
            m_Owner = "<Undefined>";
            m_HeightInInches = 1;
            m_CoordinateZ = 120;
            m_CoordinateA = 0;
            m_MomentCapacity = 50000;
            m_BucklingCapacity = 5000;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Brief description of the damage
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   HeightInInches
    //   Attr Group:Standard
    //   Alt Display Name:Height (in)
    //   Description:   The height in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HeightInInches;
    public double getHeightInInches() throws Exception {
        return m_HeightInInches;
    }

    public void setHeightInInches(double value) throws Exception {
        m_HeightInInches = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Location (ft)
    //   Description:   Distance from the butt of the pole to center of damage or decay
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   120.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation angle around the center of the pole
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   MomentCapacity
    //   Attr Group:Standard
    //   Alt Display Name:Moment Cap (ft-lb)
    //   Description:   The  moment capacity
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   50000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentCapacity;
    public double getMomentCapacity() throws Exception {
        return m_MomentCapacity;
    }

    public void setMomentCapacity(double value) throws Exception {
        m_MomentCapacity = value;
    }

    //   Attr Name:   BucklingCapacity
    //   Attr Group:Standard
    //   Alt Display Name:Buckling Cap (lbs)
    //   Description:   The buckling capacity
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   5000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingCapacity;
    public double getBucklingCapacity() throws Exception {
        return m_BucklingCapacity;
    }

    public void setBucklingCapacity(double value) throws Exception {
        m_BucklingCapacity = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


