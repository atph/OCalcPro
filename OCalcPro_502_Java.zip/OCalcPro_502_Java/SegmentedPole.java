//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Anchor;
import PPL_Model_Wrapper.Crossarm;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.NodeJunction;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.PoleSegment;
import PPL_Model_Wrapper.PowerEquipment;
import PPL_Model_Wrapper.Riser;
import PPL_Model_Wrapper.Streetlight;

//--------------------------------------------------------------------------------------------
//   Class: SegmentedPole
// Mirrors: PPLSegmentedPole : PPLElement
//--------------------------------------------------------------------------------------------
public class SegmentedPole  extends ElementBase 
{
    public static String gXMLkey = "SegmentedPole";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public SegmentedPole(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Pole_Number = "Unset";
            m_Owner = "Pole";
            m_Structure_Type = Structure_Type_val.Auto;
            m_OverlapCombineCap = false;
            m_LineOfLead = 0;
            m_LeanDirection = 0;
            m_LeanAmount = 0;
            m_OverturnMoment = 0;
            m_Aux_Data_1 = "Unset";
            m_Aux_Data_2 = "Unset";
            m_Aux_Data_3 = "Unset";
            m_Aux_Data_4 = "Unset";
            m_Aux_Data_5 = "Unset";
            m_Aux_Data_6 = "Unset";
            m_Aux_Data_7 = "Unset";
            m_Aux_Data_8 = "Unset";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Crossarm)
            return true;
         
        if (pChildCandidate instanceof PowerEquipment)
            return true;
         
        if (pChildCandidate instanceof Streetlight)
            return true;
         
        if (pChildCandidate instanceof Insulator)
            return true;
         
        if (pChildCandidate instanceof NodeJunction)
            return true;
         
        if (pChildCandidate instanceof Riser)
            return true;
         
        if (pChildCandidate instanceof GenericEquipment)
            return true;
         
        if (pChildCandidate instanceof Anchor)
            return true;
         
        if (pChildCandidate instanceof LoadCase)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof PoleSegment)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Pole Number
    //   Attr Group:Standard
    //   Description:   Pole identification
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Pole_Number;
    public String getPole_Number() throws Exception {
        return m_Pole_Number;
    }

    public void setPole_Number(String value) throws Exception {
        m_Pole_Number = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Pole
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Structure_Type_val
    {
        //   Attr Name:   Structure Type
        //   Attr Group:Standard
        //   Description:   Pole structure type specification
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Auto
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Tangent  (Pole with all wires running in line with each other)
        //        Angle  (Pole with at least one wire that is at an angle relative to the others)
        //        Deadend  (Pole with wires ending at the pole)
        //        Junction  (Pole with wires crossing at or near the pole)
        Auto,
        //Automatically determine the structure type from attached equipment
        Tangent,
        //Pole with all wires running in line with each other
        Angle,
        //Pole with at least one wire that is at an angle relative to the others
        Deadend,
        //Pole with wires ending at the pole
        Junction
    }
    //Pole with wires crossing at or near the pole
    private Structure_Type_val m_Structure_Type = Structure_Type_val.Auto;
    public Structure_Type_val getStructure_Type() throws Exception {
        return m_Structure_Type;
    }

    public void setStructure_Type(Structure_Type_val value) throws Exception {
        m_Structure_Type = value;
    }

    public Structure_Type_val string_to_Structure_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Auto"))
        {
            return Structure_Type_val.Auto;
        }
        else //Automatically determine the structure type from attached equipment
        if (__dummyScrutVar0.equals("Tangent"))
        {
            return Structure_Type_val.Tangent;
        }
        else //Pole with all wires running in line with each other
        if (__dummyScrutVar0.equals("Angle"))
        {
            return Structure_Type_val.Angle;
        }
        else //Pole with at least one wire that is at an angle relative to the others
        if (__dummyScrutVar0.equals("Deadend"))
        {
            return Structure_Type_val.Deadend;
        }
        else //Pole with wires ending at the pole
        if (__dummyScrutVar0.equals("Junction"))
        {
            return Structure_Type_val.Junction;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Pole with wires crossing at or near the pole
    public String structure_Type_val_to_String(Structure_Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Auto: 
                return "Auto";
            case Tangent: 
                return "Tangent";
            case Angle: 
                return "Angle";
            case Deadend: 
                return "Deadend";
            case Junction: 
                return "Junction";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Automatically determine the structure type from attached equipment
    //Pole with all wires running in line with each other
    //Pole with at least one wire that is at an angle relative to the others
    //Pole with wires ending at the pole
    //Pole with wires crossing at or near the pole
    //   Attr Name:   OverlapCombineCap
    //   Attr Group:Standard
    //   Alt Display Name:Overlap Combine Cap
    //   Description:   OverlapCombineCap
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverlapCombineCap;
    public boolean getOverlapCombineCap() throws Exception {
        return m_OverlapCombineCap;
    }

    public void setOverlapCombineCap(boolean value) throws Exception {
        m_OverlapCombineCap = value;
    }

    //   Attr Name:   LineOfLead
    //   Attr Group:Standard
    //   Alt Display Name:Line of Lead (Â°)
    //   Description:   The overall line of lead of the entire pole assembly
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LineOfLead;
    public double getLineOfLead() throws Exception {
        return m_LineOfLead;
    }

    public void setLineOfLead(double value) throws Exception {
        m_LineOfLead = value;
    }

    //   Attr Name:   LeanDirection
    //   Attr Group:Standard
    //   Alt Display Name:Lean Direction (Â°)
    //   Description:   Pole lean direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanDirection;
    public double getLeanDirection() throws Exception {
        return m_LeanDirection;
    }

    public void setLeanDirection(double value) throws Exception {
        m_LeanDirection = value;
    }

    //   Attr Name:   LeanAmount
    //   Attr Group:Standard
    //   Alt Display Name:Lean Amount (Â°)
    //   Description:   Pole amount direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanAmount;
    public double getLeanAmount() throws Exception {
        return m_LeanAmount;
    }

    public void setLeanAmount(double value) throws Exception {
        m_LeanAmount = value;
    }

    //   Attr Name:   OverturnMoment
    //   Attr Group:Overturn
    //   Alt Display Name:Overturn Moment (ft-lbs)
    //   Description:   Overturn Moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.#
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OverturnMoment;
    public double getOverturnMoment() throws Exception {
        return m_OverturnMoment;
    }

    public void setOverturnMoment(double value) throws Exception {
        m_OverturnMoment = value;
    }

    //   Attr Name:   Aux Data 1
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_1;
    public String getAux_Data_1() throws Exception {
        return m_Aux_Data_1;
    }

    public void setAux_Data_1(String value) throws Exception {
        m_Aux_Data_1 = value;
    }

    //   Attr Name:   Aux Data 2
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_2;
    public String getAux_Data_2() throws Exception {
        return m_Aux_Data_2;
    }

    public void setAux_Data_2(String value) throws Exception {
        m_Aux_Data_2 = value;
    }

    //   Attr Name:   Aux Data 3
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_3;
    public String getAux_Data_3() throws Exception {
        return m_Aux_Data_3;
    }

    public void setAux_Data_3(String value) throws Exception {
        m_Aux_Data_3 = value;
    }

    //   Attr Name:   Aux Data 4
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_4;
    public String getAux_Data_4() throws Exception {
        return m_Aux_Data_4;
    }

    public void setAux_Data_4(String value) throws Exception {
        m_Aux_Data_4 = value;
    }

    //   Attr Name:   Aux Data 5
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_5;
    public String getAux_Data_5() throws Exception {
        return m_Aux_Data_5;
    }

    public void setAux_Data_5(String value) throws Exception {
        m_Aux_Data_5 = value;
    }

    //   Attr Name:   Aux Data 6
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_6;
    public String getAux_Data_6() throws Exception {
        return m_Aux_Data_6;
    }

    public void setAux_Data_6(String value) throws Exception {
        m_Aux_Data_6 = value;
    }

    //   Attr Name:   Aux Data 7
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_7;
    public String getAux_Data_7() throws Exception {
        return m_Aux_Data_7;
    }

    public void setAux_Data_7(String value) throws Exception {
        m_Aux_Data_7 = value;
    }

    //   Attr Name:   Aux Data 8
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_8;
    public String getAux_Data_8() throws Exception {
        return m_Aux_Data_8;
    }

    public void setAux_Data_8(String value) throws Exception {
        m_Aux_Data_8 = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


