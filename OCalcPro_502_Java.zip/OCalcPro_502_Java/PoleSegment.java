//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.ValTable;

//--------------------------------------------------------------------------------------------
//   Class: PoleSegment
// Mirrors: PPLSegment : PPLElement
//--------------------------------------------------------------------------------------------
public class PoleSegment  extends ElementBase 
{
    public static String gXMLkey = "PoleSegment";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public PoleSegment(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Material";
            m_Name = "<tbd>";
            m_CoordinateZ = -72;
            m_Type = Type_val.Simple;
            m_Color = "#FFD2B48C";
            m_LengthInInches = 60;
            m_LapLengthInInches = 60;
            m_LapMode = LapMode_val.None;
            m_RadiusAtTipInInches = 8;
            m_RadiusAtBaseInInches = 8;
            m_Weight = 500;
            m_Shape = Shape_val.Round;
            m_Faces = 8;
            m_ThicknessTable = new ValTable("Thick;0,0.25;");
            m_Modulus_of_Elasticity = 1600000;
            m_PoissonsRatio = 0.23;
            m_WindDragCoef = 0;
            m_ThermalCoefficient = 2.7E-06;
            m_MomentCapacityTable = new ValTable("Moment;0,50000;");
            m_BucklingCapacityTable = new ValTable("Buckling;0,5000;");
            m_MaterialTip = "<unset>";
            m_MaterialBase = "<unset>";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Material)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the segment
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Material
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the segment
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <tbd>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Height (ft)
    //   Description:   Height
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   TRACKERZ
    //   Default Value:   -72
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Segment type
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Simple
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Advanced  (Advanced)
        Simple,
        //Simple
        Advanced
    }
    //Advanced
    private Type_val m_Type = Type_val.Simple;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Simple"))
        {
            return Type_val.Simple;
        }
        else //Simple
        if (__dummyScrutVar0.equals("Advanced"))
        {
            return Type_val.Advanced;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Advanced
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Simple: 
                return "Simple";
            case Advanced: 
                return "Advanced";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Simple
    //Advanced
    //   Attr Name:   Color
    //   Attr Group:Standard
    //   Alt Display Name:Display Color
    //   Description:   The color of the segment
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   COLOR
    //   Default Value:   #FFD2B48C
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Color;
    public String getColor() throws Exception {
        return m_Color;
    }

    public void setColor(String value) throws Exception {
        m_Color = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Length (in)
    //   Description:   Length
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   60
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   LapLengthInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Lap Length (in)
    //   Description:   Lap Length
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   60
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LapLengthInInches;
    public double getLapLengthInInches() throws Exception {
        return m_LapLengthInInches;
    }

    public void setLapLengthInInches(double value) throws Exception {
        m_LapLengthInInches = value;
    }

    public enum LapMode_val
    {
        //   Attr Name:   LapMode
        //   Attr Group:Dimensions
        //   Alt Display Name:Lap Mode
        //   Description:   Lap Mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   None
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Bottom  (Bottom)
        //        None  (None)
        Top,
        //Top
        Bottom,
        //Bottom
        None
    }
    //None
    private LapMode_val m_LapMode = LapMode_val.Top;
    public LapMode_val getLapMode() throws Exception {
        return m_LapMode;
    }

    public void setLapMode(LapMode_val value) throws Exception {
        m_LapMode = value;
    }

    public LapMode_val string_to_LapMode_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Top"))
        {
            return LapMode_val.Top;
        }
        else //Top
        if (__dummyScrutVar2.equals("Bottom"))
        {
            return LapMode_val.Bottom;
        }
        else //Bottom
        if (__dummyScrutVar2.equals("None"))
        {
            return LapMode_val.None;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //None
    public String lapMode_val_to_String(LapMode_val pKey) throws Exception {
        switch(pKey)
        {
            case Top: 
                return "Top";
            case Bottom: 
                return "Bottom";
            case None: 
                return "None";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Top
    //Bottom
    //None
    //   Attr Name:   RadiusAtTipInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Radius at Tip (in)
    //   Description:   Radius at tip
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   8
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RadiusAtTipInInches;
    public double getRadiusAtTipInInches() throws Exception {
        return m_RadiusAtTipInInches;
    }

    public void setRadiusAtTipInInches(double value) throws Exception {
        m_RadiusAtTipInInches = value;
    }

    //   Attr Name:   RadiusAtBaseInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Radius at Base (in)
    //   Description:   Radius at base
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   8
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RadiusAtBaseInInches;
    public double getRadiusAtBaseInInches() throws Exception {
        return m_RadiusAtBaseInInches;
    }

    public void setRadiusAtBaseInInches(double value) throws Exception {
        m_RadiusAtBaseInInches = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Dimensions
    //   Alt Display Name:Segment Weight (lbs)
    //   Description:   Segment weight in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    public enum Shape_val
    {
        //   Attr Name:   Shape
        //   Attr Group:Section
        //   Description:   Cross section shape
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Round
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Polygonal  (Polygonal)
        Round,
        //Round
        Polygonal
    }
    //Polygonal
    private Shape_val m_Shape = Shape_val.Round;
    public Shape_val getShape() throws Exception {
        return m_Shape;
    }

    public void setShape(Shape_val value) throws Exception {
        m_Shape = value;
    }

    public Shape_val string_to_Shape_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Round"))
        {
            return Shape_val.Round;
        }
        else //Round
        if (__dummyScrutVar4.equals("Polygonal"))
        {
            return Shape_val.Polygonal;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Polygonal
    public String shape_val_to_String(Shape_val pKey) throws Exception {
        switch(pKey)
        {
            case Round: 
                return "Round";
            case Polygonal: 
                return "Polygonal";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Round
    //Polygonal
    //   Attr Name:   Faces
    //   Attr Group:Section
    //   Alt Display Name:Polygon Faces
    //   Description:   Number of polygon faces
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   PLUSMINUS
    //   Default Value:   8
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_Faces;
    public int getFaces() throws Exception {
        return m_Faces;
    }

    public void setFaces(int value) throws Exception {
        m_Faces = value;
    }

    //   Attr Name:   ThicknessTable
    //   Attr Group:Capacity
    //   Alt Display Name:Thickness
    //   Description:   The material thickness
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   THICKNESS_TABLE
    //   Default Value:   Thick;0,0.25;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_ThicknessTable = new ValTable();
    public ValTable getThicknessTable() throws Exception {
        return m_ThicknessTable;
    }

    public void setThicknessTable(ValTable value) throws Exception {
        m_ThicknessTable = value;
    }

    //   Attr Name:   Modulus of Elasticity
    //   Attr Group:Capacity
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   Modulus of elasticty for the material
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   1600000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Elasticity;
    public double getModulus_of_Elasticity() throws Exception {
        return m_Modulus_of_Elasticity;
    }

    public void setModulus_of_Elasticity(double value) throws Exception {
        m_Modulus_of_Elasticity = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Capacity
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.23
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Capacity
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Capacity
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000027
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   MomentCapacityTable
    //   Attr Group:Capacity
    //   Alt Display Name:Moment Cap (ft-lb)
    //   Description:   The moment capacity table
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   MOMENT_TABLE
    //   Default Value:   Moment;0,50000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_MomentCapacityTable = new ValTable();
    public ValTable getMomentCapacityTable() throws Exception {
        return m_MomentCapacityTable;
    }

    public void setMomentCapacityTable(ValTable value) throws Exception {
        m_MomentCapacityTable = value;
    }

    //   Attr Name:   BucklingCapacityTable
    //   Attr Group:Capacity
    //   Alt Display Name:Buckling Cap (lbs)
    //   Description:   The buckling capacity table
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BUCKLING_TABLE
    //   Default Value:   Buckling;0,5000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_BucklingCapacityTable = new ValTable();
    public ValTable getBucklingCapacityTable() throws Exception {
        return m_BucklingCapacityTable;
    }

    public void setBucklingCapacityTable(ValTable value) throws Exception {
        m_BucklingCapacityTable = value;
    }

    //   Attr Name:   MaterialTip
    //   Attr Group:Materials
    //   Alt Display Name:Material at Tip
    //   Description:   Material Tip
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <unset>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_MaterialTip;
    public String getMaterialTip() throws Exception {
        return m_MaterialTip;
    }

    public void setMaterialTip(String value) throws Exception {
        m_MaterialTip = value;
    }

    //   Attr Name:   MaterialBase
    //   Attr Group:Materials
    //   Alt Display Name:Material at Base
    //   Description:   Material Base
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <unset>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_MaterialBase;
    public String getMaterialBase() throws Exception {
        return m_MaterialBase;
    }

    public void setMaterialBase(String value) throws Exception {
        m_MaterialBase = value;
    }

    public enum Blend_by_val
    {
        //   Attr Name:   Blend by
        //   Attr Group:Materials
        //   Description:   Blending Function
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Radius  (Radius)
        //        Area  (Area)
        //        Area Squared  (Area Squared)
        Height,
        //Height
        Radius,
        //Radius
        Area,
        //Area
        Area_Squared
    }
    //Area Squared
    private Blend_by_val m_Blend_by = Blend_by_val.Height;
    public Blend_by_val getBlend_by() throws Exception {
        return m_Blend_by;
    }

    public void setBlend_by(Blend_by_val value) throws Exception {
        m_Blend_by = value;
    }

    public Blend_by_val string_to_Blend_by_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Height"))
        {
            return Blend_by_val.Height;
        }
        else //Height
        if (__dummyScrutVar6.equals("Radius"))
        {
            return Blend_by_val.Radius;
        }
        else //Radius
        if (__dummyScrutVar6.equals("Area"))
        {
            return Blend_by_val.Area;
        }
        else //Area
        if (__dummyScrutVar6.equals("Area Squared"))
        {
            return Blend_by_val.Area_Squared;
        }
        else
        {
        }    
        throw new Exception("string does not match enum value");
    }

    //Area Squared
    public String blend_by_val_to_String(Blend_by_val pKey) throws Exception {
        switch(pKey)
        {
            case Height: 
                return "Height";
            case Radius: 
                return "Radius";
            case Area: 
                return "Area";
            case Area_Squared: 
                return "Area Squared";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Height
    //Radius
    //Area
    //Area Squared
    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


