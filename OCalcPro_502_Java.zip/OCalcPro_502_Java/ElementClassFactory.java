//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:43 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import CS2JNet.System.StringSupport;
import PPL_Model_Wrapper.Anchor;
import PPL_Model_Wrapper.Beam;
import PPL_Model_Wrapper.BeamLoad;
import PPL_Model_Wrapper.CapacityAdjustment;
import PPL_Model_Wrapper.Clearance;
import PPL_Model_Wrapper.CompositePole;
import PPL_Model_Wrapper.ConcretePole;
import PPL_Model_Wrapper.Crossarm;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.GuyBrace;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LatticeGroup;
import PPL_Model_Wrapper.LatticeSection;
import PPL_Model_Wrapper.LatticeStructure;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.MultiPoleStructure;
import PPL_Model_Wrapper.Node;
import PPL_Model_Wrapper.NodeConstraint;
import PPL_Model_Wrapper.NodeJunction;
import PPL_Model_Wrapper.NodeLoad;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.PoleInfoPoint;
import PPL_Model_Wrapper.PoleRestoration;
import PPL_Model_Wrapper.PoleSegment;
import PPL_Model_Wrapper.PowerEquipment;
import PPL_Model_Wrapper.Riser;
import PPL_Model_Wrapper.Scene;
import PPL_Model_Wrapper.SegmentedPole;
import PPL_Model_Wrapper.Span;
import PPL_Model_Wrapper.SpanAddition;
import PPL_Model_Wrapper.SpanBundle;
import PPL_Model_Wrapper.SteelPole;
import PPL_Model_Wrapper.Streetlight;
import PPL_Model_Wrapper.Tap;
import PPL_Model_Wrapper.WoodPole;
import PPL_Model_Wrapper.WoodPoleDamageOrDecay;

public class ElementClassFactory   
{
    public static ElementBase build(String pKey) throws Exception {
        if (StringSupport.equals(pKey, "Scene"))
            return new Scene(true);
         
        if (StringSupport.equals(pKey, "LoadCase"))
            return new LoadCase(true);
         
        if (StringSupport.equals(pKey, "Notes"))
            return new Notes(true);
         
        if (StringSupport.equals(pKey, "LinkedURI"))
            return new LinkedURI(true);
         
        if (StringSupport.equals(pKey, "PoleInfoPoint"))
            return new PoleInfoPoint(true);
         
        if (StringSupport.equals(pKey, "PoleSegment"))
            return new PoleSegment(true);
         
        if (StringSupport.equals(pKey, "WoodPole"))
            return new WoodPole(true);
         
        if (StringSupport.equals(pKey, "SteelPole"))
            return new SteelPole(true);
         
        if (StringSupport.equals(pKey, "ConcretePole"))
            return new ConcretePole(true);
         
        if (StringSupport.equals(pKey, "CompositePole"))
            return new CompositePole(true);
         
        if (StringSupport.equals(pKey, "SegmentedPole"))
            return new SegmentedPole(true);
         
        if (StringSupport.equals(pKey, "Anchor"))
            return new Anchor(true);
         
        if (StringSupport.equals(pKey, "Crossarm"))
            return new Crossarm(true);
         
        if (StringSupport.equals(pKey, "Insulator"))
            return new Insulator(true);
         
        if (StringSupport.equals(pKey, "Span"))
            return new Span(true);
         
        if (StringSupport.equals(pKey, "SpanBundle"))
            return new SpanBundle(true);
         
        if (StringSupport.equals(pKey, "Tap"))
            return new Tap(true);
         
        if (StringSupport.equals(pKey, "PowerEquipment"))
            return new PowerEquipment(true);
         
        if (StringSupport.equals(pKey, "Streetlight"))
            return new Streetlight(true);
         
        if (StringSupport.equals(pKey, "GuyBrace"))
            return new GuyBrace(true);
         
        if (StringSupport.equals(pKey, "Riser"))
            return new Riser(true);
         
        if (StringSupport.equals(pKey, "GenericEquipment"))
            return new GenericEquipment(true);
         
        if (StringSupport.equals(pKey, "PoleRestoration"))
            return new PoleRestoration(true);
         
        if (StringSupport.equals(pKey, "Clearance"))
            return new Clearance(true);
         
        if (StringSupport.equals(pKey, "SpanAddition"))
            return new SpanAddition(true);
         
        if (StringSupport.equals(pKey, "WoodPoleDamageOrDecay"))
            return new WoodPoleDamageOrDecay(true);
         
        if (StringSupport.equals(pKey, "CapacityAdjustment"))
            return new CapacityAdjustment(true);
         
        if (StringSupport.equals(pKey, "MultiPoleStructure"))
            return new MultiPoleStructure(true);
         
        if (StringSupport.equals(pKey, "LatticeStructure"))
            return new LatticeStructure(true);
         
        if (StringSupport.equals(pKey, "LatticeSection"))
            return new LatticeSection(true);
         
        if (StringSupport.equals(pKey, "LatticeGroup"))
            return new LatticeGroup(true);
         
        if (StringSupport.equals(pKey, "Material"))
            return new Material(true);
         
        if (StringSupport.equals(pKey, "Node"))
            return new Node(true);
         
        if (StringSupport.equals(pKey, "NodeJunction"))
            return new NodeJunction(true);
         
        if (StringSupport.equals(pKey, "NodeConstraint"))
            return new NodeConstraint(true);
         
        if (StringSupport.equals(pKey, "NodeLoad"))
            return new NodeLoad(true);
         
        if (StringSupport.equals(pKey, "Beam"))
            return new Beam(true);
         
        if (StringSupport.equals(pKey, "BeamLoad"))
            return new BeamLoad(true);
         
        return null;
    }

}


