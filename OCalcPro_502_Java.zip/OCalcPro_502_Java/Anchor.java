//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GuyBrace;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Anchor
// Mirrors: PPLAnchor : PPLElement
//--------------------------------------------------------------------------------------------
public class Anchor  extends ElementBase 
{
    public static String gXMLkey = "Anchor";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Anchor(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Anchor";
            m_Owner = "<Undefined>";
            m_CoordinateZ = 0;
            m_CoordinateX = 381;
            m_CoordinateA = 1.5707963267949;
            m_DeltaHeight = 0;
            m_OffsetAngle = 0;
            m_RodDiameterInInches = 0.75;
            m_RodLengthAboveGLInInches = 30;
            m_RodDescription = "Joslyn Copperbonded 1in x 10ft Twineye";
            m_RodStrength = 45000;
            m_MergeAnchors = false;
            m_HoldingStrength = 20000;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof GuyBrace)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the anchor
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Anchor
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Height from GL (ft)
    //   Description:   The vertical distance from the butt of the pole to the anchor point
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:Lead Length (ft)
    //   Description:   The horizontal lead length from the pole to the anchor point
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   381
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Lead Angle (Â°)
    //   Description:   Lead Angle
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   1.5707963267949
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   DeltaHeight
    //   Attr Group:Standard
    //   Alt Display Name:Delta Height (ft)
    //   Description:   Delta Height
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DeltaHeight;
    public double getDeltaHeight() throws Exception {
        return m_DeltaHeight;
    }

    public void setDeltaHeight(double value) throws Exception {
        m_DeltaHeight = value;
    }

    //   Attr Name:   OffsetAngle
    //   Attr Group:Standard
    //   Alt Display Name:Offset Angle (Â°)
    //   Description:   Offset Angle
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OffsetAngle;
    public double getOffsetAngle() throws Exception {
        return m_OffsetAngle;
    }

    public void setOffsetAngle(double value) throws Exception {
        m_OffsetAngle = value;
    }

    //   Attr Name:   RodDiameterInInches
    //   Attr Group:Standard
    //   Alt Display Name:Rod Diameter (in)
    //   Description:   The diameter of the rod associated with this anchor
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.75
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RodDiameterInInches;
    public double getRodDiameterInInches() throws Exception {
        return m_RodDiameterInInches;
    }

    public void setRodDiameterInInches(double value) throws Exception {
        m_RodDiameterInInches = value;
    }

    //   Attr Name:   RodLengthAboveGLInInches
    //   Attr Group:Standard
    //   Alt Display Name:Rod Length AGL (in)
    //   Description:   The length of the rod associated with this anchor above GL
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   30
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RodLengthAboveGLInInches;
    public double getRodLengthAboveGLInInches() throws Exception {
        return m_RodLengthAboveGLInInches;
    }

    public void setRodLengthAboveGLInInches(double value) throws Exception {
        m_RodLengthAboveGLInInches = value;
    }

    //   Attr Name:   RodDescription
    //   Attr Group:Standard
    //   Alt Display Name:Rod Description
    //   Description:   Description of the rod used at the site of the anchor
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Joslyn Copperbonded 1in x 10ft Twineye
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_RodDescription;
    public String getRodDescription() throws Exception {
        return m_RodDescription;
    }

    public void setRodDescription(String value) throws Exception {
        m_RodDescription = value;
    }

    //   Attr Name:   RodStrength
    //   Attr Group:Standard
    //   Alt Display Name:Rod Strength (lbs)
    //   Description:   The strength of the rod in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RodStrength;
    public double getRodStrength() throws Exception {
        return m_RodStrength;
    }

    public void setRodStrength(double value) throws Exception {
        m_RodStrength = value;
    }

    //   Attr Name:   MergeAnchors
    //   Attr Group:Standard
    //   Alt Display Name:Merge Anchors
    //   Description:   Merge with anchors at same position,
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_MergeAnchors;
    public boolean getMergeAnchors() throws Exception {
        return m_MergeAnchors;
    }

    public void setMergeAnchors(boolean value) throws Exception {
        m_MergeAnchors = value;
    }

    public enum SoilClass_val
    {
        //   Attr Name:   SoilClass
        //   Attr Group:Standard
        //   Alt Display Name:Soil Class
        //   Description:   The class of soil at the site of the anchor
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Unset
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Class 1  (Very dense and/or cemented sands, coarse gravel and cobbles)
        //        Class 2  (Dense fine sand, very hard silts and clays (may be preloaded))
        //        Class 3  (Dense sands and gravel, hard silts and clays)
        //        Class 4  (Medium dense sandy gravel, very stiff to hard silts and clays)
        //        Class 5  (Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays)
        //        Class 6  (Loose to medium dense fine to coarse sand, firm to stiff clays and silts)
        //        Class 7  (Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill)
        //        Class 8  (Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays)
        //        Unsset  (Unset)
        Class_0,
        //Sound hard rock, bedrock, unweathered
        Class_1,
        //Very dense and/or cemented sands, coarse gravel and cobbles
        Class_2,
        //Dense fine sand, very hard silts and clays (may be preloaded)
        Class_3,
        //Dense sands and gravel, hard silts and clays
        Class_4,
        //Medium dense sandy gravel, very stiff to hard silts and clays
        Class_5,
        //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        Class_6,
        //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        Class_7,
        //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        Class_8,
        //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        Unsset
    }
    //Unset
    private SoilClass_val m_SoilClass = SoilClass_val.Class_0;
    public SoilClass_val getSoilClass() throws Exception {
        return m_SoilClass;
    }

    public void setSoilClass(SoilClass_val value) throws Exception {
        m_SoilClass = value;
    }

    public SoilClass_val string_to_SoilClass_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Class 0"))
        {
            return SoilClass_val.Class_0;
        }
        else //Sound hard rock, bedrock, unweathered
        if (__dummyScrutVar0.equals("Class 1"))
        {
            return SoilClass_val.Class_1;
        }
        else //Very dense and/or cemented sands, coarse gravel and cobbles
        if (__dummyScrutVar0.equals("Class 2"))
        {
            return SoilClass_val.Class_2;
        }
        else //Dense fine sand, very hard silts and clays (may be preloaded)
        if (__dummyScrutVar0.equals("Class 3"))
        {
            return SoilClass_val.Class_3;
        }
        else //Dense sands and gravel, hard silts and clays
        if (__dummyScrutVar0.equals("Class 4"))
        {
            return SoilClass_val.Class_4;
        }
        else //Medium dense sandy gravel, very stiff to hard silts and clays
        if (__dummyScrutVar0.equals("Class 5"))
        {
            return SoilClass_val.Class_5;
        }
        else //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        if (__dummyScrutVar0.equals("Class 6"))
        {
            return SoilClass_val.Class_6;
        }
        else //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        if (__dummyScrutVar0.equals("Class 7"))
        {
            return SoilClass_val.Class_7;
        }
        else //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        if (__dummyScrutVar0.equals("Class 8"))
        {
            return SoilClass_val.Class_8;
        }
        else //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        if (__dummyScrutVar0.equals("Unsset"))
        {
            return SoilClass_val.Unsset;
        }
        else
        {
        }          
        throw new Exception("string does not match enum value");
    }

    //Unset
    public String soilClass_val_to_String(SoilClass_val pKey) throws Exception {
        switch(pKey)
        {
            case Class_0: 
                return "Class 0";
            case Class_1: 
                return "Class 1";
            case Class_2: 
                return "Class 2";
            case Class_3: 
                return "Class 3";
            case Class_4: 
                return "Class 4";
            case Class_5: 
                return "Class 5";
            case Class_6: 
                return "Class 6";
            case Class_7: 
                return "Class 7";
            case Class_8: 
                return "Class 8";
            case Unsset: 
                return "Unsset";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Sound hard rock, bedrock, unweathered
    //Very dense and/or cemented sands, coarse gravel and cobbles
    //Dense fine sand, very hard silts and clays (may be preloaded)
    //Dense sands and gravel, hard silts and clays
    //Medium dense sandy gravel, very stiff to hard silts and clays
    //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
    //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
    //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
    //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
    //Unset
    //   Attr Name:   HoldingStrength
    //   Attr Group:Standard
    //   Alt Display Name:Holding Strength (lbs)
    //   Description:   The holding strength of anchor in pounds for the selected soil class
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   20000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HoldingStrength;
    public double getHoldingStrength() throws Exception {
        return m_HoldingStrength;
    }

    public void setHoldingStrength(double value) throws Exception {
        m_HoldingStrength = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


