//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.NodeConstraint;
import PPL_Model_Wrapper.NodeLoad;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Node
// Mirrors: PPLNode : PPLElement
//--------------------------------------------------------------------------------------------
public class Node  extends ElementBase 
{
    public static String gXMLkey = "Node";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Node(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Node";
            m_Name = "<tbd>";
            m_CoordinateX = 0;
            m_CoordinateY = 0;
            m_CoordinateZ = 0;
            m_NodeRadius = 0;
            m_ShearStrength = 45000;
            m_MergeNode = false;
            m_MergeTollerance = 2;
            m_OverrideRendering = false;
            m_NodeRenderDiam = 20;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof NodeConstraint)
            return true;
         
        if (pChildCandidate instanceof Insulator)
            return true;
         
        if (pChildCandidate instanceof NodeLoad)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the node
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Node
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the node
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <tbd>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:X Coord (ft)
    //   Description:   Node X relative to center
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   CoordinateY
    //   Attr Group:Standard
    //   Alt Display Name:Y Coord (ft)
    //   Description:   Node Y relative to center
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateY;
    public double getCoordinateY() throws Exception {
        return m_CoordinateY;
    }

    public void setCoordinateY(double value) throws Exception {
        m_CoordinateY = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Z Coord (ft)
    //   Description:   Node Z relative to section
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   NodeRadius
    //   Attr Group:Parameters
    //   Alt Display Name:Node Radius (in)
    //   Description:   Node radius (plate size)
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_NodeRadius;
    public double getNodeRadius() throws Exception {
        return m_NodeRadius;
    }

    public void setNodeRadius(double value) throws Exception {
        m_NodeRadius = value;
    }

    //   Attr Name:   ShearStrength
    //   Attr Group:Parameters
    //   Alt Display Name:Shear Strength (lbs)
    //   Description:   The shear strength of the node
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   45000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ShearStrength;
    public double getShearStrength() throws Exception {
        return m_ShearStrength;
    }

    public void setShearStrength(double value) throws Exception {
        m_ShearStrength = value;
    }

    //   Attr Name:   MergeNode
    //   Attr Group:Merge Nodes
    //   Alt Display Name:Merge Nodes
    //   Description:   Indicates if the node is to be merged with proximal nodes
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_MergeNode;
    public boolean getMergeNode() throws Exception {
        return m_MergeNode;
    }

    public void setMergeNode(boolean value) throws Exception {
        m_MergeNode = value;
    }

    //   Attr Name:   MergeTollerance
    //   Attr Group:Merge Nodes
    //   Alt Display Name:Merge Tollerance (in)
    //   Description:   Max distance node is to be merged with proximal nodes
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   2
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MergeTollerance;
    public double getMergeTollerance() throws Exception {
        return m_MergeTollerance;
    }

    public void setMergeTollerance(double value) throws Exception {
        m_MergeTollerance = value;
    }

    //   Attr Name:   OverrideRendering
    //   Attr Group:Rendering
    //   Alt Display Name:Override Rendering
    //   Description:   Indicates if the rendering is controlled by this section
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverrideRendering;
    public boolean getOverrideRendering() throws Exception {
        return m_OverrideRendering;
    }

    public void setOverrideRendering(boolean value) throws Exception {
        m_OverrideRendering = value;
    }

    //   Attr Name:   NodeRenderDiam
    //   Attr Group:Rendering
    //   Alt Display Name:Node Render (in)
    //   Description:   Node render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   20
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_NodeRenderDiam;
    public double getNodeRenderDiam() throws Exception {
        return m_NodeRenderDiam;
    }

    public void setNodeRenderDiam(double value) throws Exception {
        m_NodeRenderDiam = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


