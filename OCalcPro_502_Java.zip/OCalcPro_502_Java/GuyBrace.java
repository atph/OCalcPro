//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Clearance;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: GuyBrace
// Mirrors: PPLGuyBrace : PPLElement
//--------------------------------------------------------------------------------------------
public class GuyBrace  extends ElementBase 
{
    public static String gXMLkey = "GuyBrace";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public GuyBrace(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "";
            m_Owner = "<Undefined>";
            m_Type = Type_val.Down;
            m_CoordinateZ = 453;
            m_StrutHeightInInches = 405;
            m_StrutLengthInInches = 48;
            m_StrutDiameter = 1.25;
            m_StrutWeightPerIn = 0.189167;
            m_StrutCapacity = 2500;
            m_StrutBendingMomentMax = 800;
            m_StrutFixity = StrutFixity_val.Pinned;
            m_MergeStruts = false;
            m_DeltaHeightInInches = 0;
            m_Diameter = 0.5;
            m_PercentSolid = 1;
            m_PreTension = 700;
            m_VerticalOffset = 0;
            m_HorizontalOffset = 0;
            m_LateralOffset = 0;
            m_Tension_Mode = Tension_Mode_val.Calculated;
            m_Tension = 1500;
            m_RTS_Strength = 26900;
            m_PoundsPerInch = 0.03408;
            m_ModulusOfElasticity = 26000000;
            m_PoissonsRatio = 0.3;
            m_WindDragCoef = 0;
            m_ThermalCoefficient = 2.7E-06;
            m_GuyMaterial = "<Default>";
            m_StrutMaterial = "<Default>";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Clearance)
            return true;
         
        if (pChildCandidate instanceof Material)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Guy wire description
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Type
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Down
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Span/Head  (Span Guy)
        //        Sidewalk  (Sidewalk Guy)
        //        Crossarm  (Crossarm Guy)
        //        Pushbrace  (Pushbrace)
        Down,
        //Down Guy
        Span_Head,
        //Span Guy
        Sidewalk,
        //Sidewalk Guy
        Crossarm,
        //Crossarm Guy
        Pushbrace
    }
    //Pushbrace
    private Type_val m_Type = Type_val.Down;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Down"))
        {
            return Type_val.Down;
        }
        else //Down Guy
        if (__dummyScrutVar0.equals("Span/Head"))
        {
            return Type_val.Span_Head;
        }
        else //Span Guy
        if (__dummyScrutVar0.equals("Sidewalk"))
        {
            return Type_val.Sidewalk;
        }
        else //Sidewalk Guy
        if (__dummyScrutVar0.equals("Crossarm"))
        {
            return Type_val.Crossarm;
        }
        else //Crossarm Guy
        if (__dummyScrutVar0.equals("Pushbrace"))
        {
            return Type_val.Pushbrace;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Pushbrace
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Down: 
                return "Down";
            case Span_Head: 
                return "Span/Head";
            case Sidewalk: 
                return "Sidewalk";
            case Crossarm: 
                return "Crossarm";
            case Pushbrace: 
                return "Pushbrace";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Down Guy
    //Span Guy
    //Sidewalk Guy
    //Crossarm Guy
    //Pushbrace
    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   453
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   StrutHeightInInches
    //   Attr Group:Sidewalk
    //   Alt Display Name:Strut Height (ft)
    //   Description:   Height of the strut from groundline if it is a sidewalk guy
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   405
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutHeightInInches;
    public double getStrutHeightInInches() throws Exception {
        return m_StrutHeightInInches;
    }

    public void setStrutHeightInInches(double value) throws Exception {
        m_StrutHeightInInches = value;
    }

    //   Attr Name:   StrutLengthInInches
    //   Attr Group:Sidewalk
    //   Alt Display Name:Strut Length (ft)
    //   Description:   The length of the strut if it is a sidewalk guy
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   48
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutLengthInInches;
    public double getStrutLengthInInches() throws Exception {
        return m_StrutLengthInInches;
    }

    public void setStrutLengthInInches(double value) throws Exception {
        m_StrutLengthInInches = value;
    }

    //   Attr Name:   StrutDiameter
    //   Attr Group:Sidewalk
    //   Alt Display Name:Strut Diameter (in)
    //   Description:   The diameter of the strut
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   1.25
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutDiameter;
    public double getStrutDiameter() throws Exception {
        return m_StrutDiameter;
    }

    public void setStrutDiameter(double value) throws Exception {
        m_StrutDiameter = value;
    }

    //   Attr Name:   StrutWeightPerIn
    //   Attr Group:Sidewalk
    //   Alt Display Name:Strut Weight/Len (lbs/ft)
    //   Description:   The weight of the strut in lbs per unit length
    //   Displayed Units:   store as POUNDS PER IN display as POUNDS PER FT or KILOGRAMS PER METER
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.189167
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutWeightPerIn;
    public double getStrutWeightPerIn() throws Exception {
        return m_StrutWeightPerIn;
    }

    public void setStrutWeightPerIn(double value) throws Exception {
        m_StrutWeightPerIn = value;
    }

    //   Attr Name:   StrutCapacity
    //   Attr Group:Sidewalk
    //   Alt Display Name:Allowable Strut Load (lbs)
    //   Description:   The capacity of the strut in lbs
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   FLOAT
    //   Default Value:   2500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutCapacity;
    public double getStrutCapacity() throws Exception {
        return m_StrutCapacity;
    }

    public void setStrutCapacity(double value) throws Exception {
        m_StrutCapacity = value;
    }

    //   Attr Name:   StrutBendingMomentMax
    //   Attr Group:Sidewalk
    //   Alt Display Name:Max Strut Moment Cap (ft-lbs)
    //   Description:   The bending moment capacity of the strut in ft-lbs
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   800
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrutBendingMomentMax;
    public double getStrutBendingMomentMax() throws Exception {
        return m_StrutBendingMomentMax;
    }

    public void setStrutBendingMomentMax(double value) throws Exception {
        m_StrutBendingMomentMax = value;
    }

    public enum StrutFixity_val
    {
        //   Attr Name:   StrutFixity
        //   Attr Group:Sidewalk
        //   Alt Display Name:Strut Fixity
        //   Description:   The fixity of the strut
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Pinned
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Pinned  (Strut Pinned)
        Fixed,
        //Strut Fixed
        Pinned
    }
    //Strut Pinned
    private StrutFixity_val m_StrutFixity = StrutFixity_val.Fixed;
    public StrutFixity_val getStrutFixity() throws Exception {
        return m_StrutFixity;
    }

    public void setStrutFixity(StrutFixity_val value) throws Exception {
        m_StrutFixity = value;
    }

    public StrutFixity_val string_to_StrutFixity_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Fixed"))
        {
            return StrutFixity_val.Fixed;
        }
        else //Strut Fixed
        if (__dummyScrutVar2.equals("Pinned"))
        {
            return StrutFixity_val.Pinned;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Strut Pinned
    public String strutFixity_val_to_String(StrutFixity_val pKey) throws Exception {
        switch(pKey)
        {
            case Fixed: 
                return "Fixed";
            case Pinned: 
                return "Pinned";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Strut Fixed
    //Strut Pinned
    //   Attr Name:   MergeStruts
    //   Attr Group:Sidewalk
    //   Alt Display Name:Merge Like Struts
    //   Description:   Merge with like struts at same position,
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_MergeStruts;
    public boolean getMergeStruts() throws Exception {
        return m_MergeStruts;
    }

    public void setMergeStruts(boolean value) throws Exception {
        m_MergeStruts = value;
    }

    //   Attr Name:   DeltaHeightInInches
    //   Attr Group:Standard
    //   Alt Display Name:Span Guy DeltaHt (ft)
    //   Description:   Difference in height of the far end if it is a span guy
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_DeltaHeightInInches;
    public double getDeltaHeightInInches() throws Exception {
        return m_DeltaHeightInInches;
    }

    public void setDeltaHeightInInches(double value) throws Exception {
        m_DeltaHeightInInches = value;
    }

    //   Attr Name:   Diameter
    //   Attr Group:Standard
    //   Alt Display Name:Diameter (in)
    //   Description:   Guy wire diameter in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Diameter;
    public double getDiameter() throws Exception {
        return m_Diameter;
    }

    public void setDiameter(double value) throws Exception {
        m_Diameter = value;
    }

    //   Attr Name:   PercentSolid
    //   Attr Group:Standard
    //   Alt Display Name:Percent Solid
    //   Description:   Percent Solid
    //   Displayed Units:   store as PERCENT 0 TO 1 display as PERCENT 0 TO 100
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PercentSolid;
    public double getPercentSolid() throws Exception {
        return m_PercentSolid;
    }

    public void setPercentSolid(double value) throws Exception {
        m_PercentSolid = value;
    }

    //   Attr Name:   PreTension
    //   Attr Group:Standard
    //   Alt Display Name:Pre-tension (lbs)
    //   Description:   Pre-tension in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   700
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PreTension;
    public double getPreTension() throws Exception {
        return m_PreTension;
    }

    public void setPreTension(double value) throws Exception {
        m_PreTension = value;
    }

    //   Attr Name:   VerticalOffset
    //   Attr Group:Control
    //   Alt Display Name:Vertical Offset (in)
    //   Description:   Vertical Offset in Inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_VerticalOffset;
    public double getVerticalOffset() throws Exception {
        return m_VerticalOffset;
    }

    public void setVerticalOffset(double value) throws Exception {
        m_VerticalOffset = value;
    }

    //   Attr Name:   HorizontalOffset
    //   Attr Group:Control
    //   Alt Display Name:Horizontal Offset (in)
    //   Description:   Horizontal Offset in Inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_HorizontalOffset;
    public double getHorizontalOffset() throws Exception {
        return m_HorizontalOffset;
    }

    public void setHorizontalOffset(double value) throws Exception {
        m_HorizontalOffset = value;
    }

    //   Attr Name:   LateralOffset
    //   Attr Group:Control
    //   Alt Display Name:Lateral Offset (in)
    //   Description:   LateralOffset Offset in Inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LateralOffset;
    public double getLateralOffset() throws Exception {
        return m_LateralOffset;
    }

    public void setLateralOffset(double value) throws Exception {
        m_LateralOffset = value;
    }

    public enum Tension_Mode_val
    {
        //   Attr Name:   Tension Mode
        //   Attr Group:Control
        //   Description:   Tension mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Calculated
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Manual  (Manual)
        Calculated,
        //Calculated
        Manual
    }
    //Manual
    private Tension_Mode_val m_Tension_Mode = Tension_Mode_val.Calculated;
    public Tension_Mode_val getTension_Mode() throws Exception {
        return m_Tension_Mode;
    }

    public void setTension_Mode(Tension_Mode_val value) throws Exception {
        m_Tension_Mode = value;
    }

    public Tension_Mode_val string_to_Tension_Mode_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Calculated"))
        {
            return Tension_Mode_val.Calculated;
        }
        else //Calculated
        if (__dummyScrutVar4.equals("Manual"))
        {
            return Tension_Mode_val.Manual;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Manual
    public String tension_Mode_val_to_String(Tension_Mode_val pKey) throws Exception {
        switch(pKey)
        {
            case Calculated: 
                return "Calculated";
            case Manual: 
                return "Manual";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Calculated
    //Manual
    //   Attr Name:   Tension
    //   Attr Group:Control
    //   Alt Display Name:Man Tension (lbs)
    //   Description:   Tension in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   1500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Tension;
    public double getTension() throws Exception {
        return m_Tension;
    }

    public void setTension(double value) throws Exception {
        m_Tension = value;
    }

    //   Attr Name:   RTS Strength
    //   Attr Group:Standard
    //   Alt Display Name:Strength (lbs)
    //   Description:   RTS Strength in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   26900
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RTS_Strength;
    public double getRTS_Strength() throws Exception {
        return m_RTS_Strength;
    }

    public void setRTS_Strength(double value) throws Exception {
        m_RTS_Strength = value;
    }

    //   Attr Name:   PoundsPerInch
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Weight (lbs/ft)
    //   Description:   Linear weight in pounds per inch of length
    //   Displayed Units:   store as POUNDS PER IN display as POUNDS PER FT or KILOGRAMS PER METER
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.03408
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoundsPerInch;
    public double getPoundsPerInch() throws Exception {
        return m_PoundsPerInch;
    }

    public void setPoundsPerInch(double value) throws Exception {
        m_PoundsPerInch = value;
    }

    //   Attr Name:   ModulusOfElasticity
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   ModulusOfElasticity
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Administrative access only
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   26000000
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ModulusOfElasticity;
    public double getModulusOfElasticity() throws Exception {
        return m_ModulusOfElasticity;
    }

    public void setModulusOfElasticity(double value) throws Exception {
        m_ModulusOfElasticity = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.3
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000027
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   GuyMaterial
    //   Attr Group:Material Override
    //   Alt Display Name:Guy Material
    //   Description:   Guy Material
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <Default>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_GuyMaterial;
    public String getGuyMaterial() throws Exception {
        return m_GuyMaterial;
    }

    public void setGuyMaterial(String value) throws Exception {
        m_GuyMaterial = value;
    }

    //   Attr Name:   StrutMaterial
    //   Attr Group:Material Override
    //   Alt Display Name:Strut Material
    //   Description:   Strut Material
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <Default>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_StrutMaterial;
    public String getStrutMaterial() throws Exception {
        return m_StrutMaterial;
    }

    public void setStrutMaterial(String value) throws Exception {
        m_StrutMaterial = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


