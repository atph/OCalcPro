//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: PowerEquipment
// Mirrors: PPLTransformer : PPLElement
//--------------------------------------------------------------------------------------------
public class PowerEquipment  extends ElementBase 
{
    public static String gXMLkey = "PowerEquipment";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public PowerEquipment(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_CoordinateX = 10;
            m_Description = "1PH- 25KVA";
            m_Owner = "<Undefined>";
            m_CoordinateZ = 420;
            m_CoordinateA = 0;
            m_Pole_Gap = 6;
            m_Type = Type_val.Transformer;
            m_Mount = Mount_val.Pole;
            m_Qty = 1;
            m_Array_Angle = 1.5707963267949;
            m_Rack_Spacing = 0;
            m_DiameterInInches = 22;
            m_HeightInInches = 39;
            m_DepthInInches = 39;
            m_Weight = 365;
            m_WindDragCoef = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:Pole Radius at Height (in)
    //   Description:   Internal attribute which holds the radius of the pole at the given height.
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description or Transformer Catalog name
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   1PH- 25KVA
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:   The distance in inches from the butt of the pole to the center of the transformer can
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   420
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   Angle of bank relative to the parent structure (typically pole)
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   Pole Gap
    //   Attr Group:Standard
    //   Alt Display Name:Gap (in)
    //   Description:   Distance between pole and can in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   6
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Pole_Gap;
    public double getPole_Gap() throws Exception {
        return m_Pole_Gap;
    }

    public void setPole_Gap(double value) throws Exception {
        m_Pole_Gap = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Equipment Type
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Transformer
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Regulator  (Voltage Regulator)
        //        Capacitor  (Capacitor)
        //        Switch  (Switch)
        //        Fuse  (Switch)
        //        Box  (Misc Box)
        Transformer,
        //Transformer
        Regulator,
        //Voltage Regulator
        Capacitor,
        //Capacitor
        Switch,
        //Switch
        Fuse,
        //Switch
        Box
    }
    //Misc Box
    private Type_val m_Type = Type_val.Transformer;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Transformer"))
        {
            return Type_val.Transformer;
        }
        else //Transformer
        if (__dummyScrutVar0.equals("Regulator"))
        {
            return Type_val.Regulator;
        }
        else //Voltage Regulator
        if (__dummyScrutVar0.equals("Capacitor"))
        {
            return Type_val.Capacitor;
        }
        else //Capacitor
        if (__dummyScrutVar0.equals("Switch"))
        {
            return Type_val.Switch;
        }
        else //Switch
        if (__dummyScrutVar0.equals("Fuse"))
        {
            return Type_val.Fuse;
        }
        else //Switch
        if (__dummyScrutVar0.equals("Box"))
        {
            return Type_val.Box;
        }
        else
        {
        }      
        throw new Exception("string does not match enum value");
    }

    //Misc Box
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Transformer: 
                return "Transformer";
            case Regulator: 
                return "Regulator";
            case Capacitor: 
                return "Capacitor";
            case Switch: 
                return "Switch";
            case Fuse: 
                return "Fuse";
            case Box: 
                return "Box";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Transformer
    //Voltage Regulator
    //Capacitor
    //Switch
    //Switch
    //Misc Box
    public enum Mount_val
    {
        //   Attr Name:   Mount
        //   Attr Group:Standard
        //   Description:   The type of mount used to install the equipment
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Pole
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Rack  (Equipment are mounted on a rack which is mounted to the pole)
        Pole,
        //Standard pole bank mount
        Rack
    }
    //Equipment are mounted on a rack which is mounted to the pole
    private Mount_val m_Mount = Mount_val.Pole;
    public Mount_val getMount() throws Exception {
        return m_Mount;
    }

    public void setMount(Mount_val value) throws Exception {
        m_Mount = value;
    }

    public Mount_val string_to_Mount_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Pole"))
        {
            return Mount_val.Pole;
        }
        else //Standard pole bank mount
        if (__dummyScrutVar2.equals("Rack"))
        {
            return Mount_val.Rack;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Equipment are mounted on a rack which is mounted to the pole
    public String mount_val_to_String(Mount_val pKey) throws Exception {
        switch(pKey)
        {
            case Pole: 
                return "Pole";
            case Rack: 
                return "Rack";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Standard pole bank mount
    //Equipment are mounted on a rack which is mounted to the pole
    //   Attr Name:   Qty
    //   Attr Group:Standard
    //   Alt Display Name:Unit Count
    //   Description:   Number of units
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   PLUSMINUS
    //   Default Value:   1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_Qty;
    public int getQty() throws Exception {
        return m_Qty;
    }

    public void setQty(int value) throws Exception {
        m_Qty = value;
    }

    //   Attr Name:   Array Angle
    //   Attr Group:Standard
    //   Alt Display Name:Unit Spacing (Â°)
    //   Description:   Angle between cans
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   1.5707963267949
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Array_Angle;
    public double getArray_Angle() throws Exception {
        return m_Array_Angle;
    }

    public void setArray_Angle(double value) throws Exception {
        m_Array_Angle = value;
    }

    //   Attr Name:   Rack Spacing
    //   Attr Group:Standard
    //   Alt Display Name:Rack Spacing (in)
    //   Description:   The distance between items on a rack
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Rack_Spacing;
    public double getRack_Spacing() throws Exception {
        return m_Rack_Spacing;
    }

    public void setRack_Spacing(double value) throws Exception {
        m_Rack_Spacing = value;
    }

    //   Attr Name:   DiameterInInches
    //   Attr Group:Standard
    //   Alt Display Name:Unit Diameter/Width (in)
    //   Description:   The Diameter of the transformer can in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   22
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DiameterInInches;
    public double getDiameterInInches() throws Exception {
        return m_DiameterInInches;
    }

    public void setDiameterInInches(double value) throws Exception {
        m_DiameterInInches = value;
    }

    //   Attr Name:   HeightInInches
    //   Attr Group:Standard
    //   Alt Display Name:Unit Height (in)
    //   Description:   The Height of the transformer can in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   39
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HeightInInches;
    public double getHeightInInches() throws Exception {
        return m_HeightInInches;
    }

    public void setHeightInInches(double value) throws Exception {
        m_HeightInInches = value;
    }

    //   Attr Name:   DepthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Unit Depth (in)
    //   Description:   The Depth of the transformer can in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   39
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DepthInInches;
    public double getDepthInInches() throws Exception {
        return m_DepthInInches;
    }

    public void setDepthInInches(double value) throws Exception {
        m_DepthInInches = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Standard
    //   Alt Display Name:Unit Weight (lbs)
    //   Description:   The weight of each individual transformer can in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   365.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Standard
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


