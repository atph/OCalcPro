//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.BeamLoad;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Beam
// Mirrors: PPLBeam : PPLElement
//--------------------------------------------------------------------------------------------
public class Beam  extends ElementBase 
{
    public static String gXMLkey = "Beam";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Beam(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Beam Element";
            m_Name = "<tbd>";
            m_Node1 = "<node 1>";
            m_Node2 = "<node 1>";
            m_Material = "<material>";
            m_Mode = Mode_val.Standard;
            m_BeamType = BeamType_val.Frame;
            m_OverrideRendering = false;
            m_BeamRenderDiam = 12;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof BeamLoad)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the beam
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Beam Element
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the beam
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <tbd>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   Node1
    //   Attr Group:Standard
    //   Alt Display Name:Node 1
    //   Description:   Node 1
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <node 1>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Node1;
    public String getNode1() throws Exception {
        return m_Node1;
    }

    public void setNode1(String value) throws Exception {
        m_Node1 = value;
    }

    //   Attr Name:   Node2
    //   Attr Group:Standard
    //   Alt Display Name:Node 2
    //   Description:   Node 2
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <node 1>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Node2;
    public String getNode2() throws Exception {
        return m_Node2;
    }

    public void setNode2(String value) throws Exception {
        m_Node2 = value;
    }

    //   Attr Name:   Material
    //   Attr Group:Standard
    //   Description:   Material
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <material>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Material;
    public String getMaterial() throws Exception {
        return m_Material;
    }

    public void setMaterial(String value) throws Exception {
        m_Material = value;
    }

    public enum Mode_val
    {
        //   Attr Name:   Mode
        //   Attr Group:Standard
        //   Description:   Capacity Mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Standard
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Compression Only  (Compression Only)
        //        Tension Only  (Tension Only)
        Standard,
        //Standard
        Compression_Only,
        //Compression Only
        Tension_Only
    }
    //Tension Only
    private Mode_val m_Mode = Mode_val.Standard;
    public Mode_val getMode() throws Exception {
        return m_Mode;
    }

    public void setMode(Mode_val value) throws Exception {
        m_Mode = value;
    }

    public Mode_val string_to_Mode_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Standard"))
        {
            return Mode_val.Standard;
        }
        else //Standard
        if (__dummyScrutVar0.equals("Compression Only"))
        {
            return Mode_val.Compression_Only;
        }
        else //Compression Only
        if (__dummyScrutVar0.equals("Tension Only"))
        {
            return Mode_val.Tension_Only;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Tension Only
    public String mode_val_to_String(Mode_val pKey) throws Exception {
        switch(pKey)
        {
            case Standard: 
                return "Standard";
            case Compression_Only: 
                return "Compression Only";
            case Tension_Only: 
                return "Tension Only";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Standard
    //Compression Only
    //Tension Only
    public enum BeamType_val
    {
        //   Attr Name:   BeamType
        //   Attr Group:Standard
        //   Alt Display Name:Type
        //   Description:   Beam Type
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Frame
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Truss  (Truss)
        Frame,
        //Frame
        Truss
    }
    //Truss
    private BeamType_val m_BeamType = BeamType_val.Frame;
    public BeamType_val getBeamType() throws Exception {
        return m_BeamType;
    }

    public void setBeamType(BeamType_val value) throws Exception {
        m_BeamType = value;
    }

    public BeamType_val string_to_BeamType_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Frame"))
        {
            return BeamType_val.Frame;
        }
        else //Frame
        if (__dummyScrutVar2.equals("Truss"))
        {
            return BeamType_val.Truss;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Truss
    public String beamType_val_to_String(BeamType_val pKey) throws Exception {
        switch(pKey)
        {
            case Frame: 
                return "Frame";
            case Truss: 
                return "Truss";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Frame
    //Truss
    //   Attr Name:   OverrideRendering
    //   Attr Group:Rendering
    //   Alt Display Name:Override Rendering
    //   Description:   Indicates if the rendering is controlled by this section
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverrideRendering;
    public boolean getOverrideRendering() throws Exception {
        return m_OverrideRendering;
    }

    public void setOverrideRendering(boolean value) throws Exception {
        m_OverrideRendering = value;
    }

    //   Attr Name:   BeamRenderDiam
    //   Attr Group:Rendering
    //   Alt Display Name:Beam Render (in)
    //   Description:   Node render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BeamRenderDiam;
    public double getBeamRenderDiam() throws Exception {
        return m_BeamRenderDiam;
    }

    public void setBeamRenderDiam(double value) throws Exception {
        m_BeamRenderDiam = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


