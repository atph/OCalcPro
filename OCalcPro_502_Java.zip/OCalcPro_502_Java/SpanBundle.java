//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Clearance;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.Span;
import PPL_Model_Wrapper.ValTable;

//--------------------------------------------------------------------------------------------
//   Class: SpanBundle
// Mirrors: PPLSpanBundle : PPLElement
//--------------------------------------------------------------------------------------------
public class SpanBundle  extends ElementBase 
{
    public static String gXMLkey = "SpanBundle";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public SpanBundle(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_CoordinateX = 0;
            m_CoordinateZ = 0;
            m_Owner = "<Undefined>";
            m_Type = "Bundle";
            m_Construction = Construction_val.Overlashed;
            m_BundleIceMode = BundleIceMode_val.Individual;
            m_BundleWindMode = BundleWindMode_val.Individual;
            m_CoordinateA = 0;
            m_SpanDistanceInInches = 600;
            m_SpanEndHeightDelta = 0;
            m_MidspanDeflection = 0;
            m_Tension_Type = Tension_Type_val.Static;
            m_Tension = 0;
            m_TensionTable = new ValTable("Tension;0,500;");
            m_SlackTension = 10;
            m_RatedStrength = 5000;
            m_ConductorDiameter = 0.5;
            m_OverrideTemp = false;
            m_Temperature = 65;
            m_TempMin = 32;
            m_TempMax = 212;
            m_PoundsPerInch = 0.0076;
            m_ModulusOfElasticity = 11200000;
            m_PercentSolid = 0.75;
            m_ThermalCoefficient = 1.06E-05;
            m_CreepCoefficient = 0;
            m_IceAccumulationFactor = 0.75;
            m_WindTensionFactor = -1;
            m_WindDragCoef = 0;
            m_VerticalOffset = 0;
            m_HorizontalOffset = 0;
            m_StopAtTap = false;
            m_HasInlineBox = false;
            m_BoxOffset = 15;
            m_BoxLength = 20;
            m_BoxDiameter = 8;
            m_BoxWeight = 5;
            m_HasDripLoop = false;
            m_DripLoopOffset = 2;
            m_DripLoopLength = 20;
            m_DripLoopHeight = 10;
            m_Modifier = Modifier_val.None;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Span)
            return true;
         
        if (pChildCandidate instanceof Clearance)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Description:   The X coordinate relative to parent.  SnapToParent will set the value
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Description:   The Z coordinate relative to parent.  SnapToParent will set the value
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   Type
    //   Attr Group:Standard
    //   Alt Display Name:Description
    //   Description:   The name, type, material, code, or other designation assigned to this span type by the owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Bundle
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Type;
    public String getType() throws Exception {
        return m_Type;
    }

    public void setType(String value) throws Exception {
        m_Type = value;
    }

    public enum Construction_val
    {
        //   Attr Name:   Construction
        //   Attr Group:Standard
        //   Alt Display Name:Bundle Type
        //   Description:   Bundle Construction
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Overlashed
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Spacers  (Spacers)
        //        Bonded  (Bonded)
        //        Twist/Braid  (Twist/Braid)
        //        Wrapped  (Wrapped)
        //        Other  (Other)
        Overlashed,
        //Overlashed
        Spacers,
        //Spacers
        Bonded,
        //Bonded
        Twist_Braid,
        //Twist/Braid
        Wrapped,
        //Wrapped
        Other
    }
    //Other
    private Construction_val m_Construction = Construction_val.Overlashed;
    public Construction_val getConstruction() throws Exception {
        return m_Construction;
    }

    public void setConstruction(Construction_val value) throws Exception {
        m_Construction = value;
    }

    public Construction_val string_to_Construction_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Overlashed"))
        {
            return Construction_val.Overlashed;
        }
        else //Overlashed
        if (__dummyScrutVar0.equals("Spacers"))
        {
            return Construction_val.Spacers;
        }
        else //Spacers
        if (__dummyScrutVar0.equals("Bonded"))
        {
            return Construction_val.Bonded;
        }
        else //Bonded
        if (__dummyScrutVar0.equals("Twist/Braid"))
        {
            return Construction_val.Twist_Braid;
        }
        else //Twist/Braid
        if (__dummyScrutVar0.equals("Wrapped"))
        {
            return Construction_val.Wrapped;
        }
        else //Wrapped
        if (__dummyScrutVar0.equals("Other"))
        {
            return Construction_val.Other;
        }
        else
        {
        }      
        throw new Exception("string does not match enum value");
    }

    //Other
    public String construction_val_to_String(Construction_val pKey) throws Exception {
        switch(pKey)
        {
            case Overlashed: 
                return "Overlashed";
            case Spacers: 
                return "Spacers";
            case Bonded: 
                return "Bonded";
            case Twist_Braid: 
                return "Twist/Braid";
            case Wrapped: 
                return "Wrapped";
            case Other: 
                return "Other";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Overlashed
    //Spacers
    //Bonded
    //Twist/Braid
    //Wrapped
    //Other
    public enum BundleIceMode_val
    {
        //   Attr Name:   BundleIceMode
        //   Attr Group:Bundle Ice/Wind
        //   Alt Display Name:Bundle Ice Mode
        //   Description:   Geometry for ice accumulation
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Individual
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Min Circle  (Min Circle)
        //        Convex Hull  (Convex Hull)
        //        Concave Hull  (Concave Hull)
        Individual,
        //Individual
        Min_Circle,
        //Min Circle
        Convex_Hull,
        //Convex Hull
        Concave_Hull
    }
    //Concave Hull
    private BundleIceMode_val m_BundleIceMode = BundleIceMode_val.Individual;
    public BundleIceMode_val getBundleIceMode() throws Exception {
        return m_BundleIceMode;
    }

    public void setBundleIceMode(BundleIceMode_val value) throws Exception {
        m_BundleIceMode = value;
    }

    public BundleIceMode_val string_to_BundleIceMode_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Individual"))
        {
            return BundleIceMode_val.Individual;
        }
        else //Individual
        if (__dummyScrutVar2.equals("Min Circle"))
        {
            return BundleIceMode_val.Min_Circle;
        }
        else //Min Circle
        if (__dummyScrutVar2.equals("Convex Hull"))
        {
            return BundleIceMode_val.Convex_Hull;
        }
        else //Convex Hull
        if (__dummyScrutVar2.equals("Concave Hull"))
        {
            return BundleIceMode_val.Concave_Hull;
        }
        else
        {
        }    
        throw new Exception("string does not match enum value");
    }

    //Concave Hull
    public String bundleIceMode_val_to_String(BundleIceMode_val pKey) throws Exception {
        switch(pKey)
        {
            case Individual: 
                return "Individual";
            case Min_Circle: 
                return "Min Circle";
            case Convex_Hull: 
                return "Convex Hull";
            case Concave_Hull: 
                return "Concave Hull";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Individual
    //Min Circle
    //Convex Hull
    //Concave Hull
    public enum BundleWindMode_val
    {
        //   Attr Name:   BundleWindMode
        //   Attr Group:Bundle Ice/Wind
        //   Alt Display Name:Bundle Wind Mode
        //   Description:   Geometry for wind area
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Individual
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Min Circle  (Min Circle)
        //        Convex Hull  (Convex Hull)
        //        Concave Hull  (Concave Hull)
        Individual,
        //Individual
        Min_Circle,
        //Min Circle
        Convex_Hull,
        //Convex Hull
        Concave_Hull
    }
    //Concave Hull
    private BundleWindMode_val m_BundleWindMode = BundleWindMode_val.Individual;
    public BundleWindMode_val getBundleWindMode() throws Exception {
        return m_BundleWindMode;
    }

    public void setBundleWindMode(BundleWindMode_val value) throws Exception {
        m_BundleWindMode = value;
    }

    public BundleWindMode_val string_to_BundleWindMode_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Individual"))
        {
            return BundleWindMode_val.Individual;
        }
        else //Individual
        if (__dummyScrutVar4.equals("Min Circle"))
        {
            return BundleWindMode_val.Min_Circle;
        }
        else //Min Circle
        if (__dummyScrutVar4.equals("Convex Hull"))
        {
            return BundleWindMode_val.Convex_Hull;
        }
        else //Convex Hull
        if (__dummyScrutVar4.equals("Concave Hull"))
        {
            return BundleWindMode_val.Concave_Hull;
        }
        else
        {
        }    
        throw new Exception("string does not match enum value");
    }

    //Concave Hull
    public String bundleWindMode_val_to_String(BundleWindMode_val pKey) throws Exception {
        switch(pKey)
        {
            case Individual: 
                return "Individual";
            case Min_Circle: 
                return "Min Circle";
            case Convex_Hull: 
                return "Convex Hull";
            case Concave_Hull: 
                return "Concave Hull";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Individual
    //Min Circle
    //Convex Hull
    //Concave Hull
    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The relative angle between this span its proximal connection at it's parent insulator or other holding structure
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   SpanDistanceInInches
    //   Attr Group:Standard
    //   Alt Display Name:Span Length (ft)
    //   Description:   The horizontal component of the distance between the proximal and distal ends of the span
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   600.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_SpanDistanceInInches;
    public double getSpanDistanceInInches() throws Exception {
        return m_SpanDistanceInInches;
    }

    public void setSpanDistanceInInches(double value) throws Exception {
        m_SpanDistanceInInches = value;
    }

    //   Attr Name:   SpanEndHeightDelta
    //   Attr Group:Standard
    //   Alt Display Name:End Drop/Rise (ft)
    //   Description:   The vertical component of the distance between the proximal and distal ends of the span
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_SpanEndHeightDelta;
    public double getSpanEndHeightDelta() throws Exception {
        return m_SpanEndHeightDelta;
    }

    public void setSpanEndHeightDelta(double value) throws Exception {
        m_SpanEndHeightDelta = value;
    }

    //   Attr Name:   MidspanDeflection
    //   Attr Group:Tension Sag
    //   Alt Display Name:Span Sag (ft)
    //   Description:   The vertical deflection between the proximal end of the span an the maximum deflection point of the catenary curve
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_MidspanDeflection;
    public double getMidspanDeflection() throws Exception {
        return m_MidspanDeflection;
    }

    public void setMidspanDeflection(double value) throws Exception {
        m_MidspanDeflection = value;
    }

    public enum Tension_Type_val
    {
        //   Attr Name:   Tension Type
        //   Attr Group:Tension Sag
        //   Description:   Is the tension value calculated or static
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Static
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Slack  (The tension is a static slack constant supplied by the operator or other data source)
        //        Table  (The tension is a table supplied by the operator or other data source)
        //        Sag to Tension  (The tension is calculated based on the values entered for sag, weight, and LoadCase)
        //        Tension to Sag  (The tension is based on initial stringing tension and LoadCase)
        Static,
        //The tension is a static normal constant supplied by the operator or other data source
        Slack,
        //The tension is a static slack constant supplied by the operator or other data source
        Table,
        //The tension is a table supplied by the operator or other data source
        Sag_to_Tension,
        //The tension is calculated based on the values entered for sag, weight, and LoadCase
        Tension_to_Sag
    }
    //The tension is based on initial stringing tension and LoadCase
    private Tension_Type_val m_Tension_Type = Tension_Type_val.Static;
    public Tension_Type_val getTension_Type() throws Exception {
        return m_Tension_Type;
    }

    public void setTension_Type(Tension_Type_val value) throws Exception {
        m_Tension_Type = value;
    }

    public Tension_Type_val string_to_Tension_Type_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Static"))
        {
            return Tension_Type_val.Static;
        }
        else //The tension is a static normal constant supplied by the operator or other data source
        if (__dummyScrutVar6.equals("Slack"))
        {
            return Tension_Type_val.Slack;
        }
        else //The tension is a static slack constant supplied by the operator or other data source
        if (__dummyScrutVar6.equals("Table"))
        {
            return Tension_Type_val.Table;
        }
        else //The tension is a table supplied by the operator or other data source
        if (__dummyScrutVar6.equals("Sag to Tension"))
        {
            return Tension_Type_val.Sag_to_Tension;
        }
        else //The tension is calculated based on the values entered for sag, weight, and LoadCase
        if (__dummyScrutVar6.equals("Tension to Sag"))
        {
            return Tension_Type_val.Tension_to_Sag;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //The tension is based on initial stringing tension and LoadCase
    public String tension_Type_val_to_String(Tension_Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Static: 
                return "Static";
            case Slack: 
                return "Slack";
            case Table: 
                return "Table";
            case Sag_to_Tension: 
                return "Sag to Tension";
            case Tension_to_Sag: 
                return "Tension to Sag";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //The tension is a static normal constant supplied by the operator or other data source
    //The tension is a static slack constant supplied by the operator or other data source
    //The tension is a table supplied by the operator or other data source
    //The tension is calculated based on the values entered for sag, weight, and LoadCase
    //The tension is based on initial stringing tension and LoadCase
    //   Attr Name:   Tension
    //   Attr Group:Tension Sag
    //   Alt Display Name:Tension (lbs)
    //   Description:   The tension value used only when "Tension Type" is "Static"
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Tension;
    public double getTension() throws Exception {
        return m_Tension;
    }

    public void setTension(double value) throws Exception {
        m_Tension = value;
    }

    //   Attr Name:   TensionTable
    //   Attr Group:Tension Sag
    //   Alt Display Name:Tension Table
    //   Description:   The tension values table used only when "Tension Type" is "Table"
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   TENSION_TABLE
    //   Default Value:   Tension;0,500;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_TensionTable = new ValTable();
    public ValTable getTensionTable() throws Exception {
        return m_TensionTable;
    }

    public void setTensionTable(ValTable value) throws Exception {
        m_TensionTable = value;
    }

    //   Attr Name:   SlackTension
    //   Attr Group:Tension Sag
    //   Alt Display Name:Slack Tension (lbs)
    //   Description:   The tension value used only when "Tension Type" is "Slack"
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   10.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SlackTension;
    public double getSlackTension() throws Exception {
        return m_SlackTension;
    }

    public void setSlackTension(double value) throws Exception {
        m_SlackTension = value;
    }

    //   Attr Name:   RatedStrength
    //   Attr Group:Tension Sag
    //   Alt Display Name:Msgr Rated Strength (lbs)
    //   Description:   The rated strength in pounds.
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   5000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RatedStrength;
    public double getRatedStrength() throws Exception {
        return m_RatedStrength;
    }

    public void setRatedStrength(double value) throws Exception {
        m_RatedStrength = value;
    }

    //   Attr Name:   ConductorDiameter
    //   Attr Group:Standard
    //   Alt Display Name:Msgr Diam (in)
    //   Description:   The conductor diameter in inches including the insulation.
    //   Displayed Units:   store as INCHES display as INCHES or MILLIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ConductorDiameter;
    public double getConductorDiameter() throws Exception {
        return m_ConductorDiameter;
    }

    public void setConductorDiameter(double value) throws Exception {
        m_ConductorDiameter = value;
    }

    //   Attr Name:   OverrideTemp
    //   Attr Group:Temperature
    //   Alt Display Name:Override Temp
    //   Description:   Override Nominal Temperature
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverrideTemp;
    public boolean getOverrideTemp() throws Exception {
        return m_OverrideTemp;
    }

    public void setOverrideTemp(boolean value) throws Exception {
        m_OverrideTemp = value;
    }

    //   Attr Name:   Temperature
    //   Attr Group:Temperature
    //   Alt Display Name:Temp Nom (Â°f)
    //   Description:   Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Temperature;
    public double getTemperature() throws Exception {
        return m_Temperature;
    }

    public void setTemperature(double value) throws Exception {
        m_Temperature = value;
    }

    //   Attr Name:   TempMin
    //   Attr Group:Temperature
    //   Alt Display Name:Temp Min (Â°f)
    //   Description:   Minimum Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   32
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TempMin;
    public double getTempMin() throws Exception {
        return m_TempMin;
    }

    public void setTempMin(double value) throws Exception {
        m_TempMin = value;
    }

    //   Attr Name:   TempMax
    //   Attr Group:Temperature
    //   Alt Display Name:Temp Max (Â°f)
    //   Description:   Maximum Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   212
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TempMax;
    public double getTempMax() throws Exception {
        return m_TempMax;
    }

    public void setTempMax(double value) throws Exception {
        m_TempMax = value;
    }

    //   Attr Name:   PoundsPerInch
    //   Attr Group:Phys Const
    //   Alt Display Name:Msgr Span Weight (lbs/ft)
    //   Description:   The weight per unit of running length
    //   Displayed Units:   store as POUNDS PER IN display as POUNDS PER FT or KILOGRAMS PER METER
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0000
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0076
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoundsPerInch;
    public double getPoundsPerInch() throws Exception {
        return m_PoundsPerInch;
    }

    public void setPoundsPerInch(double value) throws Exception {
        m_PoundsPerInch = value;
    }

    //   Attr Name:   ModulusOfElasticity
    //   Attr Group:Phys Const
    //   Alt Display Name:Msgr Modulus of Elasticity (psi)
    //   Description:   ModulusOfElasticity
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   11200000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ModulusOfElasticity;
    public double getModulusOfElasticity() throws Exception {
        return m_ModulusOfElasticity;
    }

    public void setModulusOfElasticity(double value) throws Exception {
        m_ModulusOfElasticity = value;
    }

    //   Attr Name:   PercentSolid
    //   Attr Group:Phys Const
    //   Alt Display Name:Msgr Percent Solid
    //   Description:   Percent Solid
    //   Displayed Units:   store as PERCENT 0 TO 1 display as PERCENT 0 TO 100
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   0.75
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PercentSolid;
    public double getPercentSolid() throws Exception {
        return m_PercentSolid;
    }

    public void setPercentSolid(double value) throws Exception {
        m_PercentSolid = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Phys Const
    //   Alt Display Name:Msgr Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000106
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   CreepCoefficient
    //   Attr Group:Phys Const
    //   Alt Display Name:Msgr Creep Coef ((in/in)/lb)
    //   Description:   CreepCoefficient
    //   Displayed Units:   store as CREEP COEFFICIENT
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_CreepCoefficient;
    public double getCreepCoefficient() throws Exception {
        return m_CreepCoefficient;
    }

    public void setCreepCoefficient(double value) throws Exception {
        m_CreepCoefficient = value;
    }

    //   Attr Name:   IceAccumulationFactor
    //   Attr Group:Tension Sag
    //   Alt Display Name:Ice Accum. Factor
    //   Description:   Ice Accumulation Factor for Tension Calculations
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###
    //   Attribute Type:   FLOAT
    //   Default Value:   0.75
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_IceAccumulationFactor;
    public double getIceAccumulationFactor() throws Exception {
        return m_IceAccumulationFactor;
    }

    public void setIceAccumulationFactor(double value) throws Exception {
        m_IceAccumulationFactor = value;
    }

    //   Attr Name:   WindTensionFactor
    //   Attr Group:Tension Sag
    //   Description:   Wind Factor for Tension Calculations
    //   Displayed Units:   INVERTED
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   -1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindTensionFactor;
    public double getWindTensionFactor() throws Exception {
        return m_WindTensionFactor;
    }

    public void setWindTensionFactor(double value) throws Exception {
        m_WindTensionFactor = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Tension Sag
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   VerticalOffset
    //   Attr Group:Phys Const
    //   Alt Display Name:Vertical Offset (in)
    //   Description:   Vertical Offset in Inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_VerticalOffset;
    public double getVerticalOffset() throws Exception {
        return m_VerticalOffset;
    }

    public void setVerticalOffset(double value) throws Exception {
        m_VerticalOffset = value;
    }

    //   Attr Name:   HorizontalOffset
    //   Attr Group:Phys Const
    //   Alt Display Name:Horizontal Offset (in)
    //   Description:   Horizontal Offset in Inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_HorizontalOffset;
    public double getHorizontalOffset() throws Exception {
        return m_HorizontalOffset;
    }

    public void setHorizontalOffset(double value) throws Exception {
        m_HorizontalOffset = value;
    }

    //   Attr Name:   StopAtTap
    //   Attr Group:Phys Const
    //   Alt Display Name:Stop at Tap
    //   Description:   Stop at Tap
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private boolean m_StopAtTap;
    public boolean getStopAtTap() throws Exception {
        return m_StopAtTap;
    }

    public void setStopAtTap(boolean value) throws Exception {
        m_StopAtTap = value;
    }

    //   Attr Name:   HasInlineBox
    //   Attr Group:Standard
    //   Alt Display Name:Inline Junction
    //   Description:   Flag set to indicate whther or not a span has an inline junction box on it
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private boolean m_HasInlineBox;
    public boolean getHasInlineBox() throws Exception {
        return m_HasInlineBox;
    }

    public void setHasInlineBox(boolean value) throws Exception {
        m_HasInlineBox = value;
    }

    //   Attr Name:   BoxOffset
    //   Attr Group:Standard
    //   Alt Display Name:Junc Box Offset (in)
    //   Description:   The distance down a line where a junction box is located
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   15.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_BoxOffset;
    public double getBoxOffset() throws Exception {
        return m_BoxOffset;
    }

    public void setBoxOffset(double value) throws Exception {
        m_BoxOffset = value;
    }

    //   Attr Name:   BoxLength
    //   Attr Group:Standard
    //   Alt Display Name:Junc Box Len (in)
    //   Description:   Junction box length in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   20.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_BoxLength;
    public double getBoxLength() throws Exception {
        return m_BoxLength;
    }

    public void setBoxLength(double value) throws Exception {
        m_BoxLength = value;
    }

    //   Attr Name:   BoxDiameter
    //   Attr Group:Standard
    //   Alt Display Name:Junc Box Diam (in)
    //   Description:   Junction box diameter in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   8.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_BoxDiameter;
    public double getBoxDiameter() throws Exception {
        return m_BoxDiameter;
    }

    public void setBoxDiameter(double value) throws Exception {
        m_BoxDiameter = value;
    }

    //   Attr Name:   BoxWeight
    //   Attr Group:Standard
    //   Alt Display Name:Junc Box Weight (lbs)
    //   Description:   Junction box weight in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   5.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_BoxWeight;
    public double getBoxWeight() throws Exception {
        return m_BoxWeight;
    }

    public void setBoxWeight(double value) throws Exception {
        m_BoxWeight = value;
    }

    //   Attr Name:   HasDripLoop
    //   Attr Group:DripLoop
    //   Alt Display Name:Drip Loop
    //   Description:   Flag set to indicate whther or not a span has a drip loop on it
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private boolean m_HasDripLoop;
    public boolean getHasDripLoop() throws Exception {
        return m_HasDripLoop;
    }

    public void setHasDripLoop(boolean value) throws Exception {
        m_HasDripLoop = value;
    }

    //   Attr Name:   DripLoopOffset
    //   Attr Group:DripLoop
    //   Alt Display Name:Drip Loop Offset (in)
    //   Description:   The distance down a line where a drip loop is located
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   2.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_DripLoopOffset;
    public double getDripLoopOffset() throws Exception {
        return m_DripLoopOffset;
    }

    public void setDripLoopOffset(double value) throws Exception {
        m_DripLoopOffset = value;
    }

    //   Attr Name:   DripLoopLength
    //   Attr Group:DripLoop
    //   Alt Display Name:Drip Loop Len (in)
    //   Description:   Drip loop length in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   20.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_DripLoopLength;
    public double getDripLoopLength() throws Exception {
        return m_DripLoopLength;
    }

    public void setDripLoopLength(double value) throws Exception {
        m_DripLoopLength = value;
    }

    //   Attr Name:   DripLoopHeight
    //   Attr Group:DripLoop
    //   Alt Display Name:Drip Loop Height (in)
    //   Description:   Drip loop height in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   10.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_DripLoopHeight;
    public double getDripLoopHeight() throws Exception {
        return m_DripLoopHeight;
    }

    public void setDripLoopHeight(double value) throws Exception {
        m_DripLoopHeight = value;
    }

    public enum Modifier_val
    {
        //   Attr Name:   Modifier
        //   Attr Group:Standard
        //   Description:   Special type modifier.
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   None
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   No
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Overlashed  (Overlashed)
        //        Bundled  (Bundled)
        //        Corrugated  (Corrugated)
        //        Flexpipe  (Flexpipe)
        //        Irregular  (Irregular)
        //        None  (None)
        //        (See Note)  ((See Note))
        Drop,
        //Drop
        Overlashed,
        //Overlashed
        Bundled,
        //Bundled
        Corrugated,
        //Corrugated
        Flexpipe,
        //Flexpipe
        Irregular,
        //Irregular
        None,
        //None
        _See_Note_
    }
    //(See Note)
    private Modifier_val m_Modifier = Modifier_val.Drop;
    public Modifier_val getModifier() throws Exception {
        return m_Modifier;
    }

    public void setModifier(Modifier_val value) throws Exception {
        m_Modifier = value;
    }

    public Modifier_val string_to_Modifier_val(String pKey) throws Exception {
        String __dummyScrutVar8 = pKey;
        if (__dummyScrutVar8.equals("Drop"))
        {
            return Modifier_val.Drop;
        }
        else //Drop
        if (__dummyScrutVar8.equals("Overlashed"))
        {
            return Modifier_val.Overlashed;
        }
        else //Overlashed
        if (__dummyScrutVar8.equals("Bundled"))
        {
            return Modifier_val.Bundled;
        }
        else //Bundled
        if (__dummyScrutVar8.equals("Corrugated"))
        {
            return Modifier_val.Corrugated;
        }
        else //Corrugated
        if (__dummyScrutVar8.equals("Flexpipe"))
        {
            return Modifier_val.Flexpipe;
        }
        else //Flexpipe
        if (__dummyScrutVar8.equals("Irregular"))
        {
            return Modifier_val.Irregular;
        }
        else //Irregular
        if (__dummyScrutVar8.equals("None"))
        {
            return Modifier_val.None;
        }
        else //None
        if (__dummyScrutVar8.equals("(See Note)"))
        {
            return Modifier_val._See_Note_;
        }
        else
        {
        }        
        throw new Exception("string does not match enum value");
    }

    //(See Note)
    public String modifier_val_to_String(Modifier_val pKey) throws Exception {
        switch(pKey)
        {
            case Drop: 
                return "Drop";
            case Overlashed: 
                return "Overlashed";
            case Bundled: 
                return "Bundled";
            case Corrugated: 
                return "Corrugated";
            case Flexpipe: 
                return "Flexpipe";
            case Irregular: 
                return "Irregular";
            case None: 
                return "None";
            case _See_Note_: 
                return "(See Note)";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Drop
    //Overlashed
    //Bundled
    //Corrugated
    //Flexpipe
    //Irregular
    //None
    //(See Note)
    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


