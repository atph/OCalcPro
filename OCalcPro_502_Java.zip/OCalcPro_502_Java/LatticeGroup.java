//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Beam;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.Node;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: LatticeGroup
// Mirrors: PPLLatticeGroup : PPLElement
//--------------------------------------------------------------------------------------------
public class LatticeGroup  extends ElementBase 
{
    public static String gXMLkey = "LatticeGroup";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public LatticeGroup(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Group";
            m_Name = "<tbd>";
            m_Width = 0;
            m_Depth = 0;
            m_Height = 0;
            m_OverrideRendering = false;
            m_NodeRenderDiam = 20;
            m_BeamRenderDiam = 12;
            m_RenderLoads = false;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Node)
            return true;
         
        if (pChildCandidate instanceof Beam)
            return true;
         
        if (pChildCandidate instanceof Material)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the group
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Group
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the group
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <tbd>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   Width
    //   Attr Group:Standard
    //   Alt Display Name:Width X (ft)
    //   Description:   Distance between min and max X
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Width;
    public double getWidth() throws Exception {
        return m_Width;
    }

    public void setWidth(double value) throws Exception {
        m_Width = value;
    }

    //   Attr Name:   Depth
    //   Attr Group:Standard
    //   Alt Display Name:Depth Y (ft)
    //   Description:   Distance between min and max Y
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Depth;
    public double getDepth() throws Exception {
        return m_Depth;
    }

    public void setDepth(double value) throws Exception {
        m_Depth = value;
    }

    //   Attr Name:   Height
    //   Attr Group:Standard
    //   Alt Display Name:Height Z (ft)
    //   Description:   Distance between min and max Z
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Height;
    public double getHeight() throws Exception {
        return m_Height;
    }

    public void setHeight(double value) throws Exception {
        m_Height = value;
    }

    //   Attr Name:   OverrideRendering
    //   Attr Group:Rendering
    //   Alt Display Name:Override Rendering
    //   Description:   Indicates if the rendering is controlled by this section
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverrideRendering;
    public boolean getOverrideRendering() throws Exception {
        return m_OverrideRendering;
    }

    public void setOverrideRendering(boolean value) throws Exception {
        m_OverrideRendering = value;
    }

    //   Attr Name:   NodeRenderDiam
    //   Attr Group:Rendering
    //   Alt Display Name:Node Render (in)
    //   Description:   Node render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   20
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_NodeRenderDiam;
    public double getNodeRenderDiam() throws Exception {
        return m_NodeRenderDiam;
    }

    public void setNodeRenderDiam(double value) throws Exception {
        m_NodeRenderDiam = value;
    }

    //   Attr Name:   BeamRenderDiam
    //   Attr Group:Rendering
    //   Alt Display Name:Beam Render (in)
    //   Description:   Beam render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BeamRenderDiam;
    public double getBeamRenderDiam() throws Exception {
        return m_BeamRenderDiam;
    }

    public void setBeamRenderDiam(double value) throws Exception {
        m_BeamRenderDiam = value;
    }

    //   Attr Name:   RenderLoads
    //   Attr Group:Rendering
    //   Alt Display Name:Render Loads
    //   Description:   Render loads
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_RenderLoads;
    public boolean getRenderLoads() throws Exception {
        return m_RenderLoads;
    }

    public void setRenderLoads(boolean value) throws Exception {
        m_RenderLoads = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


