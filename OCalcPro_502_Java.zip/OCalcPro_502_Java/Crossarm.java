//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.NodeJunction;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Crossarm
// Mirrors: PPLCrossArm : PPLElement
//--------------------------------------------------------------------------------------------
public class Crossarm  extends ElementBase 
{
    public static String gXMLkey = "Crossarm";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Crossarm(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_CoordinateX = 0;
            m_Description = "Crossarm";
            m_Owner = "<Undefined>";
            m_CoordinateZ = 462;
            m_CoordinateA = 0;
            m_Type = Type_val.Normal;
            m_Count = 1;
            m_Braced = Braced_val.None;
            m_BraceAll = false;
            m_BraceOffset = 24;
            m_BraceDrop = 24;
            m_LengthInInches = 96;
            m_HeightInInches = 4.5;
            m_DepthInInches = 3.5;
            m_Tilt = 0;
            m_VerticalOffset = 0;
            m_HorizontalOffset = 0;
            m_LateralOffset = 0;
            m_Weight = 50;
            m_Modulus_of_Rupture = 8000;
            m_Modulus_of_Elasticity = 1600000;
            m_PoissonsRatio = 0.3;
            m_WindDragCoef = 0;
            m_ThermalCoefficient = 2.7E-06;
            m_Analysis_Mode = Analysis_Mode_val.Automatic;
            m_AllowableMomentVertical = 500;
            m_AllowableMomentLongitudinal = 500;
            m_AllowableLoadTransverse = 0;
            m_AllowableLoadLongitudinal = 0;
            m_OverrideStrength = false;
            m_StrengthFactor = 0.5;
            m_Analysis_Method = Analysis_Method_val.Superposition;
            m_Offset = 0;
            m_Material = Material_val.Wood;
            m_Species = "Southern Pine";
            m_ArmMaterial = "<Default>";
            m_BraceMaterial = "<Default>";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Insulator)
            return true;
         
        if (pChildCandidate instanceof NodeJunction)
            return true;
         
        if (pChildCandidate instanceof Material)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:Pole Offset (in)
    //   Description:   Distance from the center of the pole to the center of the crossarm
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of crossarm
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Crossarm
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:   Distance from the butt of the parent pole to the center of the crossarm
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   462
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation angle around the center of the pole
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Alt Display Name:Install Type
        //   Description:   Crossarm type (centered or offset)
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Normal
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Offset  (Offset)
        //        Pole Extension  (Pole Extension)
        //        Full Gull  (Full Gull)
        //        Half Gull  (Half Gull)
        //        Standoff  (Standoff)
        Normal,
        //Normal
        Offset,
        //Offset
        Pole_Extension,
        //Pole Extension
        Full_Gull,
        //Full Gull
        Half_Gull,
        //Half Gull
        Standoff
    }
    //Standoff
    private Type_val m_Type = Type_val.Normal;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Normal"))
        {
            return Type_val.Normal;
        }
        else //Normal
        if (__dummyScrutVar0.equals("Offset"))
        {
            return Type_val.Offset;
        }
        else //Offset
        if (__dummyScrutVar0.equals("Pole Extension"))
        {
            return Type_val.Pole_Extension;
        }
        else //Pole Extension
        if (__dummyScrutVar0.equals("Full Gull"))
        {
            return Type_val.Full_Gull;
        }
        else //Full Gull
        if (__dummyScrutVar0.equals("Half Gull"))
        {
            return Type_val.Half_Gull;
        }
        else //Half Gull
        if (__dummyScrutVar0.equals("Standoff"))
        {
            return Type_val.Standoff;
        }
        else
        {
        }      
        throw new Exception("string does not match enum value");
    }

    //Standoff
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Normal: 
                return "Normal";
            case Offset: 
                return "Offset";
            case Pole_Extension: 
                return "Pole Extension";
            case Full_Gull: 
                return "Full Gull";
            case Half_Gull: 
                return "Half Gull";
            case Standoff: 
                return "Standoff";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Normal
    //Offset
    //Pole Extension
    //Full Gull
    //Half Gull
    //Standoff
    //   Attr Name:   Count
    //   Attr Group:Standard
    //   Alt Display Name:Arm Count
    //   Description:   Crossarm count (1 or 2)
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   PLUSMINUS
    //   Default Value:   1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_Count;
    public int getCount() throws Exception {
        return m_Count;
    }

    public void setCount(int value) throws Exception {
        m_Count = value;
    }

    public enum Braced_val
    {
        //   Attr Name:   Braced
        //   Attr Group:Brace
        //   Alt Display Name:Brace Config.
        //   Description:   Indicates if the crossarm is braced
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   None
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Single  (Single)
        //        None  (None)
        Double,
        //Double
        Single,
        //Single
        None
    }
    //None
    private Braced_val m_Braced = Braced_val.Double;
    public Braced_val getBraced() throws Exception {
        return m_Braced;
    }

    public void setBraced(Braced_val value) throws Exception {
        m_Braced = value;
    }

    public Braced_val string_to_Braced_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Double"))
        {
            return Braced_val.Double;
        }
        else //Double
        if (__dummyScrutVar2.equals("Single"))
        {
            return Braced_val.Single;
        }
        else //Single
        if (__dummyScrutVar2.equals("None"))
        {
            return Braced_val.None;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //None
    public String braced_val_to_String(Braced_val pKey) throws Exception {
        switch(pKey)
        {
            case Double: 
                return "Double";
            case Single: 
                return "Single";
            case None: 
                return "None";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Double
    //Single
    //None
    //   Attr Name:   BraceAll
    //   Attr Group:Brace
    //   Alt Display Name:Brace All Arms
    //   Description:   Brace all arms
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_BraceAll;
    public boolean getBraceAll() throws Exception {
        return m_BraceAll;
    }

    public void setBraceAll(boolean value) throws Exception {
        m_BraceAll = value;
    }

    //   Attr Name:   BraceOffset
    //   Attr Group:Brace
    //   Alt Display Name:Brace Horiz Offset (in)
    //   Description:   Horizontal distance to brace point
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   TRACKERX
    //   Default Value:   24.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BraceOffset;
    public double getBraceOffset() throws Exception {
        return m_BraceOffset;
    }

    public void setBraceOffset(double value) throws Exception {
        m_BraceOffset = value;
    }

    //   Attr Name:   BraceDrop
    //   Attr Group:Brace
    //   Alt Display Name:Brace Vert Offset (in)
    //   Description:   Vertical distance to brace point
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   TRACKERZ
    //   Default Value:   24.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BraceDrop;
    public double getBraceDrop() throws Exception {
        return m_BraceDrop;
    }

    public void setBraceDrop(double value) throws Exception {
        m_BraceDrop = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Arm Length (ft)
    //   Description:   The length from the crossarm from tip to tip
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   96
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   HeightInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Arm Height (in)
    //   Description:   The distance from the top of the crossarm to the bottom
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   4.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HeightInInches;
    public double getHeightInInches() throws Exception {
        return m_HeightInInches;
    }

    public void setHeightInInches(double value) throws Exception {
        m_HeightInInches = value;
    }

    //   Attr Name:   DepthInInches
    //   Attr Group:Dimensions
    //   Alt Display Name:Arm Depth (in)
    //   Description:   The distance (depth) from the face of the crossarm to the surface of the pole in inches
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DepthInInches;
    public double getDepthInInches() throws Exception {
        return m_DepthInInches;
    }

    public void setDepthInInches(double value) throws Exception {
        m_DepthInInches = value;
    }

    //   Attr Name:   Tilt
    //   Attr Group:Physical
    //   Alt Display Name:Arm Tilt
    //   Description:   The crossarm tilt in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Tilt;
    public double getTilt() throws Exception {
        return m_Tilt;
    }

    public void setTilt(double value) throws Exception {
        m_Tilt = value;
    }

    //   Attr Name:   VerticalOffset
    //   Attr Group:Physical
    //   Alt Display Name:Vertical Offset (in)
    //   Description:   Vertical Offset
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERZ
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_VerticalOffset;
    public double getVerticalOffset() throws Exception {
        return m_VerticalOffset;
    }

    public void setVerticalOffset(double value) throws Exception {
        m_VerticalOffset = value;
    }

    //   Attr Name:   HorizontalOffset
    //   Attr Group:Physical
    //   Alt Display Name:Horizontal Offset (in)
    //   Description:   Horizontal Offset
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_HorizontalOffset;
    public double getHorizontalOffset() throws Exception {
        return m_HorizontalOffset;
    }

    public void setHorizontalOffset(double value) throws Exception {
        m_HorizontalOffset = value;
    }

    //   Attr Name:   LateralOffset
    //   Attr Group:Physical
    //   Alt Display Name:Lateral Offset (in)
    //   Description:   Lateral Offset
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LateralOffset;
    public double getLateralOffset() throws Exception {
        return m_LateralOffset;
    }

    public void setLateralOffset(double value) throws Exception {
        m_LateralOffset = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Physical
    //   Alt Display Name:Arm Weight (lbs)
    //   Description:   Crossarm weight in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   50
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   Modulus of Rupture
    //   Attr Group:Physical
    //   Alt Display Name:Modulus of Rupture (psi)
    //   Description:   Modulus of rupture
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   8000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Rupture;
    public double getModulus_of_Rupture() throws Exception {
        return m_Modulus_of_Rupture;
    }

    public void setModulus_of_Rupture(double value) throws Exception {
        m_Modulus_of_Rupture = value;
    }

    //   Attr Name:   Modulus of Elasticity
    //   Attr Group:Physical
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   Modulus of elasticty for the crossarm
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   1600000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Elasticity;
    public double getModulus_of_Elasticity() throws Exception {
        return m_Modulus_of_Elasticity;
    }

    public void setModulus_of_Elasticity(double value) throws Exception {
        m_Modulus_of_Elasticity = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Physical
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.3
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Physical
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Physical
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000027
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    public enum Analysis_Mode_val
    {
        //   Attr Name:   Analysis Mode
        //   Attr Group:Analysis
        //   Alt Display Name:Capacity Method
        //   Description:   Analysis Mode
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Automatic
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Manual  (Manual)
        Automatic,
        //Automatic
        Manual
    }
    //Manual
    private Analysis_Mode_val m_Analysis_Mode = Analysis_Mode_val.Automatic;
    public Analysis_Mode_val getAnalysis_Mode() throws Exception {
        return m_Analysis_Mode;
    }

    public void setAnalysis_Mode(Analysis_Mode_val value) throws Exception {
        m_Analysis_Mode = value;
    }

    public Analysis_Mode_val string_to_Analysis_Mode_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Automatic"))
        {
            return Analysis_Mode_val.Automatic;
        }
        else //Automatic
        if (__dummyScrutVar4.equals("Manual"))
        {
            return Analysis_Mode_val.Manual;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Manual
    public String analysis_Mode_val_to_String(Analysis_Mode_val pKey) throws Exception {
        switch(pKey)
        {
            case Automatic: 
                return "Automatic";
            case Manual: 
                return "Manual";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Automatic
    //Manual
    //   Attr Name:   AllowableMomentVertical
    //   Attr Group:Analysis
    //   Alt Display Name:Max Moment Vert (ft-lb)
    //   Description:   AllowableMomentVertical
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_AllowableMomentVertical;
    public double getAllowableMomentVertical() throws Exception {
        return m_AllowableMomentVertical;
    }

    public void setAllowableMomentVertical(double value) throws Exception {
        m_AllowableMomentVertical = value;
    }

    //   Attr Name:   AllowableMomentLongitudinal
    //   Attr Group:Analysis
    //   Alt Display Name:Max Moment Long (ft-lb)
    //   Description:   AllowableMomentLongitudinal
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_AllowableMomentLongitudinal;
    public double getAllowableMomentLongitudinal() throws Exception {
        return m_AllowableMomentLongitudinal;
    }

    public void setAllowableMomentLongitudinal(double value) throws Exception {
        m_AllowableMomentLongitudinal = value;
    }

    //   Attr Name:   AllowableLoadTransverse
    //   Attr Group:Analysis
    //   Alt Display Name:Max Load Shear (lbs)
    //   Description:   AllowableLoadTransverse
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_AllowableLoadTransverse;
    public double getAllowableLoadTransverse() throws Exception {
        return m_AllowableLoadTransverse;
    }

    public void setAllowableLoadTransverse(double value) throws Exception {
        m_AllowableLoadTransverse = value;
    }

    //   Attr Name:   AllowableLoadLongitudinal
    //   Attr Group:Analysis
    //   Alt Display Name:Max Load Tension (lbs)
    //   Description:   AllowableLoadLongitudinal
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_AllowableLoadLongitudinal;
    public double getAllowableLoadLongitudinal() throws Exception {
        return m_AllowableLoadLongitudinal;
    }

    public void setAllowableLoadLongitudinal(double value) throws Exception {
        m_AllowableLoadLongitudinal = value;
    }

    //   Attr Name:   OverrideStrength
    //   Attr Group:Analysis
    //   Alt Display Name:Override Strength Factor
    //   Description:   Override Nominal Strength Factor
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_OverrideStrength;
    public boolean getOverrideStrength() throws Exception {
        return m_OverrideStrength;
    }

    public void setOverrideStrength(boolean value) throws Exception {
        m_OverrideStrength = value;
    }

    //   Attr Name:   StrengthFactor
    //   Attr Group:Analysis
    //   Alt Display Name:Strength Factor
    //   Description:   Crosarm Strength Factor value
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.50
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrengthFactor;
    public double getStrengthFactor() throws Exception {
        return m_StrengthFactor;
    }

    public void setStrengthFactor(double value) throws Exception {
        m_StrengthFactor = value;
    }

    public enum Analysis_Method_val
    {
        //   Attr Name:   Analysis Method
        //   Attr Group:Analysis
        //   Description:   Analysis Method
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Superposition
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Interaction  (Interaction)
        //        Worst Axis  (Worst Axis)
        Superposition,
        //Superposition
        Interaction,
        //Interaction
        Worst_Axis
    }
    //Worst Axis
    private Analysis_Method_val m_Analysis_Method = Analysis_Method_val.Superposition;
    public Analysis_Method_val getAnalysis_Method() throws Exception {
        return m_Analysis_Method;
    }

    public void setAnalysis_Method(Analysis_Method_val value) throws Exception {
        m_Analysis_Method = value;
    }

    public Analysis_Method_val string_to_Analysis_Method_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Superposition"))
        {
            return Analysis_Method_val.Superposition;
        }
        else //Superposition
        if (__dummyScrutVar6.equals("Interaction"))
        {
            return Analysis_Method_val.Interaction;
        }
        else //Interaction
        if (__dummyScrutVar6.equals("Worst Axis"))
        {
            return Analysis_Method_val.Worst_Axis;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Worst Axis
    public String analysis_Method_val_to_String(Analysis_Method_val pKey) throws Exception {
        switch(pKey)
        {
            case Superposition: 
                return "Superposition";
            case Interaction: 
                return "Interaction";
            case Worst_Axis: 
                return "Worst Axis";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Superposition
    //Interaction
    //Worst Axis
    //   Attr Name:   Offset
    //   Attr Group:Multi Pole
    //   Alt Display Name:Offset (ft)
    //   Description:   Multi Pole offset in feet
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_Offset;
    public double getOffset() throws Exception {
        return m_Offset;
    }

    public void setOffset(double value) throws Exception {
        m_Offset = value;
    }

    public enum Material_val
    {
        //   Attr Name:   Material
        //   Attr Group:Material
        //   Description:   Material
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Wood
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Steel  (Steel)
        //        Composite  (Composite)
        //        Other  (Other)
        Wood,
        //Wood
        Steel,
        //Steel
        Composite,
        //Composite
        Other
    }
    //Other
    private Material_val m_Material = Material_val.Wood;
    public Material_val getMaterial() throws Exception {
        return m_Material;
    }

    public void setMaterial(Material_val value) throws Exception {
        m_Material = value;
    }

    public Material_val string_to_Material_val(String pKey) throws Exception {
        String __dummyScrutVar8 = pKey;
        if (__dummyScrutVar8.equals("Wood"))
        {
            return Material_val.Wood;
        }
        else //Wood
        if (__dummyScrutVar8.equals("Steel"))
        {
            return Material_val.Steel;
        }
        else //Steel
        if (__dummyScrutVar8.equals("Composite"))
        {
            return Material_val.Composite;
        }
        else //Composite
        if (__dummyScrutVar8.equals("Other"))
        {
            return Material_val.Other;
        }
        else
        {
        }    
        throw new Exception("string does not match enum value");
    }

    //Other
    public String material_val_to_String(Material_val pKey) throws Exception {
        switch(pKey)
        {
            case Wood: 
                return "Wood";
            case Steel: 
                return "Steel";
            case Composite: 
                return "Composite";
            case Other: 
                return "Other";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Wood
    //Steel
    //Composite
    //Other
    //   Attr Name:   Species
    //   Attr Group:Material
    //   Description:   Wood species of the crossarm
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Southern Pine
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Species;
    public String getSpecies() throws Exception {
        return m_Species;
    }

    public void setSpecies(String value) throws Exception {
        m_Species = value;
    }

    //   Attr Name:   ArmMaterial
    //   Attr Group:Material
    //   Alt Display Name:Arm Material Props
    //   Description:   Arm Material
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <Default>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_ArmMaterial;
    public String getArmMaterial() throws Exception {
        return m_ArmMaterial;
    }

    public void setArmMaterial(String value) throws Exception {
        m_ArmMaterial = value;
    }

    //   Attr Name:   BraceMaterial
    //   Attr Group:Material
    //   Alt Display Name:Brace Material Props
    //   Description:   Brace Material
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <Default>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_BraceMaterial;
    public String getBraceMaterial() throws Exception {
        return m_BraceMaterial;
    }

    public void setBraceMaterial(String value) throws Exception {
        m_BraceMaterial = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


