//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: LoadCase
// Mirrors: PPLEnvironment : PPLElement
//--------------------------------------------------------------------------------------------
public class LoadCase  extends ElementBase 
{
    public static String gXMLkey = "LoadCase";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public LoadCase(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Name = "";
            m_Method = Method_val.NESC;
            m_Deflection = Deflection_val.Linear;
            m_Fixity = Fixity_val.Fixed;
            m_Solver = Solver_val.Advanced;
            m_Algorithm = Algorithm_val.Cholesky_Decomposition;
            m_District = District_val.Medium;
            m_Radial_Ice = 0.25;
            m_Ice_Density = 0.032986;
            m_Wind_Speed = 39.53;
            m_Horiz_Wind_Pres = 4;
            m_Temperature = 65;
            m_TempMin = 32;
            m_TempMax = 212;
            m_WindType = WindType_val.WindType_2007;
            m_Construction_Grade = Construction_Grade_val.B;
            m_Crossing_Conditions = Crossing_Conditions_val.Unknown;
            m_Installation_or_Replacement = Installation_or_Replacement_val.At_Installation;
            m_Override_Wind = false;
            m_NomWindAngle = 0;
            m_Terrian_Exposure = Terrian_Exposure_val.N_A;
            m_Force_Coef = 0;
            m_Apply_FSR = false;
            m_Strength_Reduction_Factor = 1;
            m_Load_Duration_Factor = 1;
            m_Immaturity_Factor = 1;
            m_Shaving_Factor = 1;
            m_Processing_Factor = 1;
            m_Degradation_Factor = 1;
            m_Shear_Area = Shear_Area_val.Tip;
            m_ApplyCrossarmAllowance = ApplyCrossarmAllowance_val.Auto;
            m_CrossarmAllowance = 300;
            m_ApplyCableAllowance = ApplyCableAllowance_val.Auto;
            m_CableAllowance = 300;
            m_Attr_250_Rule = Attr_250_Rule_val.Rule_250B;
            m_Vertical_LF = 1.5;
            m_TransWind_LF = 2.5;
            m_TransTension_LF = 1.65;
            m_GeneralLongitude_LF = 1.1;
            m_DeadendLongitude_LF = 1.65;
            m_Guy_Vertical_LF = 1.5;
            m_Guy_TransWind_LF = 2.5;
            m_Guy_TransTension_LF = 1.65;
            m_Guy_GeneralLongitude_LF = 1.1;
            m_Guy_DeadendLongitude_LF = 1.65;
            m_Anchor_Vertical_LF = 1.5;
            m_Anchor_TransWind_LF = 2.5;
            m_Anchor_TransTension_LF = 1.65;
            m_Anchor_GeneralLongitude_LF = 1.1;
            m_Anchor_DeadendLongitude_LF = 1.65;
            m_Pole_Strength_Factor = 0.85;
            m_Manufactured_Pole_Strength_Factor = 1;
            m_Crossarm_Strength_Factor = 0.5;
            m_Guy_Strength_Factor = 0.9;
            m_Anchor_Strength_Factor = 1;
            m_PoleCapacityThreshhold = 75;
            m_Guy_Inadequate_Thresh = 0.5;
            m_Guy_At_Cap_Thresh = 2;
            m_Guy_Near_Cap_Thresh = 10;
            m_Span_Cap_Thresh = 10;
            m_BucklingConstUnguyed = 2;
            m_BucklingConstGuyed = 0.707106781186548;
            m_BucklingConstGuyedDeadend = 0.707106781186548;
            m_SectionHeightMethod = SectionHeightMethod_val.Standard;
            m_BucklingSectionPercentBCH = 0.33333333;
            m_ReportingAngleMode = ReportingAngleMode_val.Load;
            m_ReportingAngle = 1.5707963267949;
            m_SpanCapSignal = false;
            m_ArmCapSignal = false;
            m_GuyCapSignal = false;
            m_AnchorCapSignal = false;
            m_CarryCapacityUp = false;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   LoadCase name
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    public enum Method_val
    {
        //   Attr Name:   Method
        //   Attr Group:Standard
        //   Alt Display Name:Code
        //   Description:   Calculation Method
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   NESC
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        GO 95  (GO 95)
        //        ASCE  (Americal Society of Civil Engineers)
        //        CSA  (Canadian Standards Association)
        //        AS/NZS 7000  (AS/NZS 7000)
        //        N/A  (No special calculations)
        NESC,
        //National Electrical Safety Code
        GO_95,
        //GO 95
        ASCE,
        //Americal Society of Civil Engineers
        CSA,
        //Canadian Standards Association
        AS_NZS_7000,
        //AS/NZS 7000
        N_A
    }
    //No special calculations
    private Method_val m_Method = Method_val.NESC;
    public Method_val getMethod() throws Exception {
        return m_Method;
    }

    public void setMethod(Method_val value) throws Exception {
        m_Method = value;
    }

    public Method_val string_to_Method_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("NESC"))
        {
            return Method_val.NESC;
        }
        else //National Electrical Safety Code
        if (__dummyScrutVar0.equals("GO 95"))
        {
            return Method_val.GO_95;
        }
        else //GO 95
        if (__dummyScrutVar0.equals("ASCE"))
        {
            return Method_val.ASCE;
        }
        else //Americal Society of Civil Engineers
        if (__dummyScrutVar0.equals("CSA"))
        {
            return Method_val.CSA;
        }
        else //Canadian Standards Association
        if (__dummyScrutVar0.equals("AS/NZS 7000"))
        {
            return Method_val.AS_NZS_7000;
        }
        else //AS/NZS 7000
        if (__dummyScrutVar0.equals("N/A"))
        {
            return Method_val.N_A;
        }
        else
        {
        }      
        throw new Exception("string does not match enum value");
    }

    //No special calculations
    public String method_val_to_String(Method_val pKey) throws Exception {
        switch(pKey)
        {
            case NESC: 
                return "NESC";
            case GO_95: 
                return "GO 95";
            case ASCE: 
                return "ASCE";
            case CSA: 
                return "CSA";
            case AS_NZS_7000: 
                return "AS/NZS 7000";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //National Electrical Safety Code
    //GO 95
    //Americal Society of Civil Engineers
    //Canadian Standards Association
    //AS/NZS 7000
    //No special calculations
    public enum Deflection_val
    {
        //   Attr Name:   Deflection
        //   Attr Group:Solver
        //   Alt Display Name:Analysis Method
        //   Description:   Solution method to use
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Linear
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        1 Iteration P-Î”  (Single iteration P-Delta)
        //        2nd Order P-Î”  (Fully Converged P-Delta)
        Linear,
        //Static No P-Delta iterations performed
        Deflection_1_Iteration_P_Delta,
        //Single iteration P-Delta
        Deflection_2nd_Order_P_Delta
    }
    //Fully Converged P-Delta
    private Deflection_val m_Deflection = Deflection_val.Linear;
    public Deflection_val getDeflection() throws Exception {
        return m_Deflection;
    }

    public void setDeflection(Deflection_val value) throws Exception {
        m_Deflection = value;
    }

    public Deflection_val string_to_Deflection_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Linear"))
        {
            return Deflection_val.Linear;
        }
        else //Static No P-Delta iterations performed
        if (__dummyScrutVar2.equals("1 Iteration P-Î”"))
        {
            return Deflection_val.Deflection_1_Iteration_P_Delta;
        }
        else //Single iteration P-Delta
        if (__dummyScrutVar2.equals("2nd Order P-Î”"))
        {
            return Deflection_val.Deflection_2nd_Order_P_Delta;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Fully Converged P-Delta
    public String deflection_val_to_String(Deflection_val pKey) throws Exception {
        switch(pKey)
        {
            case Linear: 
                return "Linear";
            case Deflection_1_Iteration_P_Delta: 
                return "1 Iteration P-Î”";
            case Deflection_2nd_Order_P_Delta: 
                return "2nd Order P-Î”";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Static No P-Delta iterations performed
    //Single iteration P-Delta
    //Fully Converged P-Delta
    public enum Fixity_val
    {
        //   Attr Name:   Fixity
        //   Attr Group:Solver
        //   Alt Display Name:Groundline Fixity
        //   Description:   Groundline fixity mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Fixed
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Pinned  (Pole is gimbaled at groundline for guy analysis)
        Fixed,
        //Pole is fixed at groundline for guy analysis
        Pinned
    }
    //Pole is gimbaled at groundline for guy analysis
    private Fixity_val m_Fixity = Fixity_val.Fixed;
    public Fixity_val getFixity() throws Exception {
        return m_Fixity;
    }

    public void setFixity(Fixity_val value) throws Exception {
        m_Fixity = value;
    }

    public Fixity_val string_to_Fixity_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Fixed"))
        {
            return Fixity_val.Fixed;
        }
        else //Pole is fixed at groundline for guy analysis
        if (__dummyScrutVar4.equals("Pinned"))
        {
            return Fixity_val.Pinned;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Pole is gimbaled at groundline for guy analysis
    public String fixity_val_to_String(Fixity_val pKey) throws Exception {
        switch(pKey)
        {
            case Fixed: 
                return "Fixed";
            case Pinned: 
                return "Pinned";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Pole is fixed at groundline for guy analysis
    //Pole is gimbaled at groundline for guy analysis
    public enum Solver_val
    {
        //   Attr Name:   Solver
        //   Attr Group:Solver
        //   Description:   Solver to use
        //   User Level Required:   Administrative access only
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Advanced
        //   ReadOnly Value:   Yes
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Advanced  (Advanced)
        Legacy,
        //Legacy
        Advanced
    }
    //Advanced
    private Solver_val m_Solver = Solver_val.Legacy;
    public Solver_val getSolver() throws Exception {
        return m_Solver;
    }

    public void setSolver(Solver_val value) throws Exception {
        m_Solver = value;
    }

    public Solver_val string_to_Solver_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Legacy"))
        {
            return Solver_val.Legacy;
        }
        else //Legacy
        if (__dummyScrutVar6.equals("Advanced"))
        {
            return Solver_val.Advanced;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Advanced
    public String solver_val_to_String(Solver_val pKey) throws Exception {
        switch(pKey)
        {
            case Legacy: 
                return "Legacy";
            case Advanced: 
                return "Advanced";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Legacy
    //Advanced
    public enum Algorithm_val
    {
        //   Attr Name:   Algorithm
        //   Attr Group:Solver
        //   Description:   Algorithm to use
        //   User Level Required:   Administrative access only
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Cholesky Decomposition
        //   ReadOnly Value:   Yes
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Conjugate Gradient  (Conjugate Gradient)
        Cholesky_Decomposition,
        //Cholesky Decomposition
        Conjugate_Gradient
    }
    //Conjugate Gradient
    private Algorithm_val m_Algorithm = Algorithm_val.Cholesky_Decomposition;
    public Algorithm_val getAlgorithm() throws Exception {
        return m_Algorithm;
    }

    public void setAlgorithm(Algorithm_val value) throws Exception {
        m_Algorithm = value;
    }

    public Algorithm_val string_to_Algorithm_val(String pKey) throws Exception {
        String __dummyScrutVar8 = pKey;
        if (__dummyScrutVar8.equals("Cholesky Decomposition"))
        {
            return Algorithm_val.Cholesky_Decomposition;
        }
        else //Cholesky Decomposition
        if (__dummyScrutVar8.equals("Conjugate Gradient"))
        {
            return Algorithm_val.Conjugate_Gradient;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Conjugate Gradient
    public String algorithm_val_to_String(Algorithm_val pKey) throws Exception {
        switch(pKey)
        {
            case Cholesky_Decomposition: 
                return "Cholesky Decomposition";
            case Conjugate_Gradient: 
                return "Conjugate Gradient";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Cholesky Decomposition
    //Conjugate Gradient
    public enum District_val
    {
        //   Attr Name:   District
        //   Attr Group:Ice
        //   Description:   District
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Medium
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Medium  (Medium)
        //        Medium A  (Medium A)
        //        Medium B  (Medium B)
        //        Heavy  (Heavy)
        //        Severe  (Severe)
        //        Manual  (Manual)
        //        Warm Island  (Warm Island)
        //        Special  (Special)
        //        Unset  (Unset)
        //        N/A  (N/A)
        Light,
        //Light
        Medium,
        //Medium
        Medium_A,
        //Medium A
        Medium_B,
        //Medium B
        Heavy,
        //Heavy
        Severe,
        //Severe
        Manual,
        //Manual
        Warm_Island,
        //Warm Island
        Special,
        //Special
        Unset,
        //Unset
        N_A
    }
    //N/A
    private District_val m_District = District_val.Light;
    public District_val getDistrict() throws Exception {
        return m_District;
    }

    public void setDistrict(District_val value) throws Exception {
        m_District = value;
    }

    public District_val string_to_District_val(String pKey) throws Exception {
        String __dummyScrutVar10 = pKey;
        if (__dummyScrutVar10.equals("Light"))
        {
            return District_val.Light;
        }
        else //Light
        if (__dummyScrutVar10.equals("Medium"))
        {
            return District_val.Medium;
        }
        else //Medium
        if (__dummyScrutVar10.equals("Medium A"))
        {
            return District_val.Medium_A;
        }
        else //Medium A
        if (__dummyScrutVar10.equals("Medium B"))
        {
            return District_val.Medium_B;
        }
        else //Medium B
        if (__dummyScrutVar10.equals("Heavy"))
        {
            return District_val.Heavy;
        }
        else //Heavy
        if (__dummyScrutVar10.equals("Severe"))
        {
            return District_val.Severe;
        }
        else //Severe
        if (__dummyScrutVar10.equals("Manual"))
        {
            return District_val.Manual;
        }
        else //Manual
        if (__dummyScrutVar10.equals("Warm Island"))
        {
            return District_val.Warm_Island;
        }
        else //Warm Island
        if (__dummyScrutVar10.equals("Special"))
        {
            return District_val.Special;
        }
        else //Special
        if (__dummyScrutVar10.equals("Unset"))
        {
            return District_val.Unset;
        }
        else //Unset
        if (__dummyScrutVar10.equals("N/A"))
        {
            return District_val.N_A;
        }
        else
        {
        }           
        throw new Exception("string does not match enum value");
    }

    //N/A
    public String district_val_to_String(District_val pKey) throws Exception {
        switch(pKey)
        {
            case Light: 
                return "Light";
            case Medium: 
                return "Medium";
            case Medium_A: 
                return "Medium A";
            case Medium_B: 
                return "Medium B";
            case Heavy: 
                return "Heavy";
            case Severe: 
                return "Severe";
            case Manual: 
                return "Manual";
            case Warm_Island: 
                return "Warm Island";
            case Special: 
                return "Special";
            case Unset: 
                return "Unset";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Light
    //Medium
    //Medium A
    //Medium B
    //Heavy
    //Severe
    //Manual
    //Warm Island
    //Special
    //Unset
    //N/A
    //   Attr Name:   Radial Ice
    //   Attr Group:Ice
    //   Alt Display Name:Radial Ice (in)
    //   Description:   Radial Thickness of Ice
    //   Displayed Units:   store as INCHES display as INCHES or MILLIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.25
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Radial_Ice;
    public double getRadial_Ice() throws Exception {
        return m_Radial_Ice;
    }

    public void setRadial_Ice(double value) throws Exception {
        m_Radial_Ice = value;
    }

    //   Attr Name:   Ice Density
    //   Attr Group:Ice
    //   Alt Display Name:Ice Density (lb/ft^3)
    //   Description:   Ice Density in lbs per cubic inch
    //   Displayed Units:   store as POUNDS PER CUBIC INCH display as POUNDS PER CUBIC FOOT or KILOGRAMS PER CUBIC METER
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.032986
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Ice_Density;
    public double getIce_Density() throws Exception {
        return m_Ice_Density;
    }

    public void setIce_Density(double value) throws Exception {
        m_Ice_Density = value;
    }

    //   Attr Name:   Wind Speed
    //   Attr Group:Wind
    //   Alt Display Name:Wind Speed (mph)
    //   Description:   NESC Basic Wind Speed at 33 Feet / ASCE Fastest Wind
    //   Displayed Units:   store as MILES PER HOUR display as MILES PER HOUR or KILOMETERS PER HOUR
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   39.53
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Wind_Speed;
    public double getWind_Speed() throws Exception {
        return m_Wind_Speed;
    }

    public void setWind_Speed(double value) throws Exception {
        m_Wind_Speed = value;
    }

    //   Attr Name:   Horiz Wind Pres
    //   Attr Group:Wind
    //   Alt Display Name:Wind Pressure (lb/ft^2)
    //   Description:   Horizontal Wind Pressure in lbs per square foot
    //   Displayed Units:   store as PSF display as PSF or PASCAL
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   4
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Horiz_Wind_Pres;
    public double getHoriz_Wind_Pres() throws Exception {
        return m_Horiz_Wind_Pres;
    }

    public void setHoriz_Wind_Pres(double value) throws Exception {
        m_Horiz_Wind_Pres = value;
    }

    //   Attr Name:   Temperature
    //   Attr Group:Temperature
    //   Alt Display Name:Temperature (Â°f)
    //   Description:   Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Temperature;
    public double getTemperature() throws Exception {
        return m_Temperature;
    }

    public void setTemperature(double value) throws Exception {
        m_Temperature = value;
    }

    //   Attr Name:   TempMin
    //   Attr Group:Temperature
    //   Alt Display Name:Temp Min (Â°f)
    //   Description:   Minimum Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   32
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TempMin;
    public double getTempMin() throws Exception {
        return m_TempMin;
    }

    public void setTempMin(double value) throws Exception {
        m_TempMin = value;
    }

    //   Attr Name:   TempMax
    //   Attr Group:Temperature
    //   Alt Display Name:Temp Max (Â°f)
    //   Description:   Maximum Temperature
    //   Displayed Units:   store as FAHRENHEIT display as FAHRENHEIT or CELSIUS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   212
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TempMax;
    public double getTempMax() throws Exception {
        return m_TempMax;
    }

    public void setTempMax(double value) throws Exception {
        m_TempMax = value;
    }

    public enum WindType_val
    {
        //   Attr Name:   WindType
        //   Attr Group:Wind
        //   Alt Display Name:NESC Standard
        //   Description:   Wind calculation type
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   2007
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        2002  (2002)
        //        2007  (2007)
        //        2012  (2012)
        //        N/A  (N/A)
        WindType_1997,
        //1997
        WindType_2002,
        //2002
        WindType_2007,
        //2007
        WindType_2012,
        //2012
        N_A
    }
    //N/A
    private WindType_val m_WindType = WindType_val.WindType_1997;
    public WindType_val getWindType() throws Exception {
        return m_WindType;
    }

    public void setWindType(WindType_val value) throws Exception {
        m_WindType = value;
    }

    public WindType_val string_to_WindType_val(String pKey) throws Exception {
        String __dummyScrutVar12 = pKey;
        if (__dummyScrutVar12.equals("1997"))
        {
            return WindType_val.WindType_1997;
        }
        else //1997
        if (__dummyScrutVar12.equals("2002"))
        {
            return WindType_val.WindType_2002;
        }
        else //2002
        if (__dummyScrutVar12.equals("2007"))
        {
            return WindType_val.WindType_2007;
        }
        else //2007
        if (__dummyScrutVar12.equals("2012"))
        {
            return WindType_val.WindType_2012;
        }
        else //2012
        if (__dummyScrutVar12.equals("N/A"))
        {
            return WindType_val.N_A;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //N/A
    public String windType_val_to_String(WindType_val pKey) throws Exception {
        switch(pKey)
        {
            case WindType_1997: 
                return "1997";
            case WindType_2002: 
                return "2002";
            case WindType_2007: 
                return "2007";
            case WindType_2012: 
                return "2012";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //1997
    //2002
    //2007
    //2012
    //N/A
    public enum Construction_Grade_val
    {
        //   Attr Name:   Construction Grade
        //   Attr Group:Standard
        //   Description:   Construction Grade
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   B
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        F  (F)
        //        B  (B)
        //        C  (C)
        //        1  (1)
        //        2  (2)
        //        3  (3)
        //        N/A  (N/A)
        A,
        //A
        F,
        //F
        B,
        //B
        C,
        //C
        Construction_Grade_1,
        //1
        Construction_Grade_2,
        //2
        Construction_Grade_3,
        //3
        N_A
    }
    //N/A
    private Construction_Grade_val m_Construction_Grade = Construction_Grade_val.A;
    public Construction_Grade_val getConstruction_Grade() throws Exception {
        return m_Construction_Grade;
    }

    public void setConstruction_Grade(Construction_Grade_val value) throws Exception {
        m_Construction_Grade = value;
    }

    public Construction_Grade_val string_to_Construction_Grade_val(String pKey) throws Exception {
        String __dummyScrutVar14 = pKey;
        if (__dummyScrutVar14.equals("A"))
        {
            return Construction_Grade_val.A;
        }
        else //A
        if (__dummyScrutVar14.equals("F"))
        {
            return Construction_Grade_val.F;
        }
        else //F
        if (__dummyScrutVar14.equals("B"))
        {
            return Construction_Grade_val.B;
        }
        else //B
        if (__dummyScrutVar14.equals("C"))
        {
            return Construction_Grade_val.C;
        }
        else //C
        if (__dummyScrutVar14.equals("1"))
        {
            return Construction_Grade_val.Construction_Grade_1;
        }
        else //1
        if (__dummyScrutVar14.equals("2"))
        {
            return Construction_Grade_val.Construction_Grade_2;
        }
        else //2
        if (__dummyScrutVar14.equals("3"))
        {
            return Construction_Grade_val.Construction_Grade_3;
        }
        else //3
        if (__dummyScrutVar14.equals("N/A"))
        {
            return Construction_Grade_val.N_A;
        }
        else
        {
        }        
        throw new Exception("string does not match enum value");
    }

    //N/A
    public String construction_Grade_val_to_String(Construction_Grade_val pKey) throws Exception {
        switch(pKey)
        {
            case A: 
                return "A";
            case F: 
                return "F";
            case B: 
                return "B";
            case C: 
                return "C";
            case Construction_Grade_1: 
                return "1";
            case Construction_Grade_2: 
                return "2";
            case Construction_Grade_3: 
                return "3";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //A
    //F
    //B
    //C
    //1
    //2
    //3
    //N/A
    public enum Crossing_Conditions_val
    {
        //   Attr Name:   Crossing Conditions
        //   Attr Group:Standard
        //   Description:   Describes the crossings conditions of the site
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Unknown
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        None  (None)
        //        At Crossing  (At Crossing)
        Unknown,
        //Unknown
        None,
        //None
        At_Crossing
    }
    //At Crossing
    private Crossing_Conditions_val m_Crossing_Conditions = Crossing_Conditions_val.Unknown;
    public Crossing_Conditions_val getCrossing_Conditions() throws Exception {
        return m_Crossing_Conditions;
    }

    public void setCrossing_Conditions(Crossing_Conditions_val value) throws Exception {
        m_Crossing_Conditions = value;
    }

    public Crossing_Conditions_val string_to_Crossing_Conditions_val(String pKey) throws Exception {
        String __dummyScrutVar16 = pKey;
        if (__dummyScrutVar16.equals("Unknown"))
        {
            return Crossing_Conditions_val.Unknown;
        }
        else //Unknown
        if (__dummyScrutVar16.equals("None"))
        {
            return Crossing_Conditions_val.None;
        }
        else //None
        if (__dummyScrutVar16.equals("At Crossing"))
        {
            return Crossing_Conditions_val.At_Crossing;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //At Crossing
    public String crossing_Conditions_val_to_String(Crossing_Conditions_val pKey) throws Exception {
        switch(pKey)
        {
            case Unknown: 
                return "Unknown";
            case None: 
                return "None";
            case At_Crossing: 
                return "At Crossing";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Unknown
    //None
    //At Crossing
    public enum Installation_or_Replacement_val
    {
        //   Attr Name:   Installation or Replacement
        //   Attr Group:Standard
        //   Description:   Use load factors at installation or load factors at replacement
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   At Installation
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        At Replacement  (Existing)
        At_Installation,
        //New
        At_Replacement
    }
    //Existing
    private Installation_or_Replacement_val m_Installation_or_Replacement = Installation_or_Replacement_val.At_Installation;
    public Installation_or_Replacement_val getInstallation_or_Replacement() throws Exception {
        return m_Installation_or_Replacement;
    }

    public void setInstallation_or_Replacement(Installation_or_Replacement_val value) throws Exception {
        m_Installation_or_Replacement = value;
    }

    public Installation_or_Replacement_val string_to_Installation_or_Replacement_val(String pKey) throws Exception {
        String __dummyScrutVar18 = pKey;
        if (__dummyScrutVar18.equals("At Installation"))
        {
            return Installation_or_Replacement_val.At_Installation;
        }
        else //New
        if (__dummyScrutVar18.equals("At Replacement"))
        {
            return Installation_or_Replacement_val.At_Replacement;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Existing
    public String installation_or_Replacement_val_to_String(Installation_or_Replacement_val pKey) throws Exception {
        switch(pKey)
        {
            case At_Installation: 
                return "At Installation";
            case At_Replacement: 
                return "At Replacement";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //New
    //Existing
    //   Attr Name:   Override Wind
    //   Attr Group:Wind
    //   Description:   Apply fixed wind angle
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Override_Wind;
    public boolean getOverride_Wind() throws Exception {
        return m_Override_Wind;
    }

    public void setOverride_Wind(boolean value) throws Exception {
        m_Override_Wind = value;
    }

    //   Attr Name:   NomWindAngle
    //   Attr Group:Wind
    //   Alt Display Name:Override Wind Angle (Â°)
    //   Description:   Nominal wind angle
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_NomWindAngle;
    public double getNomWindAngle() throws Exception {
        return m_NomWindAngle;
    }

    public void setNomWindAngle(double value) throws Exception {
        m_NomWindAngle = value;
    }

    public enum Terrian_Exposure_val
    {
        //   Attr Name:   Terrian Exposure
        //   Attr Group:Standard
        //   Alt Display Name:Terrain Exposure
        //   Description:   ASCE Terrian Exposure Code
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   N/A
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   No
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        C  (C)
        //        D  (D)
        //        N/A  (N/A)
        B,
        //B
        C,
        //C
        D,
        //D
        N_A
    }
    //N/A
    private Terrian_Exposure_val m_Terrian_Exposure = Terrian_Exposure_val.B;
    public Terrian_Exposure_val getTerrian_Exposure() throws Exception {
        return m_Terrian_Exposure;
    }

    public void setTerrian_Exposure(Terrian_Exposure_val value) throws Exception {
        m_Terrian_Exposure = value;
    }

    public Terrian_Exposure_val string_to_Terrian_Exposure_val(String pKey) throws Exception {
        String __dummyScrutVar20 = pKey;
        if (__dummyScrutVar20.equals("B"))
        {
            return Terrian_Exposure_val.B;
        }
        else //B
        if (__dummyScrutVar20.equals("C"))
        {
            return Terrian_Exposure_val.C;
        }
        else //C
        if (__dummyScrutVar20.equals("D"))
        {
            return Terrian_Exposure_val.D;
        }
        else //D
        if (__dummyScrutVar20.equals("N/A"))
        {
            return Terrian_Exposure_val.N_A;
        }
        else
        {
        }    
        throw new Exception("string does not match enum value");
    }

    //N/A
    public String terrian_Exposure_val_to_String(Terrian_Exposure_val pKey) throws Exception {
        switch(pKey)
        {
            case B: 
                return "B";
            case C: 
                return "C";
            case D: 
                return "D";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //B
    //C
    //D
    //N/A
    //   Attr Name:   Force Coef
    //   Attr Group:Standard
    //   Description:   ASCE Force Coefficient
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   Yes
    private double m_Force_Coef;
    public double getForce_Coef() throws Exception {
        return m_Force_Coef;
    }

    public void setForce_Coef(double value) throws Exception {
        m_Force_Coef = value;
    }

    //   Attr Name:   Apply FSR
    //   Attr Group:ANSI
    //   Description:   Apply ANSI O5.1.2008 Fiber Strength Reduction calculations for wood poles >= 60 feet in length
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Apply_FSR;
    public boolean getApply_FSR() throws Exception {
        return m_Apply_FSR;
    }

    public void setApply_FSR(boolean value) throws Exception {
        m_Apply_FSR = value;
    }

    //   Attr Name:   Strength Reduction Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Î¦ Strength Reduction Factor
    //   Description:   Strength Reduction Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Strength_Reduction_Factor;
    public double getStrength_Reduction_Factor() throws Exception {
        return m_Strength_Reduction_Factor;
    }

    public void setStrength_Reduction_Factor(double value) throws Exception {
        m_Strength_Reduction_Factor = value;
    }

    //   Attr Name:   Load Duration Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:K1 Load Duration Factor
    //   Description:   Load Duration Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Load_Duration_Factor;
    public double getLoad_Duration_Factor() throws Exception {
        return m_Load_Duration_Factor;
    }

    public void setLoad_Duration_Factor(double value) throws Exception {
        m_Load_Duration_Factor = value;
    }

    //   Attr Name:   Immaturity Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:K20 Immaturity Factor
    //   Description:   Immaturity Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Immaturity_Factor;
    public double getImmaturity_Factor() throws Exception {
        return m_Immaturity_Factor;
    }

    public void setImmaturity_Factor(double value) throws Exception {
        m_Immaturity_Factor = value;
    }

    //   Attr Name:   Shaving Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:K21 Shaving Factor
    //   Description:   Shaving Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Shaving_Factor;
    public double getShaving_Factor() throws Exception {
        return m_Shaving_Factor;
    }

    public void setShaving_Factor(double value) throws Exception {
        m_Shaving_Factor = value;
    }

    //   Attr Name:   Processing Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:K22 Processing Factor
    //   Description:   Processing Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Processing_Factor;
    public double getProcessing_Factor() throws Exception {
        return m_Processing_Factor;
    }

    public void setProcessing_Factor(double value) throws Exception {
        m_Processing_Factor = value;
    }

    //   Attr Name:   Degradation Factor
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Kd Degradation Factor
    //   Description:   Degradation Factor
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Degradation_Factor;
    public double getDegradation_Factor() throws Exception {
        return m_Degradation_Factor;
    }

    public void setDegradation_Factor(double value) throws Exception {
        m_Degradation_Factor = value;
    }

    public enum Shear_Area_val
    {
        //   Attr Name:   Shear Area
        //   Attr Group:AS/NZS 7000
        //   Description:   Shear Area
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Tip
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Actual  (Actual)
        Tip,
        //Tip
        Actual
    }
    //Actual
    private Shear_Area_val m_Shear_Area = Shear_Area_val.Tip;
    public Shear_Area_val getShear_Area() throws Exception {
        return m_Shear_Area;
    }

    public void setShear_Area(Shear_Area_val value) throws Exception {
        m_Shear_Area = value;
    }

    public Shear_Area_val string_to_Shear_Area_val(String pKey) throws Exception {
        String __dummyScrutVar22 = pKey;
        if (__dummyScrutVar22.equals("Tip"))
        {
            return Shear_Area_val.Tip;
        }
        else //Tip
        if (__dummyScrutVar22.equals("Actual"))
        {
            return Shear_Area_val.Actual;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Actual
    public String shear_Area_val_to_String(Shear_Area_val pKey) throws Exception {
        switch(pKey)
        {
            case Tip: 
                return "Tip";
            case Actual: 
                return "Actual";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Tip
    //Actual
    public enum ApplyCrossarmAllowance_val
    {
        //   Attr Name:   ApplyCrossarmAllowance
        //   Attr Group:Allowances
        //   Alt Display Name:Apply Crossarm Allowance
        //   Description:   Cable chair allowance on crossarm mode
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Auto
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Yes  (Yes)
        //        No  (No)
        Auto,
        //Auto
        Yes,
        //Yes
        No
    }
    //No
    private ApplyCrossarmAllowance_val m_ApplyCrossarmAllowance = ApplyCrossarmAllowance_val.Auto;
    public ApplyCrossarmAllowance_val getApplyCrossarmAllowance() throws Exception {
        return m_ApplyCrossarmAllowance;
    }

    public void setApplyCrossarmAllowance(ApplyCrossarmAllowance_val value) throws Exception {
        m_ApplyCrossarmAllowance = value;
    }

    public ApplyCrossarmAllowance_val string_to_ApplyCrossarmAllowance_val(String pKey) throws Exception {
        String __dummyScrutVar24 = pKey;
        if (__dummyScrutVar24.equals("Auto"))
        {
            return ApplyCrossarmAllowance_val.Auto;
        }
        else //Auto
        if (__dummyScrutVar24.equals("Yes"))
        {
            return ApplyCrossarmAllowance_val.Yes;
        }
        else //Yes
        if (__dummyScrutVar24.equals("No"))
        {
            return ApplyCrossarmAllowance_val.No;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //No
    public String applyCrossarmAllowance_val_to_String(ApplyCrossarmAllowance_val pKey) throws Exception {
        switch(pKey)
        {
            case Auto: 
                return "Auto";
            case Yes: 
                return "Yes";
            case No: 
                return "No";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Auto
    //Yes
    //No
    //   Attr Name:   CrossarmAllowance
    //   Attr Group:Allowances
    //   Alt Display Name:Cable chair on Arm (lbs)
    //   Description:   Allowance for cable chair on crossarm
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   300
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_CrossarmAllowance;
    public double getCrossarmAllowance() throws Exception {
        return m_CrossarmAllowance;
    }

    public void setCrossarmAllowance(double value) throws Exception {
        m_CrossarmAllowance = value;
    }

    public enum ApplyCableAllowance_val
    {
        //   Attr Name:   ApplyCableAllowance
        //   Attr Group:Allowances
        //   Alt Display Name:Apply Cable Allowance
        //   Description:   Ladder or Chair
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Auto
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Yes  (Yes)
        //        No  (No)
        Auto,
        //Auto
        Yes,
        //Yes
        No
    }
    //No
    private ApplyCableAllowance_val m_ApplyCableAllowance = ApplyCableAllowance_val.Auto;
    public ApplyCableAllowance_val getApplyCableAllowance() throws Exception {
        return m_ApplyCableAllowance;
    }

    public void setApplyCableAllowance(ApplyCableAllowance_val value) throws Exception {
        m_ApplyCableAllowance = value;
    }

    public ApplyCableAllowance_val string_to_ApplyCableAllowance_val(String pKey) throws Exception {
        String __dummyScrutVar26 = pKey;
        if (__dummyScrutVar26.equals("Auto"))
        {
            return ApplyCableAllowance_val.Auto;
        }
        else //Auto
        if (__dummyScrutVar26.equals("Yes"))
        {
            return ApplyCableAllowance_val.Yes;
        }
        else //Yes
        if (__dummyScrutVar26.equals("No"))
        {
            return ApplyCableAllowance_val.No;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //No
    public String applyCableAllowance_val_to_String(ApplyCableAllowance_val pKey) throws Exception {
        switch(pKey)
        {
            case Auto: 
                return "Auto";
            case Yes: 
                return "Yes";
            case No: 
                return "No";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Auto
    //Yes
    //No
    //   Attr Name:   CableAllowance
    //   Attr Group:Allowances
    //   Alt Display Name:Cable allowance (lbs)
    //   Description:   Cable tension allowance for chair or ladder
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   300
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_CableAllowance;
    public double getCableAllowance() throws Exception {
        return m_CableAllowance;
    }

    public void setCableAllowance(double value) throws Exception {
        m_CableAllowance = value;
    }

    public enum Attr_250_Rule_val
    {
        //   Attr Name:   250 Rule
        //   Attr Group:NESC
        //   Description:   Rule applied from NESC 250 when calculating the loads
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Rule 250B
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Rule 250B Alternate  (Rule 250B Alternate)
        //        Rule 250C  (Rule 250C)
        //        Rule 250D  (Rule 250D)
        //        N/A  (N/A)
        Rule_250B,
        //Rule 250B
        Rule_250B_Alternate,
        //Rule 250B Alternate
        Rule_250C,
        //Rule 250C
        Rule_250D,
        //Rule 250D
        N_A
    }
    //N/A
    private Attr_250_Rule_val m_Attr_250_Rule = Attr_250_Rule_val.Rule_250B;
    public Attr_250_Rule_val getAttr_250_Rule() throws Exception {
        return m_Attr_250_Rule;
    }

    public void setAttr_250_Rule(Attr_250_Rule_val value) throws Exception {
        m_Attr_250_Rule = value;
    }

    public Attr_250_Rule_val string_to_Attr_250_Rule_val(String pKey) throws Exception {
        String __dummyScrutVar28 = pKey;
        if (__dummyScrutVar28.equals("Rule 250B"))
        {
            return Attr_250_Rule_val.Rule_250B;
        }
        else //Rule 250B
        if (__dummyScrutVar28.equals("Rule 250B Alternate"))
        {
            return Attr_250_Rule_val.Rule_250B_Alternate;
        }
        else //Rule 250B Alternate
        if (__dummyScrutVar28.equals("Rule 250C"))
        {
            return Attr_250_Rule_val.Rule_250C;
        }
        else //Rule 250C
        if (__dummyScrutVar28.equals("Rule 250D"))
        {
            return Attr_250_Rule_val.Rule_250D;
        }
        else //Rule 250D
        if (__dummyScrutVar28.equals("N/A"))
        {
            return Attr_250_Rule_val.N_A;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //N/A
    public String attr_250_Rule_val_to_String(Attr_250_Rule_val pKey) throws Exception {
        switch(pKey)
        {
            case Rule_250B: 
                return "Rule 250B";
            case Rule_250B_Alternate: 
                return "Rule 250B Alternate";
            case Rule_250C: 
                return "Rule 250C";
            case Rule_250D: 
                return "Rule 250D";
            case N_A: 
                return "N/A";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Rule 250B
    //Rule 250B Alternate
    //Rule 250C
    //Rule 250D
    //N/A
    //   Attr Name:   Vertical LF
    //   Attr Group:Pole LFs
    //   Alt Display Name:Vertical Pole LF
    //   Description:   NESC Vertical Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Vertical_LF;
    public double getVertical_LF() throws Exception {
        return m_Vertical_LF;
    }

    public void setVertical_LF(double value) throws Exception {
        m_Vertical_LF = value;
    }

    //   Attr Name:   TransWind LF
    //   Attr Group:Pole LFs
    //   Alt Display Name:Transverse Wind Pole LF
    //   Description:   NESC Transverse Wind Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   2.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TransWind_LF;
    public double getTransWind_LF() throws Exception {
        return m_TransWind_LF;
    }

    public void setTransWind_LF(double value) throws Exception {
        m_TransWind_LF = value;
    }

    //   Attr Name:   TransTension LF
    //   Attr Group:Pole LFs
    //   Alt Display Name:Wire Tension (Guyed, Junction, Angle) Pole LF
    //   Description:   NESC Transverse Wire Tesnion Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_TransTension_LF;
    public double getTransTension_LF() throws Exception {
        return m_TransTension_LF;
    }

    public void setTransTension_LF(double value) throws Exception {
        m_TransTension_LF = value;
    }

    //   Attr Name:   GeneralLongitude LF
    //   Attr Group:Pole LFs
    //   Alt Display Name:Wire Tension (Unguyed Tangent) Pole LF
    //   Description:   NESC General Non-Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_GeneralLongitude_LF;
    public double getGeneralLongitude_LF() throws Exception {
        return m_GeneralLongitude_LF;
    }

    public void setGeneralLongitude_LF(double value) throws Exception {
        m_GeneralLongitude_LF = value;
    }

    //   Attr Name:   DeadendLongitude LF
    //   Attr Group:Pole LFs
    //   Alt Display Name:Wire Tension (Deadend) Pole LF
    //   Description:   NESC Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DeadendLongitude_LF;
    public double getDeadendLongitude_LF() throws Exception {
        return m_DeadendLongitude_LF;
    }

    public void setDeadendLongitude_LF(double value) throws Exception {
        m_DeadendLongitude_LF = value;
    }

    //   Attr Name:   Guy Vertical LF
    //   Attr Group:Guy LFs
    //   Alt Display Name:Vertical Guy LF
    //   Description:   NESC Vertical Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_Vertical_LF;
    public double getGuy_Vertical_LF() throws Exception {
        return m_Guy_Vertical_LF;
    }

    public void setGuy_Vertical_LF(double value) throws Exception {
        m_Guy_Vertical_LF = value;
    }

    //   Attr Name:   Guy TransWind LF
    //   Attr Group:Guy LFs
    //   Alt Display Name:Transverse Wind Guy LF
    //   Description:   NESC Transverse Wind Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   2.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_TransWind_LF;
    public double getGuy_TransWind_LF() throws Exception {
        return m_Guy_TransWind_LF;
    }

    public void setGuy_TransWind_LF(double value) throws Exception {
        m_Guy_TransWind_LF = value;
    }

    //   Attr Name:   Guy TransTension LF
    //   Attr Group:Guy LFs
    //   Alt Display Name:Wire Tension (Guyed, Junction, Angle) Guy LF
    //   Description:   NESC Transverse Wire Tesnion Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_TransTension_LF;
    public double getGuy_TransTension_LF() throws Exception {
        return m_Guy_TransTension_LF;
    }

    public void setGuy_TransTension_LF(double value) throws Exception {
        m_Guy_TransTension_LF = value;
    }

    //   Attr Name:   Guy GeneralLongitude LF
    //   Attr Group:Guy LFs
    //   Alt Display Name:Wire Tension (Unguyed Tangent) Guy LF
    //   Description:   NESC General Non-Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_GeneralLongitude_LF;
    public double getGuy_GeneralLongitude_LF() throws Exception {
        return m_Guy_GeneralLongitude_LF;
    }

    public void setGuy_GeneralLongitude_LF(double value) throws Exception {
        m_Guy_GeneralLongitude_LF = value;
    }

    //   Attr Name:   Guy DeadendLongitude LF
    //   Attr Group:Guy LFs
    //   Alt Display Name:Wire Tension (Deadend) Guy LF
    //   Description:   NESC Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_DeadendLongitude_LF;
    public double getGuy_DeadendLongitude_LF() throws Exception {
        return m_Guy_DeadendLongitude_LF;
    }

    public void setGuy_DeadendLongitude_LF(double value) throws Exception {
        m_Guy_DeadendLongitude_LF = value;
    }

    //   Attr Name:   Anchor Vertical LF
    //   Attr Group:Anchor LFs
    //   Alt Display Name:Vertical Anchor LF
    //   Description:   NESC Vertical Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_Vertical_LF;
    public double getAnchor_Vertical_LF() throws Exception {
        return m_Anchor_Vertical_LF;
    }

    public void setAnchor_Vertical_LF(double value) throws Exception {
        m_Anchor_Vertical_LF = value;
    }

    //   Attr Name:   Anchor TransWind LF
    //   Attr Group:Anchor LFs
    //   Alt Display Name:Transverse Wind Anchor LF
    //   Description:   NESC Transverse Wind Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   2.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_TransWind_LF;
    public double getAnchor_TransWind_LF() throws Exception {
        return m_Anchor_TransWind_LF;
    }

    public void setAnchor_TransWind_LF(double value) throws Exception {
        m_Anchor_TransWind_LF = value;
    }

    //   Attr Name:   Anchor TransTension LF
    //   Attr Group:Anchor LFs
    //   Alt Display Name:Wire Tension (Guyed, Junction, Angle) Anchor LF
    //   Description:   NESC Transverse Wire Tesnion Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_TransTension_LF;
    public double getAnchor_TransTension_LF() throws Exception {
        return m_Anchor_TransTension_LF;
    }

    public void setAnchor_TransTension_LF(double value) throws Exception {
        m_Anchor_TransTension_LF = value;
    }

    //   Attr Name:   Anchor GeneralLongitude LF
    //   Attr Group:Anchor LFs
    //   Alt Display Name:Wire Tension (Unguyed Tangent) Anchor LF
    //   Description:   NESC General Non-Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_GeneralLongitude_LF;
    public double getAnchor_GeneralLongitude_LF() throws Exception {
        return m_Anchor_GeneralLongitude_LF;
    }

    public void setAnchor_GeneralLongitude_LF(double value) throws Exception {
        m_Anchor_GeneralLongitude_LF = value;
    }

    //   Attr Name:   Anchor DeadendLongitude LF
    //   Attr Group:Anchor LFs
    //   Alt Display Name:Wire Tension (Deadend) Anchor LF
    //   Description:   NESC Deadend Longitudinal Load Factor for applied 250 rule calculations for the selected Construction Grade
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.65
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_DeadendLongitude_LF;
    public double getAnchor_DeadendLongitude_LF() throws Exception {
        return m_Anchor_DeadendLongitude_LF;
    }

    public void setAnchor_DeadendLongitude_LF(double value) throws Exception {
        m_Anchor_DeadendLongitude_LF = value;
    }

    //   Attr Name:   Pole Strength Factor
    //   Attr Group:Standard
    //   Description:   Pole Strength Factor value
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.85
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Pole_Strength_Factor;
    public double getPole_Strength_Factor() throws Exception {
        return m_Pole_Strength_Factor;
    }

    public void setPole_Strength_Factor(double value) throws Exception {
        m_Pole_Strength_Factor = value;
    }

    //   Attr Name:   Manufactured Pole Strength Factor
    //   Attr Group:Strength
    //   Alt Display Name:Mfg Pole Str Factor
    //   Description:   Pole Strength Factor value
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Manufactured_Pole_Strength_Factor;
    public double getManufactured_Pole_Strength_Factor() throws Exception {
        return m_Manufactured_Pole_Strength_Factor;
    }

    public void setManufactured_Pole_Strength_Factor(double value) throws Exception {
        m_Manufactured_Pole_Strength_Factor = value;
    }

    //   Attr Name:   Crossarm Strength Factor
    //   Attr Group:Strength
    //   Description:   Crosarm Strength Factor value
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.50
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Crossarm_Strength_Factor;
    public double getCrossarm_Strength_Factor() throws Exception {
        return m_Crossarm_Strength_Factor;
    }

    public void setCrossarm_Strength_Factor(double value) throws Exception {
        m_Crossarm_Strength_Factor = value;
    }

    //   Attr Name:   Guy Strength Factor
    //   Attr Group:Strength
    //   Description:   Guy Strength Factor value
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.9
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_Strength_Factor;
    public double getGuy_Strength_Factor() throws Exception {
        return m_Guy_Strength_Factor;
    }

    public void setGuy_Strength_Factor(double value) throws Exception {
        m_Guy_Strength_Factor = value;
    }

    //   Attr Name:   Anchor Strength Factor
    //   Attr Group:Strength
    //   Description:   Anchor Strength Factor value
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   1.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Anchor_Strength_Factor;
    public double getAnchor_Strength_Factor() throws Exception {
        return m_Anchor_Strength_Factor;
    }

    public void setAnchor_Strength_Factor(double value) throws Exception {
        m_Anchor_Strength_Factor = value;
    }

    //   Attr Name:   PoleCapacityThreshhold
    //   Attr Group:Threshold
    //   Alt Display Name:Capacity Threshold %
    //   Description:   PoleCapacityThreshhold
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   75
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoleCapacityThreshhold;
    public double getPoleCapacityThreshhold() throws Exception {
        return m_PoleCapacityThreshhold;
    }

    public void setPoleCapacityThreshhold(double value) throws Exception {
        m_PoleCapacityThreshhold = value;
    }

    //   Attr Name:   Guy Inadequate Thresh
    //   Attr Group:Threshold
    //   Alt Display Name:Guy/Anch Inadequate %
    //   Description:
    //   Displayed Units:   store as PERCENT 0 TO 100 display as INVERSE PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.5
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_Inadequate_Thresh;
    public double getGuy_Inadequate_Thresh() throws Exception {
        return m_Guy_Inadequate_Thresh;
    }

    public void setGuy_Inadequate_Thresh(double value) throws Exception {
        m_Guy_Inadequate_Thresh = value;
    }

    //   Attr Name:   Guy At Cap Thresh
    //   Attr Group:Threshold
    //   Alt Display Name:Guy/Anch At Cap %
    //   Description:
    //   Displayed Units:   store as PERCENT 0 TO 100 display as INVERSE PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   2
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_At_Cap_Thresh;
    public double getGuy_At_Cap_Thresh() throws Exception {
        return m_Guy_At_Cap_Thresh;
    }

    public void setGuy_At_Cap_Thresh(double value) throws Exception {
        m_Guy_At_Cap_Thresh = value;
    }

    //   Attr Name:   Guy Near Cap Thresh
    //   Attr Group:Threshold
    //   Alt Display Name:Guy/Anch Near Cap %
    //   Description:
    //   Displayed Units:   store as PERCENT 0 TO 100 display as INVERSE PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Guy_Near_Cap_Thresh;
    public double getGuy_Near_Cap_Thresh() throws Exception {
        return m_Guy_Near_Cap_Thresh;
    }

    public void setGuy_Near_Cap_Thresh(double value) throws Exception {
        m_Guy_Near_Cap_Thresh = value;
    }

    //   Attr Name:   Span Cap Thresh
    //   Attr Group:Threshold
    //   Alt Display Name:Span Load Thresh %
    //   Description:
    //   Displayed Units:   store as PERCENT 0 TO 100 display as INVERSE PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   10
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Span_Cap_Thresh;
    public double getSpan_Cap_Thresh() throws Exception {
        return m_Span_Cap_Thresh;
    }

    public void setSpan_Cap_Thresh(double value) throws Exception {
        m_Span_Cap_Thresh = value;
    }

    //   Attr Name:   BucklingConstUnguyed
    //   Attr Group:Buckling
    //   Alt Display Name:Unguyed Constant
    //   Description:   Buckling constant unguyed
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   2
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingConstUnguyed;
    public double getBucklingConstUnguyed() throws Exception {
        return m_BucklingConstUnguyed;
    }

    public void setBucklingConstUnguyed(double value) throws Exception {
        m_BucklingConstUnguyed = value;
    }

    //   Attr Name:   BucklingConstGuyed
    //   Attr Group:Buckling
    //   Alt Display Name:Guyed Constant
    //   Description:   Buckling constant guyed
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.707106781186548
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingConstGuyed;
    public double getBucklingConstGuyed() throws Exception {
        return m_BucklingConstGuyed;
    }

    public void setBucklingConstGuyed(double value) throws Exception {
        m_BucklingConstGuyed = value;
    }

    //   Attr Name:   BucklingConstGuyedDeadend
    //   Attr Group:Buckling
    //   Alt Display Name:Guyed Deadend Const
    //   Description:   Buckling constant guyed deadend
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00##
    //   Attribute Type:   FLOAT
    //   Default Value:   0.707106781186548
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingConstGuyedDeadend;
    public double getBucklingConstGuyedDeadend() throws Exception {
        return m_BucklingConstGuyedDeadend;
    }

    public void setBucklingConstGuyedDeadend(double value) throws Exception {
        m_BucklingConstGuyedDeadend = value;
    }

    public enum SectionHeightMethod_val
    {
        //   Attr Name:   SectionHeightMethod
        //   Attr Group:Buckling
        //   Alt Display Name:Section Method
        //   Description:   Buckling method
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Standard
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   No
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Percent BCH  (Percent BCH)
        Standard,
        //Standard
        Percent_BCH
    }
    //Percent BCH
    private SectionHeightMethod_val m_SectionHeightMethod = SectionHeightMethod_val.Standard;
    public SectionHeightMethod_val getSectionHeightMethod() throws Exception {
        return m_SectionHeightMethod;
    }

    public void setSectionHeightMethod(SectionHeightMethod_val value) throws Exception {
        m_SectionHeightMethod = value;
    }

    public SectionHeightMethod_val string_to_SectionHeightMethod_val(String pKey) throws Exception {
        String __dummyScrutVar30 = pKey;
        if (__dummyScrutVar30.equals("Standard"))
        {
            return SectionHeightMethod_val.Standard;
        }
        else //Standard
        if (__dummyScrutVar30.equals("Percent BCH"))
        {
            return SectionHeightMethod_val.Percent_BCH;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Percent BCH
    public String sectionHeightMethod_val_to_String(SectionHeightMethod_val pKey) throws Exception {
        switch(pKey)
        {
            case Standard: 
                return "Standard";
            case Percent_BCH: 
                return "Percent BCH";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Standard
    //Percent BCH
    //   Attr Name:   BucklingSectionPercentBCH
    //   Attr Group:Buckling
    //   Alt Display Name:Percent BCH
    //   Description:   Percent of Buckling Column Height to use as Buckling Section
    //   Displayed Units:   store as PERCENT 0 TO 1 display as PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.33333333
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   Yes
    private double m_BucklingSectionPercentBCH;
    public double getBucklingSectionPercentBCH() throws Exception {
        return m_BucklingSectionPercentBCH;
    }

    public void setBucklingSectionPercentBCH(double value) throws Exception {
        m_BucklingSectionPercentBCH = value;
    }

    public enum ReportingAngleMode_val
    {
        //   Attr Name:   ReportingAngleMode
        //   Attr Group:Reporting
        //   Alt Display Name:Report Angle Mode
        //   Description:   Reporting Angle Mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Load
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Wind  (Wind)
        //        Load  (Load)
        //        Relative  (Relative)
        //        Fixed  (Fixed)
        Tip_Deflection,
        //Tip Deflection
        Wind,
        //Wind
        Load,
        //Load
        Relative,
        //Relative
        Fixed
    }
    //Fixed
    private ReportingAngleMode_val m_ReportingAngleMode = ReportingAngleMode_val.Tip_Deflection;
    public ReportingAngleMode_val getReportingAngleMode() throws Exception {
        return m_ReportingAngleMode;
    }

    public void setReportingAngleMode(ReportingAngleMode_val value) throws Exception {
        m_ReportingAngleMode = value;
    }

    public ReportingAngleMode_val string_to_ReportingAngleMode_val(String pKey) throws Exception {
        String __dummyScrutVar32 = pKey;
        if (__dummyScrutVar32.equals("Tip Deflection"))
        {
            return ReportingAngleMode_val.Tip_Deflection;
        }
        else //Tip Deflection
        if (__dummyScrutVar32.equals("Wind"))
        {
            return ReportingAngleMode_val.Wind;
        }
        else //Wind
        if (__dummyScrutVar32.equals("Load"))
        {
            return ReportingAngleMode_val.Load;
        }
        else //Load
        if (__dummyScrutVar32.equals("Relative"))
        {
            return ReportingAngleMode_val.Relative;
        }
        else //Relative
        if (__dummyScrutVar32.equals("Fixed"))
        {
            return ReportingAngleMode_val.Fixed;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Fixed
    public String reportingAngleMode_val_to_String(ReportingAngleMode_val pKey) throws Exception {
        switch(pKey)
        {
            case Tip_Deflection: 
                return "Tip Deflection";
            case Wind: 
                return "Wind";
            case Load: 
                return "Load";
            case Relative: 
                return "Relative";
            case Fixed: 
                return "Fixed";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Tip Deflection
    //Wind
    //Load
    //Relative
    //Fixed
    //   Attr Name:   ReportingAngle
    //   Attr Group:Reporting
    //   Alt Display Name:Reporting Angle (Â°)
    //   Description:   Reporting angle
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   1.5707963267949
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ReportingAngle;
    public double getReportingAngle() throws Exception {
        return m_ReportingAngle;
    }

    public void setReportingAngle(double value) throws Exception {
        m_ReportingAngle = value;
    }

    //   Attr Name:   SpanCapSignal
    //   Attr Group:Reporting
    //   Alt Display Name:Signal Span Over Cap
    //   Description:
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_SpanCapSignal;
    public boolean getSpanCapSignal() throws Exception {
        return m_SpanCapSignal;
    }

    public void setSpanCapSignal(boolean value) throws Exception {
        m_SpanCapSignal = value;
    }

    //   Attr Name:   ArmCapSignal
    //   Attr Group:Reporting
    //   Alt Display Name:Signal Crossarm Over Cap
    //   Description:
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_ArmCapSignal;
    public boolean getArmCapSignal() throws Exception {
        return m_ArmCapSignal;
    }

    public void setArmCapSignal(boolean value) throws Exception {
        m_ArmCapSignal = value;
    }

    //   Attr Name:   GuyCapSignal
    //   Attr Group:Reporting
    //   Alt Display Name:Signal Guy Over Cap
    //   Description:
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_GuyCapSignal;
    public boolean getGuyCapSignal() throws Exception {
        return m_GuyCapSignal;
    }

    public void setGuyCapSignal(boolean value) throws Exception {
        m_GuyCapSignal = value;
    }

    //   Attr Name:   AnchorCapSignal
    //   Attr Group:Reporting
    //   Alt Display Name:Signal Anchor Over Cap
    //   Description:
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_AnchorCapSignal;
    public boolean getAnchorCapSignal() throws Exception {
        return m_AnchorCapSignal;
    }

    public void setAnchorCapSignal(boolean value) throws Exception {
        m_AnchorCapSignal = value;
    }

    //   Attr Name:   CarryCapacityUp
    //   Attr Group:Reporting
    //   Alt Display Name:Carry Cap Up
    //   Description:   Carry moment capacy upwards
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_CarryCapacityUp;
    public boolean getCarryCapacityUp() throws Exception {
        return m_CarryCapacityUp;
    }

    public void setCarryCapacityUp(boolean value) throws Exception {
        m_CarryCapacityUp = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


