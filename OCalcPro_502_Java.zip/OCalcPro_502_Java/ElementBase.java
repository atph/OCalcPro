//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.Collections.LCC.CSList;
import CS2JNet.System.LCC.Disposable;
import CS2JNet.System.Reflection.BindingFlags;
import CS2JNet.System.StringSupport;
import java.util.UUID;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.EnumValsList;

//--------------------------------------------------------------------------------------------
//   Class: ElementBase
// Mirrors: PPLElement
//--------------------------------------------------------------------------------------------
public abstract class ElementBase   
{
    String cDescriptionOverride = "";
    public void setDescriptionOverride(String value) throws Exception {
        cDescriptionOverride = value;
    }

    public String getDescriptionOverride() throws Exception {
        return cDescriptionOverride;
    }

    public UUID m_Guid = UUID.randomUUID();
    public void setGuid(String value) throws Exception {
        m_Guid = UUID.fromString(value);
    }

    public String getGuid() throws Exception {
        return m_Guid.toString();
    }

    //Parent
    protected ElementBase m_Parent = null;
    public ElementBase getParent() throws Exception {
        return m_Parent;
    }

    //Children
    private CSList<ElementBase> m_Children = new CSList<ElementBase>();
    public void setChildren(CSList<ElementBase> value) throws Exception {
        m_Children = value;
    }

    public CSList<ElementBase> getChildren() throws Exception {
        return m_Children;
    }

    public IReadOnlyList<ElementBase> getChildren() throws Exception {
        return m_Children.AsReadOnly();
    }

    public abstract boolean isLegalChild(ElementBase pChildCandidate) throws Exception ;

    public void addChild(ElementBase pChild) throws Exception {
        if (!isLegalChild(pChild))
            throw new Exception("element is not a legal child of this type");
         
        m_Children.add(pChild);
        pChild.m_Parent = this;
    }

    public void removeChild(ElementBase pChild) throws Exception {
        if (!m_Children.contains(pChild))
            throw new Exception("element is not a child of this element");
         
        m_Children.remove(pChild);
    }

    //Write
    public abstract String xMLkey() throws Exception ;

    public void saveToXML(XmlTextWriter pWriter) throws Exception {
        pWriter.WriteStartElement(xMLkey());
        pWriter.WriteStartElement("ATTRIBUTES");
        for (Object __dummyForeachVar0 : this.getClass().GetProperties(BindingFlags.getInstance() | BindingFlags.getPublic() | BindingFlags.SetProperty | BindingFlags.GetProperty))
        {
            PropertyInfo fi = (PropertyInfo)__dummyForeachVar0;
            String sname = fi.Name.Replace("_", " ");
            if (StringSupport.equals(sname, "Children"))
                continue;
             
            String stype = fi.PropertyType.Name.toString();
            String sval = fi.GetValue(this).toString();
            if (stype.endsWith("_val"))
            {
                sval = EnumValsList.enumToString(sval);
                stype = "String";
            }
             
            pWriter.WriteStartElement("VALUE");
            pWriter.WriteAttributeString("NAME", sname);
            pWriter.WriteAttributeString("TYPE", stype);
            pWriter.WriteString(sval);
            pWriter.WriteEndElement();
        }
        pWriter.WriteEndElement();
        pWriter.WriteStartElement("PPLChildElements");
        for (ElementBase elem : this.m_Children)
        {
            elem.saveToXML(pWriter);
        }
        pWriter.WriteEndElement();
        pWriter.WriteEndElement();
    }

}


