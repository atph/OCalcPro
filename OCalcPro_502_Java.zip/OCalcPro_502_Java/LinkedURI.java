//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: LinkedURI
// Mirrors: PPLLinkedURI : PPLElement
//--------------------------------------------------------------------------------------------
public class LinkedURI  extends ElementBase 
{
    public static String gXMLkey = "LinkedURI";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public LinkedURI(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Link";
            m_Owner = "<Undefined>";
            m_URI = "";
            m_Viewer = Viewer_val.External;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the link
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Link
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   URI
    //   Attr Group:Standard
    //   Description:   Universal Resource Identifier
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   URI
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_URI;
    public String getURI() throws Exception {
        return m_URI;
    }

    public void setURI(String value) throws Exception {
        m_URI = value;
    }

    public enum Viewer_val
    {
        //   Attr Name:   Viewer
        //   Attr Group:Standard
        //   Description:   Viewer to use
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   External
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        External  (External)
        Built_in,
        //Built in
        External
    }
    //External
    private Viewer_val m_Viewer = Viewer_val.Built_in;
    public Viewer_val getViewer() throws Exception {
        return m_Viewer;
    }

    public void setViewer(Viewer_val value) throws Exception {
        m_Viewer = value;
    }

    public Viewer_val string_to_Viewer_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Built in"))
        {
            return Viewer_val.Built_in;
        }
        else //Built in
        if (__dummyScrutVar0.equals("External"))
        {
            return Viewer_val.External;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //External
    public String viewer_val_to_String(Viewer_val pKey) throws Exception {
        switch(pKey)
        {
            case Built_in: 
                return "Built in";
            case External: 
                return "External";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Built in
    //External
    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


