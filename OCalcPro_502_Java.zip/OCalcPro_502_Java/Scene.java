//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.CompositePole;
import PPL_Model_Wrapper.ConcretePole;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.MultiPoleStructure;
import PPL_Model_Wrapper.SegmentedPole;
import PPL_Model_Wrapper.SteelPole;
import PPL_Model_Wrapper.WoodPole;

//--------------------------------------------------------------------------------------------
//   Class: Scene
// Mirrors: PPLGroundLine : PPLElement
//--------------------------------------------------------------------------------------------
public class Scene  extends ElementBase 
{
    public static String gXMLkey = "PPLScene";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Scene(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_SelectedLoadCase = 0;
            m_PPLVersion = 502;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof WoodPole)
            return true;
         
        if (pChildCandidate instanceof SteelPole)
            return true;
         
        if (pChildCandidate instanceof ConcretePole)
            return true;
         
        if (pChildCandidate instanceof CompositePole)
            return true;
         
        if (pChildCandidate instanceof SegmentedPole)
            return true;
         
        if (pChildCandidate instanceof MultiPoleStructure)
            return true;
         
        return false;
    }

    //   Attr Name:   SelectedLoadCase
    //   Attr Group:Standard
    //   Alt Display Name:
    //   Description:   SelectedLoadCase
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   INTEGER
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_SelectedLoadCase;
    public int getSelectedLoadCase() throws Exception {
        return m_SelectedLoadCase;
    }

    public void setSelectedLoadCase(int value) throws Exception {
        m_SelectedLoadCase = value;
    }

    //   Attr Name:   PPLVersion
    //   Attr Group:Standard
    //   Alt Display Name:
    //   Description:   PPLVersion
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   INTEGER
    //   Default Value:   502
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_PPLVersion;
    public int getPPLVersion() throws Exception {
        return m_PPLVersion;
    }

    public void setPPLVersion(int value) throws Exception {
        m_PPLVersion = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


