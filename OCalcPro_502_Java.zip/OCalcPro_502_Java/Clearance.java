//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Clearance
// Mirrors: PPLClearance : PPLElement
//--------------------------------------------------------------------------------------------
public class Clearance  extends ElementBase 
{
    public static String gXMLkey = "Clearance";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Clearance(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Clearance";
            m_Render = false;
            m_Mode = Mode_val.Automatic;
            m_SagMinimum = 0;
            m_SagNominal = 0;
            m_SagMaximum = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the clearance item
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Clearance
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    public enum Group_val
    {
    }
    //   Attr Name:   Group
    //   Attr Group:Standard
    //   Alt Display Name:Clearance Group
    //   Description:   The clearance group
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   ENUMERATED
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private Group_val m_Group;
    public Group_val getGroup() throws Exception {
        return m_Group;
    }

    public void setGroup(Group_val value) throws Exception {
        m_Group = value;
    }

    public Group_val string_to_Group_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        throw new Exception("string does not match enum value");
    }

    public String group_val_to_String(Group_val pKey) throws Exception {
        switch(pKey)
        {
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //   Attr Name:   Render
    //   Attr Group:Standard
    //   Alt Display Name:Render in 3D view
    //   Description:   Render
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_Render;
    public boolean getRender() throws Exception {
        return m_Render;
    }

    public void setRender(boolean value) throws Exception {
        m_Render = value;
    }

    public enum Mode_val
    {
        //   Attr Name:   Mode
        //   Attr Group:Standard
        //   Alt Display Name:Population Mode
        //   Description:   The population
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Automatic
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Automatic  (Automatic)
        //        External  (External)
        Manual,
        //Manual
        Automatic,
        //Automatic
        External
    }
    //External
    private Mode_val m_Mode = Mode_val.Manual;
    public Mode_val getMode() throws Exception {
        return m_Mode;
    }

    public void setMode(Mode_val value) throws Exception {
        m_Mode = value;
    }

    public Mode_val string_to_Mode_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Manual"))
        {
            return Mode_val.Manual;
        }
        else //Manual
        if (__dummyScrutVar2.equals("Automatic"))
        {
            return Mode_val.Automatic;
        }
        else //Automatic
        if (__dummyScrutVar2.equals("External"))
        {
            return Mode_val.External;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //External
    public String mode_val_to_String(Mode_val pKey) throws Exception {
        switch(pKey)
        {
            case Manual: 
                return "Manual";
            case Automatic: 
                return "Automatic";
            case External: 
                return "External";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Manual
    //Automatic
    //External
    //   Attr Name:   SagMinimum
    //   Attr Group:Standard
    //   Alt Display Name:Sag Minimum (ft)
    //   Description:   The vertical deflection minimum
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SagMinimum;
    public double getSagMinimum() throws Exception {
        return m_SagMinimum;
    }

    public void setSagMinimum(double value) throws Exception {
        m_SagMinimum = value;
    }

    //   Attr Name:   SagNominal
    //   Attr Group:Standard
    //   Alt Display Name:Sag Nominal (ft)
    //   Description:   The vertical deflection nominal
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SagNominal;
    public double getSagNominal() throws Exception {
        return m_SagNominal;
    }

    public void setSagNominal(double value) throws Exception {
        m_SagNominal = value;
    }

    //   Attr Name:   SagMaximum
    //   Attr Group:Standard
    //   Alt Display Name:Sag Maximum (ft)
    //   Description:   The vertical deflection maximum
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SagMaximum;
    public double getSagMaximum() throws Exception {
        return m_SagMaximum;
    }

    public void setSagMaximum(double value) throws Exception {
        m_SagMaximum = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


