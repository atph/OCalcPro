//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.Collections.LCC.CSList;
import CS2JNet.System.LCC.Disposable;
import CS2JNet.System.StringSupport;

//--------------------------------------------------------------------------------------------
//   Class: ValTable
//--------------------------------------------------------------------------------------------
public class ValTable   
{
    public ValTable() throws Exception {
    }

    public ValTable(String pTokens) throws Exception {
        parseTokens(pTokens);
    }

    public static class ValuePair   
    {
        public ValuePair() throws Exception {
            setPosition(0);
            setValueAtPosition(0);
        }

        private double __Position;
        public void setPosition(double value) {
            __Position = value;
        }

        public double getPosition() {
            return __Position;
        }

        private double __ValueAtPosition;
        public void setValueAtPosition(double value) {
            __ValueAtPosition = value;
        }

        public double getValueAtPosition() {
            return __ValueAtPosition;
        }
    
    }

    private CSList<ValuePair> m_DataValues = new CSList<ValuePair>();
    public void setDataValues(CSList<ValuePair> value) throws Exception {
        m_DataValues = value;
    }

    public CSList<ValuePair> getDataValues() throws Exception {
        return m_DataValues;
    }

    private String __Label;
    public void setLabel(String value) {
        __Label = value;
    }

    public String getLabel() {
        return __Label;
    }

    public void parseTokens(String pTokens) throws Exception {
        String[] toks = StringSupport.Split(pTokens, ';');
        System.Diagnostics.Debug.Assert(toks.length >= 2);
        try
        {
            setLabel(toks[0]);
        }
        catch (Exception __dummyCatchVar1)
        {
        }

        try
        {
            for (int idx = 1;idx < toks.length;idx++)
            {
                String s = StringSupport.Trim(toks[idx]);
                if (StringSupport.equals(s, ""))
                    continue;
                 
                try
                {
                    String[] vp = StringSupport.Split(s, ',');
                    System.Diagnostics.Debug.Assert(vp.length == 2);
                    ValuePair tvp = new ValuePair();
                    tvp.setPosition(Convert.ToDouble(vp[0]));
                    tvp.setValueAtPosition(Convert.ToDouble(vp[1]));
                    m_DataValues.add(tvp);
                }
                catch (Exception __dummyCatchVar2)
                {
                }
            
            }
        }
        catch (Exception __dummyCatchVar3)
        {
        }
    
    }

    public String buildTokens() throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(getLabel());
        sb.append(';');
        for (ValuePair tvp : m_DataValues)
        {
            sb.append(String.valueOf(tvp.getPosition()));
            sb.append(',');
            sb.append(String.valueOf(tvp.getValueAtPosition()));
            sb.append(';');
        }
        return sb.toString();
    }

    public String toString() {
        try
        {
            return buildTokens();
        }
        catch (RuntimeException __dummyCatchVar4)
        {
            throw __dummyCatchVar4;
        }
        catch (Exception __dummyCatchVar4)
        {
            throw new RuntimeException(__dummyCatchVar4);
        }
    
    }

}


