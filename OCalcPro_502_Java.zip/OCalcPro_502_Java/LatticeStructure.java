//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LatticeSection;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: LatticeStructure
// Mirrors: PPLLatticeStructure : PPLElement
//--------------------------------------------------------------------------------------------
public class LatticeStructure  extends ElementBase 
{
    public static String gXMLkey = "LatticeStructure";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public LatticeStructure(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Pole_Number = "Unset";
            m_Owner = "Pole";
            m_LineOfLead = 0;
            m_NodeRenderDiam = 12;
            m_BeamRenderDiam = 6;
            m_RenderLoads = false;
            m_GravitationalAccellerationX = 0;
            m_GravitationalAccellerationY = 0;
            m_GravitationalAccellerationZ = 2.68116666666667;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof LatticeSection)
            return true;
         
        if (pChildCandidate instanceof LoadCase)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Pole Number
    //   Attr Group:Standard
    //   Description:   Structure ID
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Pole_Number;
    public String getPole_Number() throws Exception {
        return m_Pole_Number;
    }

    public void setPole_Number(String value) throws Exception {
        m_Pole_Number = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Pole
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   LineOfLead
    //   Attr Group:Standard
    //   Alt Display Name:Line of Lead (Â°)
    //   Description:   The overall line of lead of the entire pole assembly
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LineOfLead;
    public double getLineOfLead() throws Exception {
        return m_LineOfLead;
    }

    public void setLineOfLead(double value) throws Exception {
        m_LineOfLead = value;
    }

    //   Attr Name:   NodeRenderDiam
    //   Attr Group:Standard
    //   Alt Display Name:Node Render (in)
    //   Description:   Node render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   12
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_NodeRenderDiam;
    public double getNodeRenderDiam() throws Exception {
        return m_NodeRenderDiam;
    }

    public void setNodeRenderDiam(double value) throws Exception {
        m_NodeRenderDiam = value;
    }

    //   Attr Name:   BeamRenderDiam
    //   Attr Group:Standard
    //   Alt Display Name:Beam Render (in)
    //   Description:   Beam render diameter
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   6
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BeamRenderDiam;
    public double getBeamRenderDiam() throws Exception {
        return m_BeamRenderDiam;
    }

    public void setBeamRenderDiam(double value) throws Exception {
        m_BeamRenderDiam = value;
    }

    //   Attr Name:   RenderLoads
    //   Attr Group:Standard
    //   Alt Display Name:Render Loads
    //   Description:   Render loads
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_RenderLoads;
    public boolean getRenderLoads() throws Exception {
        return m_RenderLoads;
    }

    public void setRenderLoads(boolean value) throws Exception {
        m_RenderLoads = value;
    }

    //   Attr Name:   GravitationalAccellerationX
    //   Attr Group:Gravity
    //   Alt Display Name:Grav Accel X (ft/s/s)
    //   Description:   GravitationalAccellerationX
    //   Displayed Units:   store as INCHES PERSEC PERSEC display as FEET PERSEC PERSEC or METERS PERSEC PERSEC
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_GravitationalAccellerationX;
    public double getGravitationalAccellerationX() throws Exception {
        return m_GravitationalAccellerationX;
    }

    public void setGravitationalAccellerationX(double value) throws Exception {
        m_GravitationalAccellerationX = value;
    }

    //   Attr Name:   GravitationalAccellerationY
    //   Attr Group:Gravity
    //   Alt Display Name:Grav Accel Y (ft/s/s)
    //   Description:   GravitationalAccellerationY
    //   Displayed Units:   store as INCHES PERSEC PERSEC display as FEET PERSEC PERSEC or METERS PERSEC PERSEC
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_GravitationalAccellerationY;
    public double getGravitationalAccellerationY() throws Exception {
        return m_GravitationalAccellerationY;
    }

    public void setGravitationalAccellerationY(double value) throws Exception {
        m_GravitationalAccellerationY = value;
    }

    //   Attr Name:   GravitationalAccellerationZ
    //   Attr Group:Gravity
    //   Alt Display Name:Grav Accel Z (ft/s/s)
    //   Description:   GravitationalAccellerationZ
    //   Displayed Units:   store as INCHES PERSEC PERSEC display as FEET PERSEC PERSEC or METERS PERSEC PERSEC
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.000
    //   Attribute Type:   FLOAT
    //   Default Value:   2.68116666666667
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_GravitationalAccellerationZ;
    public double getGravitationalAccellerationZ() throws Exception {
        return m_GravitationalAccellerationZ;
    }

    public void setGravitationalAccellerationZ(double value) throws Exception {
        m_GravitationalAccellerationZ = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


