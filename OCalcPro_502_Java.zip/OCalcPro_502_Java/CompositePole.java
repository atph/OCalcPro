//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Anchor;
import PPL_Model_Wrapper.CapacityAdjustment;
import PPL_Model_Wrapper.Crossarm;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.NodeJunction;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.PowerEquipment;
import PPL_Model_Wrapper.Riser;
import PPL_Model_Wrapper.Streetlight;
import PPL_Model_Wrapper.ValTable;

//--------------------------------------------------------------------------------------------
//   Class: CompositePole
// Mirrors: PPLCompositePole : PPLElement
//--------------------------------------------------------------------------------------------
public class CompositePole  extends ElementBase 
{
    public static String gXMLkey = "CompositePole";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public CompositePole(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Pole_Number = "Unset";
            m_Owner = "Pole";
            m_Structure_Type = Structure_Type_val.Auto;
            m_Class = "4";
            m_LengthInInches = 480;
            m_CatalogName = "User Defined";
            m_Pole_Code = Pole_Code_val.GO_95;
            m_Shape = Shape_val.Polygonal;
            m_Faces = 4;
            m_Mount = Mount_val.Pedestal;
            m_PedestalRadius = 16;
            m_BuryDepthInInches = 72;
            m_LineOfLead = 0;
            m_LeanDirection = 0;
            m_LeanAmount = 0;
            m_RadiusAtTipInInches = 3.3422538049298;
            m_RadiusAtBaseInInches = 9;
            m_OverturnMoment = 0;
            m_Modulus_of_Elasticity = 29000000;
            m_PoissonsRatio = 0.4;
            m_WindDragCoef = 0;
            m_ThermalCoefficient = 2.7E-06;
            m_Density = 0.0347222222222222;
            m_Characteristic_Shear_Strength = 450;
            m_Characteristic_Compression_Strength = 3500;
            m_Effective_Length = -1;
            m_Material_Constant = 1.24;
            m_Offset = 0;
            m_Aux_Data_1 = "Unset";
            m_Aux_Data_2 = "Unset";
            m_Aux_Data_3 = "Unset";
            m_Aux_Data_4 = "Unset";
            m_Aux_Data_5 = "Unset";
            m_Aux_Data_6 = "Unset";
            m_Aux_Data_7 = "Unset";
            m_Aux_Data_8 = "Unset";
            m_ThicknessTable = new ValTable("Thick;0,0.25;");
            m_PedestalMomentCapacity = 90000;
            m_PedestalBucklingCapacity = 9000;
            m_DistToGrade = 0;
            m_MomentCapacityTable = new ValTable("Moment;0,50000;");
            m_BucklingCapacityTable = new ValTable("Buckling;0,5000;");
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Crossarm)
            return true;
         
        if (pChildCandidate instanceof PowerEquipment)
            return true;
         
        if (pChildCandidate instanceof Streetlight)
            return true;
         
        if (pChildCandidate instanceof Insulator)
            return true;
         
        if (pChildCandidate instanceof NodeJunction)
            return true;
         
        if (pChildCandidate instanceof CapacityAdjustment)
            return true;
         
        if (pChildCandidate instanceof Riser)
            return true;
         
        if (pChildCandidate instanceof GenericEquipment)
            return true;
         
        if (pChildCandidate instanceof Anchor)
            return true;
         
        if (pChildCandidate instanceof LoadCase)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Pole Number
    //   Attr Group:Standard
    //   Description:   Pole identification
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Pole_Number;
    public String getPole_Number() throws Exception {
        return m_Pole_Number;
    }

    public void setPole_Number(String value) throws Exception {
        m_Pole_Number = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Pole
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Structure_Type_val
    {
        //   Attr Name:   Structure Type
        //   Attr Group:Standard
        //   Description:   Pole structure type specification
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Auto
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Tangent  (Pole with all wires running in line with each other)
        //        Angle  (Pole with at least one wire that is at an angle relative to the others)
        //        Deadend  (Pole with wires ending at the pole)
        //        Junction  (Pole with wires crossing at or near the pole)
        Auto,
        //Automatically determine the structure type from attached equipment
        Tangent,
        //Pole with all wires running in line with each other
        Angle,
        //Pole with at least one wire that is at an angle relative to the others
        Deadend,
        //Pole with wires ending at the pole
        Junction
    }
    //Pole with wires crossing at or near the pole
    private Structure_Type_val m_Structure_Type = Structure_Type_val.Auto;
    public Structure_Type_val getStructure_Type() throws Exception {
        return m_Structure_Type;
    }

    public void setStructure_Type(Structure_Type_val value) throws Exception {
        m_Structure_Type = value;
    }

    public Structure_Type_val string_to_Structure_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Auto"))
        {
            return Structure_Type_val.Auto;
        }
        else //Automatically determine the structure type from attached equipment
        if (__dummyScrutVar0.equals("Tangent"))
        {
            return Structure_Type_val.Tangent;
        }
        else //Pole with all wires running in line with each other
        if (__dummyScrutVar0.equals("Angle"))
        {
            return Structure_Type_val.Angle;
        }
        else //Pole with at least one wire that is at an angle relative to the others
        if (__dummyScrutVar0.equals("Deadend"))
        {
            return Structure_Type_val.Deadend;
        }
        else //Pole with wires ending at the pole
        if (__dummyScrutVar0.equals("Junction"))
        {
            return Structure_Type_val.Junction;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Pole with wires crossing at or near the pole
    public String structure_Type_val_to_String(Structure_Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Auto: 
                return "Auto";
            case Tangent: 
                return "Tangent";
            case Angle: 
                return "Angle";
            case Deadend: 
                return "Deadend";
            case Junction: 
                return "Junction";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Automatically determine the structure type from attached equipment
    //Pole with all wires running in line with each other
    //Pole with at least one wire that is at an angle relative to the others
    //Pole with wires ending at the pole
    //Pole with wires crossing at or near the pole
    //   Attr Name:   Class
    //   Attr Group:Standard
    //   Alt Display Name:Pole Class
    //   Description:   Pole class specification
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   4
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Class;
    public String getClass() throws Exception {
        return m_Class;
    }

    public void setClass(String value) throws Exception {
        m_Class = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Length (ft)
    //   Description:   Pole length in inches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   480
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   CatalogName
    //   Attr Group:Standard
    //   Alt Display Name:Catalog Name
    //   Description:   Wood species of the pole
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   User Defined
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_CatalogName;
    public String getCatalogName() throws Exception {
        return m_CatalogName;
    }

    public void setCatalogName(String value) throws Exception {
        m_CatalogName = value;
    }

    public enum Pole_Code_val
    {
        //   Attr Name:   Pole Code
        //   Attr Group:Standard
        //   Alt Display Name:Code
        //   Description:   Pole Code
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   GO 95
        //   ReadOnly Value:   Yes
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        GO 95  (GO 95)
        NESC,
        //NESC
        GO_95
    }
    //GO 95
    private Pole_Code_val m_Pole_Code = Pole_Code_val.NESC;
    public Pole_Code_val getPole_Code() throws Exception {
        return m_Pole_Code;
    }

    public void setPole_Code(Pole_Code_val value) throws Exception {
        m_Pole_Code = value;
    }

    public Pole_Code_val string_to_Pole_Code_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("NESC"))
        {
            return Pole_Code_val.NESC;
        }
        else //NESC
        if (__dummyScrutVar2.equals("GO 95"))
        {
            return Pole_Code_val.GO_95;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //GO 95
    public String pole_Code_val_to_String(Pole_Code_val pKey) throws Exception {
        switch(pKey)
        {
            case NESC: 
                return "NESC";
            case GO_95: 
                return "GO 95";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //NESC
    //GO 95
    public enum Shape_val
    {
        //   Attr Name:   Shape
        //   Attr Group:Standard
        //   Description:   Cross section shape
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Polygonal
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Polygonal  (Polygonal)
        Round,
        //Round
        Polygonal
    }
    //Polygonal
    private Shape_val m_Shape = Shape_val.Round;
    public Shape_val getShape() throws Exception {
        return m_Shape;
    }

    public void setShape(Shape_val value) throws Exception {
        m_Shape = value;
    }

    public Shape_val string_to_Shape_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Round"))
        {
            return Shape_val.Round;
        }
        else //Round
        if (__dummyScrutVar4.equals("Polygonal"))
        {
            return Shape_val.Polygonal;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Polygonal
    public String shape_val_to_String(Shape_val pKey) throws Exception {
        switch(pKey)
        {
            case Round: 
                return "Round";
            case Polygonal: 
                return "Polygonal";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Round
    //Polygonal
    //   Attr Name:   Faces
    //   Attr Group:Standard
    //   Alt Display Name:Polygon Faces
    //   Description:   Number of polygon faces
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   PLUSMINUS
    //   Default Value:   4
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private int m_Faces;
    public int getFaces() throws Exception {
        return m_Faces;
    }

    public void setFaces(int value) throws Exception {
        m_Faces = value;
    }

    public enum Mount_val
    {
        //   Attr Name:   Mount
        //   Attr Group:Installation
        //   Alt Display Name:Mount Type
        //   Description:   Mount type
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Pedestal
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Pedestal  (Pedestal)
        Embedded,
        //Embedded
        Pedestal
    }
    //Pedestal
    private Mount_val m_Mount = Mount_val.Embedded;
    public Mount_val getMount() throws Exception {
        return m_Mount;
    }

    public void setMount(Mount_val value) throws Exception {
        m_Mount = value;
    }

    public Mount_val string_to_Mount_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Embedded"))
        {
            return Mount_val.Embedded;
        }
        else //Embedded
        if (__dummyScrutVar6.equals("Pedestal"))
        {
            return Mount_val.Pedestal;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Pedestal
    public String mount_val_to_String(Mount_val pKey) throws Exception {
        switch(pKey)
        {
            case Embedded: 
                return "Embedded";
            case Pedestal: 
                return "Pedestal";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Embedded
    //Pedestal
    //   Attr Name:   PedestalRadius
    //   Attr Group:Installation
    //   Alt Display Name:Pedestal Radius (in)
    //   Description:   Radius of pedestal mount
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   16.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PedestalRadius;
    public double getPedestalRadius() throws Exception {
        return m_PedestalRadius;
    }

    public void setPedestalRadius(double value) throws Exception {
        m_PedestalRadius = value;
    }

    //   Attr Name:   BuryDepthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Setting Depth (ft)
    //   Description:   Bury depth in inches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   72
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_BuryDepthInInches;
    public double getBuryDepthInInches() throws Exception {
        return m_BuryDepthInInches;
    }

    public void setBuryDepthInInches(double value) throws Exception {
        m_BuryDepthInInches = value;
    }

    //   Attr Name:   LineOfLead
    //   Attr Group:Standard
    //   Alt Display Name:Line of Lead (Â°)
    //   Description:   The overall line of lead of the entire pole assembly
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LineOfLead;
    public double getLineOfLead() throws Exception {
        return m_LineOfLead;
    }

    public void setLineOfLead(double value) throws Exception {
        m_LineOfLead = value;
    }

    //   Attr Name:   LeanDirection
    //   Attr Group:Standard
    //   Alt Display Name:Lean Direction (Â°)
    //   Description:   Pole lean direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanDirection;
    public double getLeanDirection() throws Exception {
        return m_LeanDirection;
    }

    public void setLeanDirection(double value) throws Exception {
        m_LeanDirection = value;
    }

    //   Attr Name:   LeanAmount
    //   Attr Group:Standard
    //   Alt Display Name:Lean Amount (Â°)
    //   Description:   Pole amount direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanAmount;
    public double getLeanAmount() throws Exception {
        return m_LeanAmount;
    }

    public void setLeanAmount(double value) throws Exception {
        m_LeanAmount = value;
    }

    //   Attr Name:   RadiusAtTipInInches
    //   Attr Group:Circumference
    //   Alt Display Name:Tip Circum (in)
    //   Description:
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.3422538049298
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RadiusAtTipInInches;
    public double getRadiusAtTipInInches() throws Exception {
        return m_RadiusAtTipInInches;
    }

    public void setRadiusAtTipInInches(double value) throws Exception {
        m_RadiusAtTipInInches = value;
    }

    //   Attr Name:   RadiusAtBaseInInches
    //   Attr Group:Circumference
    //   Alt Display Name:Base Circum (in)
    //   Description:   Radius At Base
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   9
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RadiusAtBaseInInches;
    public double getRadiusAtBaseInInches() throws Exception {
        return m_RadiusAtBaseInInches;
    }

    public void setRadiusAtBaseInInches(double value) throws Exception {
        m_RadiusAtBaseInInches = value;
    }

    public enum SoilClass_val
    {
        //   Attr Name:   SoilClass
        //   Attr Group:Overturn
        //   Alt Display Name:Soil Class
        //   Description:   The class of soil at the site of the anchor
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Unset
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Class 1  (Very dense and/or cemented sands, coarse gravel and cobbles)
        //        Class 2  (Dense fine sand, very hard silts and clays (may be preloaded))
        //        Class 3  (Dense sands and gravel, hard silts and clays)
        //        Class 4  (Medium dense sandy gravel, very stiff to hard silts and clays)
        //        Class 5  (Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays)
        //        Class 6  (Loose to medium dense fine to coarse sand, firm to stiff clays and silts)
        //        Class 7  (Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill)
        //        Class 8  (Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays)
        //        Unsset  (Unset)
        Class_0,
        //Sound hard rock, bedrock, unweathered
        Class_1,
        //Very dense and/or cemented sands, coarse gravel and cobbles
        Class_2,
        //Dense fine sand, very hard silts and clays (may be preloaded)
        Class_3,
        //Dense sands and gravel, hard silts and clays
        Class_4,
        //Medium dense sandy gravel, very stiff to hard silts and clays
        Class_5,
        //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        Class_6,
        //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        Class_7,
        //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        Class_8,
        //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        Unsset
    }
    //Unset
    private SoilClass_val m_SoilClass = SoilClass_val.Class_0;
    public SoilClass_val getSoilClass() throws Exception {
        return m_SoilClass;
    }

    public void setSoilClass(SoilClass_val value) throws Exception {
        m_SoilClass = value;
    }

    public SoilClass_val string_to_SoilClass_val(String pKey) throws Exception {
        String __dummyScrutVar8 = pKey;
        if (__dummyScrutVar8.equals("Class 0"))
        {
            return SoilClass_val.Class_0;
        }
        else //Sound hard rock, bedrock, unweathered
        if (__dummyScrutVar8.equals("Class 1"))
        {
            return SoilClass_val.Class_1;
        }
        else //Very dense and/or cemented sands, coarse gravel and cobbles
        if (__dummyScrutVar8.equals("Class 2"))
        {
            return SoilClass_val.Class_2;
        }
        else //Dense fine sand, very hard silts and clays (may be preloaded)
        if (__dummyScrutVar8.equals("Class 3"))
        {
            return SoilClass_val.Class_3;
        }
        else //Dense sands and gravel, hard silts and clays
        if (__dummyScrutVar8.equals("Class 4"))
        {
            return SoilClass_val.Class_4;
        }
        else //Medium dense sandy gravel, very stiff to hard silts and clays
        if (__dummyScrutVar8.equals("Class 5"))
        {
            return SoilClass_val.Class_5;
        }
        else //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        if (__dummyScrutVar8.equals("Class 6"))
        {
            return SoilClass_val.Class_6;
        }
        else //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        if (__dummyScrutVar8.equals("Class 7"))
        {
            return SoilClass_val.Class_7;
        }
        else //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        if (__dummyScrutVar8.equals("Class 8"))
        {
            return SoilClass_val.Class_8;
        }
        else //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        if (__dummyScrutVar8.equals("Unsset"))
        {
            return SoilClass_val.Unsset;
        }
        else
        {
        }          
        throw new Exception("string does not match enum value");
    }

    //Unset
    public String soilClass_val_to_String(SoilClass_val pKey) throws Exception {
        switch(pKey)
        {
            case Class_0: 
                return "Class 0";
            case Class_1: 
                return "Class 1";
            case Class_2: 
                return "Class 2";
            case Class_3: 
                return "Class 3";
            case Class_4: 
                return "Class 4";
            case Class_5: 
                return "Class 5";
            case Class_6: 
                return "Class 6";
            case Class_7: 
                return "Class 7";
            case Class_8: 
                return "Class 8";
            case Unsset: 
                return "Unsset";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Sound hard rock, bedrock, unweathered
    //Very dense and/or cemented sands, coarse gravel and cobbles
    //Dense fine sand, very hard silts and clays (may be preloaded)
    //Dense sands and gravel, hard silts and clays
    //Medium dense sandy gravel, very stiff to hard silts and clays
    //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
    //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
    //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
    //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
    //Unset
    //   Attr Name:   OverturnMoment
    //   Attr Group:Overturn
    //   Alt Display Name:Overturn Moment (ft-lbs)
    //   Description:   Overturn Moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.#
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OverturnMoment;
    public double getOverturnMoment() throws Exception {
        return m_OverturnMoment;
    }

    public void setOverturnMoment(double value) throws Exception {
        m_OverturnMoment = value;
    }

    //   Attr Name:   Modulus of Elasticity
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   Modulus of elasticty for the material
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   29000000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Elasticity;
    public double getModulus_of_Elasticity() throws Exception {
        return m_Modulus_of_Elasticity;
    }

    public void setModulus_of_Elasticity(double value) throws Exception {
        m_Modulus_of_Elasticity = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.4
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000027
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   Density
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Density (lb/ft^3)
    //   Description:   Density for the given species in lbs per cubic inch
    //   Displayed Units:   store as POUNDS PER CUBIC INCH display as POUNDS PER CUBIC FOOT or KILOGRAMS PER CUBIC METER
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0347222222222222
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Density;
    public double getDensity() throws Exception {
        return m_Density;
    }

    public void setDensity(double value) throws Exception {
        m_Density = value;
    }

    //   Attr Name:   Characteristic Shear Strength
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Char Shear Str (psi)
    //   Description:   Characteristic Shear Strength
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   450
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Characteristic_Shear_Strength;
    public double getCharacteristic_Shear_Strength() throws Exception {
        return m_Characteristic_Shear_Strength;
    }

    public void setCharacteristic_Shear_Strength(double value) throws Exception {
        m_Characteristic_Shear_Strength = value;
    }

    //   Attr Name:   Characteristic Compression Strength
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Char Compression Str (psi)
    //   Description:   Characteristic Compression Strength
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   3500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Characteristic_Compression_Strength;
    public double getCharacteristic_Compression_Strength() throws Exception {
        return m_Characteristic_Compression_Strength;
    }

    public void setCharacteristic_Compression_Strength(double value) throws Exception {
        m_Characteristic_Compression_Strength = value;
    }

    //   Attr Name:   Effective Length
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Effective Length (ft)
    //   Description:   Effective Length
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0#
    //   Attribute Type:   FLOAT
    //   Default Value:   -1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Effective_Length;
    public double getEffective_Length() throws Exception {
        return m_Effective_Length;
    }

    public void setEffective_Length(double value) throws Exception {
        m_Effective_Length = value;
    }

    //   Attr Name:   Material Constant
    //   Attr Group:AS/NZS 7000
    //   Description:   Material Constant
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   1.24
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Material_Constant;
    public double getMaterial_Constant() throws Exception {
        return m_Material_Constant;
    }

    public void setMaterial_Constant(double value) throws Exception {
        m_Material_Constant = value;
    }

    //   Attr Name:   Offset
    //   Attr Group:Multi Pole
    //   Alt Display Name:Offset (ft)
    //   Description:   Pole offset in feet
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_Offset;
    public double getOffset() throws Exception {
        return m_Offset;
    }

    public void setOffset(double value) throws Exception {
        m_Offset = value;
    }

    //   Attr Name:   Aux Data 1
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_1;
    public String getAux_Data_1() throws Exception {
        return m_Aux_Data_1;
    }

    public void setAux_Data_1(String value) throws Exception {
        m_Aux_Data_1 = value;
    }

    //   Attr Name:   Aux Data 2
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_2;
    public String getAux_Data_2() throws Exception {
        return m_Aux_Data_2;
    }

    public void setAux_Data_2(String value) throws Exception {
        m_Aux_Data_2 = value;
    }

    //   Attr Name:   Aux Data 3
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_3;
    public String getAux_Data_3() throws Exception {
        return m_Aux_Data_3;
    }

    public void setAux_Data_3(String value) throws Exception {
        m_Aux_Data_3 = value;
    }

    //   Attr Name:   Aux Data 4
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_4;
    public String getAux_Data_4() throws Exception {
        return m_Aux_Data_4;
    }

    public void setAux_Data_4(String value) throws Exception {
        m_Aux_Data_4 = value;
    }

    //   Attr Name:   Aux Data 5
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_5;
    public String getAux_Data_5() throws Exception {
        return m_Aux_Data_5;
    }

    public void setAux_Data_5(String value) throws Exception {
        m_Aux_Data_5 = value;
    }

    //   Attr Name:   Aux Data 6
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_6;
    public String getAux_Data_6() throws Exception {
        return m_Aux_Data_6;
    }

    public void setAux_Data_6(String value) throws Exception {
        m_Aux_Data_6 = value;
    }

    //   Attr Name:   Aux Data 7
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_7;
    public String getAux_Data_7() throws Exception {
        return m_Aux_Data_7;
    }

    public void setAux_Data_7(String value) throws Exception {
        m_Aux_Data_7 = value;
    }

    //   Attr Name:   Aux Data 8
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_8;
    public String getAux_Data_8() throws Exception {
        return m_Aux_Data_8;
    }

    public void setAux_Data_8(String value) throws Exception {
        m_Aux_Data_8 = value;
    }

    //   Attr Name:   ThicknessTable
    //   Attr Group:Standard
    //   Alt Display Name:Thickness
    //   Description:   The material thickness
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   THICKNESS_TABLE
    //   Default Value:   Thick;0,0.25;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_ThicknessTable = new ValTable();
    public ValTable getThicknessTable() throws Exception {
        return m_ThicknessTable;
    }

    public void setThicknessTable(ValTable value) throws Exception {
        m_ThicknessTable = value;
    }

    //   Attr Name:   PedestalMomentCapacity
    //   Attr Group:Installation
    //   Alt Display Name:Ped Mom Cap (ft-lb)
    //   Description:   The pedestal moment capacity
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   90000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PedestalMomentCapacity;
    public double getPedestalMomentCapacity() throws Exception {
        return m_PedestalMomentCapacity;
    }

    public void setPedestalMomentCapacity(double value) throws Exception {
        m_PedestalMomentCapacity = value;
    }

    //   Attr Name:   PedestalBucklingCapacity
    //   Attr Group:Installation
    //   Alt Display Name:Ped Buck Cap (lbs)
    //   Description:   The pedestal buckling capacity
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   9000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PedestalBucklingCapacity;
    public double getPedestalBucklingCapacity() throws Exception {
        return m_PedestalBucklingCapacity;
    }

    public void setPedestalBucklingCapacity(double value) throws Exception {
        m_PedestalBucklingCapacity = value;
    }

    //   Attr Name:   DistToGrade
    //   Attr Group:Installation
    //   Alt Display Name:Dist To Grade (ft)
    //   Description:   Distance to grade of pedastal mount
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DistToGrade;
    public double getDistToGrade() throws Exception {
        return m_DistToGrade;
    }

    public void setDistToGrade(double value) throws Exception {
        m_DistToGrade = value;
    }

    //   Attr Name:   MomentCapacityTable
    //   Attr Group:Capacity
    //   Alt Display Name:Moment Cap (ft-lb)
    //   Description:   The moment capacity table
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   MOMENT_TABLE
    //   Default Value:   Moment;0,50000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_MomentCapacityTable = new ValTable();
    public ValTable getMomentCapacityTable() throws Exception {
        return m_MomentCapacityTable;
    }

    public void setMomentCapacityTable(ValTable value) throws Exception {
        m_MomentCapacityTable = value;
    }

    //   Attr Name:   BucklingCapacityTable
    //   Attr Group:Capacity
    //   Alt Display Name:Buckling Cap (lbs)
    //   Description:   The buckling capacity table
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BUCKLING_TABLE
    //   Default Value:   Buckling;0,5000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_BucklingCapacityTable = new ValTable();
    public ValTable getBucklingCapacityTable() throws Exception {
        return m_BucklingCapacityTable;
    }

    public void setBucklingCapacityTable(ValTable value) throws Exception {
        m_BucklingCapacityTable = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


