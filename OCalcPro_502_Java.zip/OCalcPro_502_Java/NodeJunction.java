//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: NodeJunction
// Mirrors: PPLJunctionNode : PPLElement
//--------------------------------------------------------------------------------------------
public class NodeJunction  extends ElementBase 
{
    public static String gXMLkey = "NodeJunction";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public NodeJunction(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Junction";
            m_Owner = "<Undefined>";
            m_Node = "<node>";
            m_CoordinateZ = 300;
            m_CoordinateA = 0;
            m_Side = Side_val.Inline;
            m_CoordinateX = 0;
            m_WidthInInches = 3;
            m_Weight = 1;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the insulator.
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Junction
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   Node
    //   Attr Group:Standard
    //   Description:   Node
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <node>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Node;
    public String getNode() throws Exception {
        return m_Node;
    }

    public void setNode(String value) throws Exception {
        m_Node = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:   The Z coordinate relative to the parent.  This value is frequently set by SnapToParent
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   300.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation of the insulator / span holder relative to its parent.  If the orientation is non-zero the stalk with lean alone this axis
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    public enum Side_val
    {
        //   Attr Name:   Side
        //   Attr Group:Standard
        //   Alt Display Name:Position
        //   Description:   The junction position.
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Inline
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Street  (Street)
        //        Field  (Field)
        //        Inline  (Inline)
        //        Front  (Front)
        //        Back  (Back)
        //        Both  (Both)
        Tip,
        //Tip
        Street,
        //Street
        Field,
        //Field
        Inline,
        //Inline
        Front,
        //Front
        Back,
        //Back
        Both
    }
    //Both
    private Side_val m_Side = Side_val.Tip;
    public Side_val getSide() throws Exception {
        return m_Side;
    }

    public void setSide(Side_val value) throws Exception {
        m_Side = value;
    }

    public Side_val string_to_Side_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Tip"))
        {
            return Side_val.Tip;
        }
        else //Tip
        if (__dummyScrutVar0.equals("Street"))
        {
            return Side_val.Street;
        }
        else //Street
        if (__dummyScrutVar0.equals("Field"))
        {
            return Side_val.Field;
        }
        else //Field
        if (__dummyScrutVar0.equals("Inline"))
        {
            return Side_val.Inline;
        }
        else //Inline
        if (__dummyScrutVar0.equals("Front"))
        {
            return Side_val.Front;
        }
        else //Front
        if (__dummyScrutVar0.equals("Back"))
        {
            return Side_val.Back;
        }
        else //Back
        if (__dummyScrutVar0.equals("Both"))
        {
            return Side_val.Both;
        }
        else
        {
        }       
        throw new Exception("string does not match enum value");
    }

    //Both
    public String side_val_to_String(Side_val pKey) throws Exception {
        switch(pKey)
        {
            case Tip: 
                return "Tip";
            case Street: 
                return "Street";
            case Field: 
                return "Field";
            case Inline: 
                return "Inline";
            case Front: 
                return "Front";
            case Back: 
                return "Back";
            case Both: 
                return "Both";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Tip
    //Street
    //Field
    //Inline
    //Front
    //Back
    //Both
    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:Horizontal Offset (in)
    //   Description:   Distance from the center of the parent.  In the case of a crossarm this is the position along the arm.  In the case of poles this is typically set by SnapToParent
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   WidthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Unit Width (in)
    //   Description:   The effective width for wind area of the junction bolt
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WidthInInches;
    public double getWidthInInches() throws Exception {
        return m_WidthInInches;
    }

    public void setWidthInInches(double value) throws Exception {
        m_WidthInInches = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Standard
    //   Alt Display Name:Unit Weight (lbs)
    //   Description:   Weight of the junction in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   1.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


