//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: NodeConstraint
// Mirrors: PPLNodeConstraint : PPLElement
//--------------------------------------------------------------------------------------------
public class NodeConstraint  extends ElementBase 
{
    public static String gXMLkey = "NodeConstraint";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public NodeConstraint(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Constraint";
            m_Name = "";
            m_LateralConstraints = LateralConstraints_val.X_Y_Z;
            m_RotationConstraints = RotationConstraints_val.XX_YY_ZZ;
            m_RotationHinges = RotationHinges_val.None;
            m_SettleHeaveX = 0;
            m_SettleHeaveY = 0;
            m_SettleHeaveZ = 0;
            m_RackingXX = 0;
            m_RackingYY = 0;
            m_RackingZZ = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the constraint
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Constraint
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the constraint
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    public enum LateralConstraints_val
    {
        //   Attr Name:   LateralConstraints
        //   Attr Group:Standard
        //   Alt Display Name:Lateral Constraints
        //   Description:   Lateral Constraints
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   X,Y,Z
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        X,Y,Z  (X,Y,Z)
        //        X  (X)
        //        Y  (Y)
        //        Z  (Z)
        //        X,Y  (X,Y)
        //        X,Z  (X,Z)
        //        Y,Z  (Y,Z)
        None,
        //None
        X_Y_Z,
        //X,Y,Z
        X,
        //X
        Y,
        //Y
        Z,
        //Z
        X_Y,
        //X,Y
        X_Z,
        //X,Z
        Y_Z
    }
    //Y,Z
    private LateralConstraints_val m_LateralConstraints = LateralConstraints_val.None;
    public LateralConstraints_val getLateralConstraints() throws Exception {
        return m_LateralConstraints;
    }

    public void setLateralConstraints(LateralConstraints_val value) throws Exception {
        m_LateralConstraints = value;
    }

    public LateralConstraints_val string_to_LateralConstraints_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("None"))
        {
            return LateralConstraints_val.None;
        }
        else //None
        if (__dummyScrutVar0.equals("X,Y,Z"))
        {
            return LateralConstraints_val.X_Y_Z;
        }
        else //X,Y,Z
        if (__dummyScrutVar0.equals("X"))
        {
            return LateralConstraints_val.X;
        }
        else //X
        if (__dummyScrutVar0.equals("Y"))
        {
            return LateralConstraints_val.Y;
        }
        else //Y
        if (__dummyScrutVar0.equals("Z"))
        {
            return LateralConstraints_val.Z;
        }
        else //Z
        if (__dummyScrutVar0.equals("X,Y"))
        {
            return LateralConstraints_val.X_Y;
        }
        else //X,Y
        if (__dummyScrutVar0.equals("X,Z"))
        {
            return LateralConstraints_val.X_Z;
        }
        else //X,Z
        if (__dummyScrutVar0.equals("Y,Z"))
        {
            return LateralConstraints_val.Y_Z;
        }
        else
        {
        }        
        throw new Exception("string does not match enum value");
    }

    //Y,Z
    public String lateralConstraints_val_to_String(LateralConstraints_val pKey) throws Exception {
        switch(pKey)
        {
            case None: 
                return "None";
            case X_Y_Z: 
                return "X,Y,Z";
            case X: 
                return "X";
            case Y: 
                return "Y";
            case Z: 
                return "Z";
            case X_Y: 
                return "X,Y";
            case X_Z: 
                return "X,Z";
            case Y_Z: 
                return "Y,Z";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //None
    //X,Y,Z
    //X
    //Y
    //Z
    //X,Y
    //X,Z
    //Y,Z
    public enum RotationConstraints_val
    {
        //   Attr Name:   RotationConstraints
        //   Attr Group:Standard
        //   Alt Display Name:Rotation Constraints
        //   Description:   Rotation Constraints
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   XX,YY,ZZ
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        XX,YY,ZZ  (XX,YY,ZZ)
        //        XX  (XX)
        //        YY  (YY)
        //        ZZ  (ZZ)
        //        XX,YY  (XX,YY)
        //        XX,ZZ  (XX,ZZ)
        //        YY,ZZ  (YY,ZZ)
        None,
        //None
        XX_YY_ZZ,
        //XX,YY,ZZ
        XX,
        //XX
        YY,
        //YY
        ZZ,
        //ZZ
        XX_YY,
        //XX,YY
        XX_ZZ,
        //XX,ZZ
        YY_ZZ
    }
    //YY,ZZ
    private RotationConstraints_val m_RotationConstraints = RotationConstraints_val.None;
    public RotationConstraints_val getRotationConstraints() throws Exception {
        return m_RotationConstraints;
    }

    public void setRotationConstraints(RotationConstraints_val value) throws Exception {
        m_RotationConstraints = value;
    }

    public RotationConstraints_val string_to_RotationConstraints_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("None"))
        {
            return RotationConstraints_val.None;
        }
        else //None
        if (__dummyScrutVar2.equals("XX,YY,ZZ"))
        {
            return RotationConstraints_val.XX_YY_ZZ;
        }
        else //XX,YY,ZZ
        if (__dummyScrutVar2.equals("XX"))
        {
            return RotationConstraints_val.XX;
        }
        else //XX
        if (__dummyScrutVar2.equals("YY"))
        {
            return RotationConstraints_val.YY;
        }
        else //YY
        if (__dummyScrutVar2.equals("ZZ"))
        {
            return RotationConstraints_val.ZZ;
        }
        else //ZZ
        if (__dummyScrutVar2.equals("XX,YY"))
        {
            return RotationConstraints_val.XX_YY;
        }
        else //XX,YY
        if (__dummyScrutVar2.equals("XX,ZZ"))
        {
            return RotationConstraints_val.XX_ZZ;
        }
        else //XX,ZZ
        if (__dummyScrutVar2.equals("YY,ZZ"))
        {
            return RotationConstraints_val.YY_ZZ;
        }
        else
        {
        }        
        throw new Exception("string does not match enum value");
    }

    //YY,ZZ
    public String rotationConstraints_val_to_String(RotationConstraints_val pKey) throws Exception {
        switch(pKey)
        {
            case None: 
                return "None";
            case XX_YY_ZZ: 
                return "XX,YY,ZZ";
            case XX: 
                return "XX";
            case YY: 
                return "YY";
            case ZZ: 
                return "ZZ";
            case XX_YY: 
                return "XX,YY";
            case XX_ZZ: 
                return "XX,ZZ";
            case YY_ZZ: 
                return "YY,ZZ";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //None
    //XX,YY,ZZ
    //XX
    //YY
    //ZZ
    //XX,YY
    //XX,ZZ
    //YY,ZZ
    public enum RotationHinges_val
    {
        //   Attr Name:   RotationHinges
        //   Attr Group:Standard
        //   Alt Display Name:Rotation Hinges
        //   Description:   Rotation Hinges
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   None
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   No
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        XX,YY,ZZ  (XX,YY,ZZ)
        //        XX  (XX)
        //        YY  (YY)
        //        ZZ  (ZZ)
        //        XX,YY  (XX,YY)
        //        XX,ZZ  (XX,ZZ)
        //        YY,ZZ  (YY,ZZ)
        None,
        //None
        XX_YY_ZZ,
        //XX,YY,ZZ
        XX,
        //XX
        YY,
        //YY
        ZZ,
        //ZZ
        XX_YY,
        //XX,YY
        XX_ZZ,
        //XX,ZZ
        YY_ZZ
    }
    //YY,ZZ
    private RotationHinges_val m_RotationHinges = RotationHinges_val.None;
    public RotationHinges_val getRotationHinges() throws Exception {
        return m_RotationHinges;
    }

    public void setRotationHinges(RotationHinges_val value) throws Exception {
        m_RotationHinges = value;
    }

    public RotationHinges_val string_to_RotationHinges_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("None"))
        {
            return RotationHinges_val.None;
        }
        else //None
        if (__dummyScrutVar4.equals("XX,YY,ZZ"))
        {
            return RotationHinges_val.XX_YY_ZZ;
        }
        else //XX,YY,ZZ
        if (__dummyScrutVar4.equals("XX"))
        {
            return RotationHinges_val.XX;
        }
        else //XX
        if (__dummyScrutVar4.equals("YY"))
        {
            return RotationHinges_val.YY;
        }
        else //YY
        if (__dummyScrutVar4.equals("ZZ"))
        {
            return RotationHinges_val.ZZ;
        }
        else //ZZ
        if (__dummyScrutVar4.equals("XX,YY"))
        {
            return RotationHinges_val.XX_YY;
        }
        else //XX,YY
        if (__dummyScrutVar4.equals("XX,ZZ"))
        {
            return RotationHinges_val.XX_ZZ;
        }
        else //XX,ZZ
        if (__dummyScrutVar4.equals("YY,ZZ"))
        {
            return RotationHinges_val.YY_ZZ;
        }
        else
        {
        }        
        throw new Exception("string does not match enum value");
    }

    //YY,ZZ
    public String rotationHinges_val_to_String(RotationHinges_val pKey) throws Exception {
        switch(pKey)
        {
            case None: 
                return "None";
            case XX_YY_ZZ: 
                return "XX,YY,ZZ";
            case XX: 
                return "XX";
            case YY: 
                return "YY";
            case ZZ: 
                return "ZZ";
            case XX_YY: 
                return "XX,YY";
            case XX_ZZ: 
                return "XX,ZZ";
            case YY_ZZ: 
                return "YY,ZZ";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //None
    //XX,YY,ZZ
    //XX
    //YY
    //ZZ
    //XX,YY
    //XX,ZZ
    //YY,ZZ
    //   Attr Name:   SettleHeaveX
    //   Attr Group:Standard
    //   Alt Display Name:Settle Heave X (in)
    //   Description:   Prescribed lateral motion in the X axis
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SettleHeaveX;
    public double getSettleHeaveX() throws Exception {
        return m_SettleHeaveX;
    }

    public void setSettleHeaveX(double value) throws Exception {
        m_SettleHeaveX = value;
    }

    //   Attr Name:   SettleHeaveY
    //   Attr Group:Standard
    //   Alt Display Name:Settle Heave Y (in)
    //   Description:   Prescribed lateral motion in the Y axis
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SettleHeaveY;
    public double getSettleHeaveY() throws Exception {
        return m_SettleHeaveY;
    }

    public void setSettleHeaveY(double value) throws Exception {
        m_SettleHeaveY = value;
    }

    //   Attr Name:   SettleHeaveZ
    //   Attr Group:Standard
    //   Alt Display Name:Settle Heave Z (in)
    //   Description:   Prescribed lateral motion in the Z axis
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_SettleHeaveZ;
    public double getSettleHeaveZ() throws Exception {
        return m_SettleHeaveZ;
    }

    public void setSettleHeaveZ(double value) throws Exception {
        m_SettleHeaveZ = value;
    }

    //   Attr Name:   RackingXX
    //   Attr Group:Standard
    //   Alt Display Name:Racking XX (Â°)
    //   Description:   Prescribed rotation in the XX axis
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RackingXX;
    public double getRackingXX() throws Exception {
        return m_RackingXX;
    }

    public void setRackingXX(double value) throws Exception {
        m_RackingXX = value;
    }

    //   Attr Name:   RackingYY
    //   Attr Group:Standard
    //   Alt Display Name:Racking YY (Â°)
    //   Description:   Prescribed rotation in the YY axis
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RackingYY;
    public double getRackingYY() throws Exception {
        return m_RackingYY;
    }

    public void setRackingYY(double value) throws Exception {
        m_RackingYY = value;
    }

    //   Attr Name:   RackingZZ
    //   Attr Group:Standard
    //   Alt Display Name:Racking ZZ (Â°)
    //   Description:   Prescribed rotation in the ZZ axis
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RackingZZ;
    public double getRackingZZ() throws Exception {
        return m_RackingZZ;
    }

    public void setRackingZZ(double value) throws Exception {
        m_RackingZZ = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


