//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: NodeLoad
// Mirrors: PPLNodeLoad : PPLElement
//--------------------------------------------------------------------------------------------
public class NodeLoad  extends ElementBase 
{
    public static String gXMLkey = "NodeLoad";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public NodeLoad(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Applied Load";
            m_Name = "";
            m_LoadX = 0;
            m_LoadY = 0;
            m_LoadZ = 0;
            m_MomentX = 0;
            m_MomentY = 0;
            m_MomentZ = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Applied Load
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Name
    //   Attr Group:Standard
    //   Description:   Name of the load
    //   User Level Required:   Limited users can NOT access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Name;
    public String getName() throws Exception {
        return m_Name;
    }

    public void setName(String value) throws Exception {
        m_Name = value;
    }

    //   Attr Name:   LoadX
    //   Attr Group:Standard
    //   Alt Display Name:Load X lbs
    //   Description:   Applied load in the X axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadX;
    public double getLoadX() throws Exception {
        return m_LoadX;
    }

    public void setLoadX(double value) throws Exception {
        m_LoadX = value;
    }

    //   Attr Name:   LoadY
    //   Attr Group:Standard
    //   Alt Display Name:Load Y lbs
    //   Description:   Applied load in the Y axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadY;
    public double getLoadY() throws Exception {
        return m_LoadY;
    }

    public void setLoadY(double value) throws Exception {
        m_LoadY = value;
    }

    //   Attr Name:   LoadZ
    //   Attr Group:Standard
    //   Alt Display Name:Load Z lbs
    //   Description:   Applied load in the Z axis
    //   Displayed Units:   store as POUNDS display as POUNDS or NEWTONS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LoadZ;
    public double getLoadZ() throws Exception {
        return m_LoadZ;
    }

    public void setLoadZ(double value) throws Exception {
        m_LoadZ = value;
    }

    //   Attr Name:   MomentX
    //   Attr Group:Standard
    //   Alt Display Name:Moment X (ft-lb)
    //   Description:   Applied Moment in the XX axis
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentX;
    public double getMomentX() throws Exception {
        return m_MomentX;
    }

    public void setMomentX(double value) throws Exception {
        m_MomentX = value;
    }

    //   Attr Name:   MomentY
    //   Attr Group:Standard
    //   Alt Display Name:Moment Y (ft-lb)
    //   Description:   Applied Moment in the YY axis
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentY;
    public double getMomentY() throws Exception {
        return m_MomentY;
    }

    public void setMomentY(double value) throws Exception {
        m_MomentY = value;
    }

    //   Attr Name:   MomentZ
    //   Attr Group:Standard
    //   Alt Display Name:Moment Z (ft-lb)
    //   Description:   Applied Moment in the ZZ axis
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MomentZ;
    public double getMomentZ() throws Exception {
        return m_MomentZ;
    }

    public void setMomentZ(double value) throws Exception {
        m_MomentZ = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


