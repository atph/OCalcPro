//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: SpanAddition
// Mirrors: PPLSpanAddition : PPLElement
//--------------------------------------------------------------------------------------------
public class SpanAddition  extends ElementBase 
{
    public static String gXMLkey = "SpanAddition";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public SpanAddition(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Span Addition";
            m_Owner = "<Undefined>";
            m_Type = Type_val.Aviation_Ball;
            m_OffsetInches = 120;
            m_Size = 20;
            m_Weight = 7;
            m_WindDragCoef = 0;
            m_LoopOrientation = LoopOrientation_val.Vertical;
            m_LoopPosition = LoopPosition_val.Minus;
            m_LeadOne = false;
            m_LeadOnePosition = LeadOnePosition_val.Minus;
            m_LeadOneOffset = 80;
            m_LeadTwo = false;
            m_LeadTwoPosition = LeadTwoPosition_val.Plus;
            m_LeadTwoOffset = 80;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the span addition item
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Span Addition
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Alt Display Name:Addition Type
        //   Description:   The type of the span addition item
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Aviation Ball
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Splice  (Splice)
        //        Damper  (Damper)
        //        Aviation Ball  (Aviation Ball)
        //        Perch Stopper  (Perch Stopper)
        //        Maintenance Loop  (Maintenance Loop)
        //        Other  (Other)
        Cut_Out,
        //Cut-Out
        Splice,
        //Splice
        Damper,
        //Damper
        Aviation_Ball,
        //Aviation Ball
        Perch_Stopper,
        //Perch Stopper
        Maintenance_Loop,
        //Maintenance Loop
        Other
    }
    //Other
    private Type_val m_Type = Type_val.Cut_Out;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Cut-Out"))
        {
            return Type_val.Cut_Out;
        }
        else //Cut-Out
        if (__dummyScrutVar0.equals("Splice"))
        {
            return Type_val.Splice;
        }
        else //Splice
        if (__dummyScrutVar0.equals("Damper"))
        {
            return Type_val.Damper;
        }
        else //Damper
        if (__dummyScrutVar0.equals("Aviation Ball"))
        {
            return Type_val.Aviation_Ball;
        }
        else //Aviation Ball
        if (__dummyScrutVar0.equals("Perch Stopper"))
        {
            return Type_val.Perch_Stopper;
        }
        else //Perch Stopper
        if (__dummyScrutVar0.equals("Maintenance Loop"))
        {
            return Type_val.Maintenance_Loop;
        }
        else //Maintenance Loop
        if (__dummyScrutVar0.equals("Other"))
        {
            return Type_val.Other;
        }
        else
        {
        }       
        throw new Exception("string does not match enum value");
    }

    //Other
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Cut_Out: 
                return "Cut-Out";
            case Splice: 
                return "Splice";
            case Damper: 
                return "Damper";
            case Aviation_Ball: 
                return "Aviation Ball";
            case Perch_Stopper: 
                return "Perch Stopper";
            case Maintenance_Loop: 
                return "Maintenance Loop";
            case Other: 
                return "Other";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Cut-Out
    //Splice
    //Damper
    //Aviation Ball
    //Perch Stopper
    //Maintenance Loop
    //Other
    //   Attr Name:   OffsetInches
    //   Attr Group:Standard
    //   Alt Display Name:Offset Dist (ft)
    //   Description:   Offset distance from pole
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   120.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_OffsetInches;
    public double getOffsetInches() throws Exception {
        return m_OffsetInches;
    }

    public void setOffsetInches(double value) throws Exception {
        m_OffsetInches = value;
    }

    //   Attr Name:   Size
    //   Attr Group:Standard
    //   Alt Display Name:Size (in)
    //   Description:   Size of the addition in the primary dimension
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   20.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Size;
    public double getSize() throws Exception {
        return m_Size;
    }

    public void setSize(double value) throws Exception {
        m_Size = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Standard
    //   Alt Display Name:Weight (lbs)
    //   Description:   Weight of the addition
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   7.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Standard
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    public enum LoopOrientation_val
    {
        //   Attr Name:   LoopOrientation
        //   Attr Group:Loop
        //   Alt Display Name:Loop Orientation
        //   Description:   The loop orientation
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Vertical
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Horizontal  (Horizontal)
        Vertical,
        //Vertical
        Horizontal
    }
    //Horizontal
    private LoopOrientation_val m_LoopOrientation = LoopOrientation_val.Vertical;
    public LoopOrientation_val getLoopOrientation() throws Exception {
        return m_LoopOrientation;
    }

    public void setLoopOrientation(LoopOrientation_val value) throws Exception {
        m_LoopOrientation = value;
    }

    public LoopOrientation_val string_to_LoopOrientation_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Vertical"))
        {
            return LoopOrientation_val.Vertical;
        }
        else //Vertical
        if (__dummyScrutVar2.equals("Horizontal"))
        {
            return LoopOrientation_val.Horizontal;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Horizontal
    public String loopOrientation_val_to_String(LoopOrientation_val pKey) throws Exception {
        switch(pKey)
        {
            case Vertical: 
                return "Vertical";
            case Horizontal: 
                return "Horizontal";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Vertical
    //Horizontal
    public enum LoopPosition_val
    {
        //   Attr Name:   LoopPosition
        //   Attr Group:Loop
        //   Alt Display Name:Loop Position
        //   Description:   The loop position
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Minus
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Center  (Center)
        //        Minus  (Minus)
        Plus,
        //Plus
        Center,
        //Center
        Minus
    }
    //Minus
    private LoopPosition_val m_LoopPosition = LoopPosition_val.Plus;
    public LoopPosition_val getLoopPosition() throws Exception {
        return m_LoopPosition;
    }

    public void setLoopPosition(LoopPosition_val value) throws Exception {
        m_LoopPosition = value;
    }

    public LoopPosition_val string_to_LoopPosition_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Plus"))
        {
            return LoopPosition_val.Plus;
        }
        else //Plus
        if (__dummyScrutVar4.equals("Center"))
        {
            return LoopPosition_val.Center;
        }
        else //Center
        if (__dummyScrutVar4.equals("Minus"))
        {
            return LoopPosition_val.Minus;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Minus
    public String loopPosition_val_to_String(LoopPosition_val pKey) throws Exception {
        switch(pKey)
        {
            case Plus: 
                return "Plus";
            case Center: 
                return "Center";
            case Minus: 
                return "Minus";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Plus
    //Center
    //Minus
    //   Attr Name:   LeadOne
    //   Attr Group:Loop
    //   Alt Display Name:Lead One
    //   Description:   Lead one
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_LeadOne;
    public boolean getLeadOne() throws Exception {
        return m_LeadOne;
    }

    public void setLeadOne(boolean value) throws Exception {
        m_LeadOne = value;
    }

    public enum LeadOnePosition_val
    {
        //   Attr Name:   LeadOnePosition
        //   Attr Group:Loop
        //   Alt Display Name:Lead One Position
        //   Description:   The lead one position
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Minus
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Center  (Center)
        //        Minus  (Minus)
        Plus,
        //Plus
        Center,
        //Center
        Minus
    }
    //Minus
    private LeadOnePosition_val m_LeadOnePosition = LeadOnePosition_val.Plus;
    public LeadOnePosition_val getLeadOnePosition() throws Exception {
        return m_LeadOnePosition;
    }

    public void setLeadOnePosition(LeadOnePosition_val value) throws Exception {
        m_LeadOnePosition = value;
    }

    public LeadOnePosition_val string_to_LeadOnePosition_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Plus"))
        {
            return LeadOnePosition_val.Plus;
        }
        else //Plus
        if (__dummyScrutVar6.equals("Center"))
        {
            return LeadOnePosition_val.Center;
        }
        else //Center
        if (__dummyScrutVar6.equals("Minus"))
        {
            return LeadOnePosition_val.Minus;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Minus
    public String leadOnePosition_val_to_String(LeadOnePosition_val pKey) throws Exception {
        switch(pKey)
        {
            case Plus: 
                return "Plus";
            case Center: 
                return "Center";
            case Minus: 
                return "Minus";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Plus
    //Center
    //Minus
    //   Attr Name:   LeadOneOffset
    //   Attr Group:Loop
    //   Alt Display Name:Lead One Offset (ft)
    //   Description:   Lead One offset distance from pole
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   80.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeadOneOffset;
    public double getLeadOneOffset() throws Exception {
        return m_LeadOneOffset;
    }

    public void setLeadOneOffset(double value) throws Exception {
        m_LeadOneOffset = value;
    }

    //   Attr Name:   LeadTwo
    //   Attr Group:Loop
    //   Alt Display Name:Lead Two
    //   Description:   Lead two
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   Yes
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_LeadTwo;
    public boolean getLeadTwo() throws Exception {
        return m_LeadTwo;
    }

    public void setLeadTwo(boolean value) throws Exception {
        m_LeadTwo = value;
    }

    public enum LeadTwoPosition_val
    {
        //   Attr Name:   LeadTwoPosition
        //   Attr Group:Loop
        //   Alt Display Name:Lead Two Position
        //   Description:   The lead one position
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Plus
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Center  (Center)
        //        Minus  (Minus)
        Plus,
        //Plus
        Center,
        //Center
        Minus
    }
    //Minus
    private LeadTwoPosition_val m_LeadTwoPosition = LeadTwoPosition_val.Plus;
    public LeadTwoPosition_val getLeadTwoPosition() throws Exception {
        return m_LeadTwoPosition;
    }

    public void setLeadTwoPosition(LeadTwoPosition_val value) throws Exception {
        m_LeadTwoPosition = value;
    }

    public LeadTwoPosition_val string_to_LeadTwoPosition_val(String pKey) throws Exception {
        String __dummyScrutVar8 = pKey;
        if (__dummyScrutVar8.equals("Plus"))
        {
            return LeadTwoPosition_val.Plus;
        }
        else //Plus
        if (__dummyScrutVar8.equals("Center"))
        {
            return LeadTwoPosition_val.Center;
        }
        else //Center
        if (__dummyScrutVar8.equals("Minus"))
        {
            return LeadTwoPosition_val.Minus;
        }
        else
        {
        }   
        throw new Exception("string does not match enum value");
    }

    //Minus
    public String leadTwoPosition_val_to_String(LeadTwoPosition_val pKey) throws Exception {
        switch(pKey)
        {
            case Plus: 
                return "Plus";
            case Center: 
                return "Center";
            case Minus: 
                return "Minus";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Plus
    //Center
    //Minus
    //   Attr Name:   LeadTwoOffset
    //   Attr Group:Loop
    //   Alt Display Name:Lead Two Offset (ft)
    //   Description:   Loop top ffset distance from pole
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   80.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeadTwoOffset;
    public double getLeadTwoOffset() throws Exception {
        return m_LeadTwoOffset;
    }

    public void setLeadTwoOffset(double value) throws Exception {
        m_LeadTwoOffset = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


