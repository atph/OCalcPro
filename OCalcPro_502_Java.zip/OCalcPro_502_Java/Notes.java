//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;

//--------------------------------------------------------------------------------------------
//   Class: Notes
// Mirrors: PPLNotes : PPLElement
//--------------------------------------------------------------------------------------------
public class Notes  extends ElementBase 
{
    public static String gXMLkey = "Notes";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Notes(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Note";
            m_Type = Type_val.Normal;
            m_Owner = "<Undefined>";
            m_Author = "";
            m_Date = "";
            m_Contents = "";
            m_Grid = "";
            m_SplitPercent = 0.6;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the note
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Note
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Alt Display Name:Note Type
        //   Description:   Note type
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Normal
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        High Priority  (High Priority)
        //        TBD Initial  (TBD Initial)
        //        TBD Complete  (TBD Complete)
        //        TBD Accepted  (TBD Accepted)
        Normal,
        //Normal
        High_Priority,
        //High Priority
        TBD_Initial,
        //TBD Initial
        TBD_Complete,
        //TBD Complete
        TBD_Accepted
    }
    //TBD Accepted
    private Type_val m_Type = Type_val.Normal;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Normal"))
        {
            return Type_val.Normal;
        }
        else //Normal
        if (__dummyScrutVar0.equals("High Priority"))
        {
            return Type_val.High_Priority;
        }
        else //High Priority
        if (__dummyScrutVar0.equals("TBD Initial"))
        {
            return Type_val.TBD_Initial;
        }
        else //TBD Initial
        if (__dummyScrutVar0.equals("TBD Complete"))
        {
            return Type_val.TBD_Complete;
        }
        else //TBD Complete
        if (__dummyScrutVar0.equals("TBD Accepted"))
        {
            return Type_val.TBD_Accepted;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //TBD Accepted
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Normal: 
                return "Normal";
            case High_Priority: 
                return "High Priority";
            case TBD_Initial: 
                return "TBD Initial";
            case TBD_Complete: 
                return "TBD Complete";
            case TBD_Accepted: 
                return "TBD Accepted";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Normal
    //High Priority
    //TBD Initial
    //TBD Complete
    //TBD Accepted
    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   Author
    //   Attr Group:Standard
    //   Description:   Author of the note
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Author;
    public String getAuthor() throws Exception {
        return m_Author;
    }

    public void setAuthor(String value) throws Exception {
        m_Author = value;
    }

    //   Attr Name:   Date
    //   Attr Group:Standard
    //   Description:   Creation date of the note
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   DATE
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Date;
    public String getDate() throws Exception {
        return m_Date;
    }

    public void setDate(String value) throws Exception {
        m_Date = value;
    }

    //   Attr Name:   Contents
    //   Attr Group:Standard
    //   Description:   RTF Contents
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Contents;
    public String getContents() throws Exception {
        return m_Contents;
    }

    public void setContents(String value) throws Exception {
        m_Contents = value;
    }

    //   Attr Name:   Grid
    //   Attr Group:Standard
    //   Description:   SpreadSheet Contents
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   Yes
    private String m_Grid;
    public String getGrid() throws Exception {
        return m_Grid;
    }

    public void setGrid(String value) throws Exception {
        m_Grid = value;
    }

    //   Attr Name:   SplitPercent
    //   Attr Group:Standard
    //   Description:   Split bar position
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   FLOAT
    //   Default Value:   0.6
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   Yes
    private double m_SplitPercent;
    public double getSplitPercent() throws Exception {
        return m_SplitPercent;
    }

    public void setSplitPercent(double value) throws Exception {
        m_SplitPercent = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


