//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.CompositePole;
import PPL_Model_Wrapper.ConcretePole;
import PPL_Model_Wrapper.Crossarm;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LatticeSection;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.SteelPole;
import PPL_Model_Wrapper.WoodPole;

//--------------------------------------------------------------------------------------------
//   Class: MultiPoleStructure
// Mirrors: PPLMultiPoleStructure : PPLElement
//--------------------------------------------------------------------------------------------
public class MultiPoleStructure  extends ElementBase 
{
    public static String gXMLkey = "MultiPoleStructure";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public MultiPoleStructure(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Pole_Number = "Unset";
            m_Owner = "Pole";
            m_LineOfLead = 0;
            m_ReportingMode = ReportingMode_val.Active_Leg;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof WoodPole)
            return true;
         
        if (pChildCandidate instanceof SteelPole)
            return true;
         
        if (pChildCandidate instanceof ConcretePole)
            return true;
         
        if (pChildCandidate instanceof CompositePole)
            return true;
         
        if (pChildCandidate instanceof Crossarm)
            return true;
         
        if (pChildCandidate instanceof LoadCase)
            return true;
         
        if (pChildCandidate instanceof LatticeSection)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Pole Number
    //   Attr Group:Standard
    //   Description:   Structure ID
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Pole_Number;
    public String getPole_Number() throws Exception {
        return m_Pole_Number;
    }

    public void setPole_Number(String value) throws Exception {
        m_Pole_Number = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Pole
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   LineOfLead
    //   Attr Group:Standard
    //   Alt Display Name:Line of Lead (Â°)
    //   Description:   The overall line of lead of the entire pole assembly
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LineOfLead;
    public double getLineOfLead() throws Exception {
        return m_LineOfLead;
    }

    public void setLineOfLead(double value) throws Exception {
        m_LineOfLead = value;
    }

    public enum ReportingMode_val
    {
        //   Attr Name:   ReportingMode
        //   Attr Group:Standard
        //   Alt Display Name:Reporting Mode
        //   Description:   Reporting Mode
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Active Leg
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Worst Leg  (Worst Leg)
        Active_Leg,
        //Active Leg
        Worst_Leg
    }
    //Worst Leg
    private ReportingMode_val m_ReportingMode = ReportingMode_val.Active_Leg;
    public ReportingMode_val getReportingMode() throws Exception {
        return m_ReportingMode;
    }

    public void setReportingMode(ReportingMode_val value) throws Exception {
        m_ReportingMode = value;
    }

    public ReportingMode_val string_to_ReportingMode_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Active Leg"))
        {
            return ReportingMode_val.Active_Leg;
        }
        else //Active Leg
        if (__dummyScrutVar0.equals("Worst Leg"))
        {
            return ReportingMode_val.Worst_Leg;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Worst Leg
    public String reportingMode_val_to_String(ReportingMode_val pKey) throws Exception {
        switch(pKey)
        {
            case Active_Leg: 
                return "Active Leg";
            case Worst_Leg: 
                return "Worst Leg";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Active Leg
    //Worst Leg
    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


