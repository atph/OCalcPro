//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.ValTable;

//--------------------------------------------------------------------------------------------
//   Class: PoleRestoration
// Mirrors: PPLRestoration : PPLElement
//--------------------------------------------------------------------------------------------
public class PoleRestoration  extends ElementBase 
{
    public static String gXMLkey = "PoleRestoration";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public PoleRestoration(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Type = Type_val.C2;
            m_Description = "Osmose";
            m_Owner = "<Undefined>";
            m_LengthInInches = 120;
            m_MomentCapacityTable = new ValTable("Moment;0,10000;");
            m_CoordinateZ = 160;
            m_CoordinateA = 0;
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   Type of restoration
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   C2
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        C2  (Osmose C2 Truss)
        //        ET  (Osmose ET Truss)
        //        FiberWrap  (Osmose FiberWrap)
        //        FiberWrap II  (Osmose FiberWrap II)
        //        Truss  (Other Truss)
        //        Wrap  (Other Pole Wrap)
        C,
        //Osmose C Truss
        C2,
        //Osmose C2 Truss
        ET,
        //Osmose ET Truss
        FiberWrap,
        //Osmose FiberWrap
        FiberWrap_II,
        //Osmose FiberWrap II
        Truss,
        //Other Truss
        Wrap
    }
    //Other Pole Wrap
    private Type_val m_Type = Type_val.C;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("C"))
        {
            return Type_val.C;
        }
        else //Osmose C Truss
        if (__dummyScrutVar0.equals("C2"))
        {
            return Type_val.C2;
        }
        else //Osmose C2 Truss
        if (__dummyScrutVar0.equals("ET"))
        {
            return Type_val.ET;
        }
        else //Osmose ET Truss
        if (__dummyScrutVar0.equals("FiberWrap"))
        {
            return Type_val.FiberWrap;
        }
        else //Osmose FiberWrap
        if (__dummyScrutVar0.equals("FiberWrap II"))
        {
            return Type_val.FiberWrap_II;
        }
        else //Osmose FiberWrap II
        if (__dummyScrutVar0.equals("Truss"))
        {
            return Type_val.Truss;
        }
        else //Other Truss
        if (__dummyScrutVar0.equals("Wrap"))
        {
            return Type_val.Wrap;
        }
        else
        {
        }       
        throw new Exception("string does not match enum value");
    }

    //Other Pole Wrap
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case C: 
                return "C";
            case C2: 
                return "C2";
            case ET: 
                return "ET";
            case FiberWrap: 
                return "FiberWrap";
            case FiberWrap_II: 
                return "FiberWrap II";
            case Truss: 
                return "Truss";
            case Wrap: 
                return "Wrap";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Osmose C Truss
    //Osmose C2 Truss
    //Osmose ET Truss
    //Osmose FiberWrap
    //Osmose FiberWrap II
    //Other Truss
    //Other Pole Wrap
    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the restoration
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Osmose
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Length (ft)
    //   Description:   The length in iches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   120.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   MomentCapacityTable
    //   Attr Group:Standard
    //   Alt Display Name:Moment Added (ft-lb)
    //   Description:   The moment capacity table
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   MOMENT_TABLE
    //   Default Value:   Moment;0,10000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_MomentCapacityTable = new ValTable();
    public ValTable getMomentCapacityTable() throws Exception {
        return m_MomentCapacityTable;
    }

    public void setMomentCapacityTable(ValTable value) throws Exception {
        m_MomentCapacityTable = value;
    }

    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Top Of Restoration (ft)
    //   Description:   Distance from the butt of the pole to the top of the truss or wrap
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   160.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation angle around the center of the pole
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


