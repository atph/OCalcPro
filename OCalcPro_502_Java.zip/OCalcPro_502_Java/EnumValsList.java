//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:43 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;

public class EnumValsList   
{
    public static String enumToString(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("NESC"))
        {
            return "NESC";
        }
        else if (__dummyScrutVar0.equals("Linear"))
        {
            return "Linear";
        }
        else if (__dummyScrutVar0.equals("Fixed"))
        {
            return "Fixed";
        }
        else if (__dummyScrutVar0.equals("Advanced"))
        {
            return "Advanced";
        }
        else if (__dummyScrutVar0.equals("Cholesky_Decomposition"))
        {
            return "Cholesky Decomposition";
        }
        else if (__dummyScrutVar0.equals("Medium"))
        {
            return "Medium";
        }
        else if (__dummyScrutVar0.equals("WindType_2007"))
        {
            return "2007";
        }
        else if (__dummyScrutVar0.equals("B"))
        {
            return "B";
        }
        else if (__dummyScrutVar0.equals("Unknown"))
        {
            return "Unknown";
        }
        else if (__dummyScrutVar0.equals("At_Installation"))
        {
            return "At Installation";
        }
        else if (__dummyScrutVar0.equals("N_A"))
        {
            return "N/A";
        }
        else if (__dummyScrutVar0.equals("Tip"))
        {
            return "Tip";
        }
        else if (__dummyScrutVar0.equals("Auto"))
        {
            return "Auto";
        }
        else if (__dummyScrutVar0.equals("Rule_250B"))
        {
            return "Rule 250B";
        }
        else if (__dummyScrutVar0.equals("Standard"))
        {
            return "Standard";
        }
        else if (__dummyScrutVar0.equals("Load"))
        {
            return "Load";
        }
        else if (__dummyScrutVar0.equals("GO_95"))
        {
            return "GO 95";
        }
        else if (__dummyScrutVar0.equals("ASCE"))
        {
            return "ASCE";
        }
        else if (__dummyScrutVar0.equals("CSA"))
        {
            return "CSA";
        }
        else if (__dummyScrutVar0.equals("AS_NZS_7000"))
        {
            return "AS/NZS 7000";
        }
        else if (__dummyScrutVar0.equals("Deflection_1_Iteration_P_Delta"))
        {
            return "1 Iteration P-Î”";
        }
        else if (__dummyScrutVar0.equals("Deflection_2nd_Order_P_Delta"))
        {
            return "2nd Order P-Î”";
        }
        else if (__dummyScrutVar0.equals("Pinned"))
        {
            return "Pinned";
        }
        else if (__dummyScrutVar0.equals("Legacy"))
        {
            return "Legacy";
        }
        else if (__dummyScrutVar0.equals("Conjugate_Gradient"))
        {
            return "Conjugate Gradient";
        }
        else if (__dummyScrutVar0.equals("Light"))
        {
            return "Light";
        }
        else if (__dummyScrutVar0.equals("Medium_A"))
        {
            return "Medium A";
        }
        else if (__dummyScrutVar0.equals("Medium_B"))
        {
            return "Medium B";
        }
        else if (__dummyScrutVar0.equals("Heavy"))
        {
            return "Heavy";
        }
        else if (__dummyScrutVar0.equals("Severe"))
        {
            return "Severe";
        }
        else if (__dummyScrutVar0.equals("Manual"))
        {
            return "Manual";
        }
        else if (__dummyScrutVar0.equals("Warm_Island"))
        {
            return "Warm Island";
        }
        else if (__dummyScrutVar0.equals("Special"))
        {
            return "Special";
        }
        else if (__dummyScrutVar0.equals("Unset"))
        {
            return "Unset";
        }
        else if (__dummyScrutVar0.equals("WindType_1997"))
        {
            return "1997";
        }
        else if (__dummyScrutVar0.equals("WindType_2002"))
        {
            return "2002";
        }
        else if (__dummyScrutVar0.equals("WindType_2012"))
        {
            return "2012";
        }
        else if (__dummyScrutVar0.equals("A"))
        {
            return "A";
        }
        else if (__dummyScrutVar0.equals("F"))
        {
            return "F";
        }
        else if (__dummyScrutVar0.equals("C"))
        {
            return "C";
        }
        else if (__dummyScrutVar0.equals("Construction_Grade_1"))
        {
            return "1";
        }
        else if (__dummyScrutVar0.equals("Construction_Grade_2"))
        {
            return "2";
        }
        else if (__dummyScrutVar0.equals("Construction_Grade_3"))
        {
            return "3";
        }
        else if (__dummyScrutVar0.equals("None"))
        {
            return "None";
        }
        else if (__dummyScrutVar0.equals("At_Crossing"))
        {
            return "At Crossing";
        }
        else if (__dummyScrutVar0.equals("At_Replacement"))
        {
            return "At Replacement";
        }
        else if (__dummyScrutVar0.equals("D"))
        {
            return "D";
        }
        else if (__dummyScrutVar0.equals("Actual"))
        {
            return "Actual";
        }
        else if (__dummyScrutVar0.equals("Yes"))
        {
            return "Yes";
        }
        else if (__dummyScrutVar0.equals("No"))
        {
            return "No";
        }
        else if (__dummyScrutVar0.equals("Rule_250B_Alternate"))
        {
            return "Rule 250B Alternate";
        }
        else if (__dummyScrutVar0.equals("Rule_250C"))
        {
            return "Rule 250C";
        }
        else if (__dummyScrutVar0.equals("Rule_250D"))
        {
            return "Rule 250D";
        }
        else if (__dummyScrutVar0.equals("Percent_BCH"))
        {
            return "Percent BCH";
        }
        else if (__dummyScrutVar0.equals("Tip_Deflection"))
        {
            return "Tip Deflection";
        }
        else if (__dummyScrutVar0.equals("Wind"))
        {
            return "Wind";
        }
        else if (__dummyScrutVar0.equals("Relative"))
        {
            return "Relative";
        }
        else if (__dummyScrutVar0.equals("Normal"))
        {
            return "Normal";
        }
        else if (__dummyScrutVar0.equals("High_Priority"))
        {
            return "High Priority";
        }
        else if (__dummyScrutVar0.equals("TBD_Initial"))
        {
            return "TBD Initial";
        }
        else if (__dummyScrutVar0.equals("TBD_Complete"))
        {
            return "TBD Complete";
        }
        else if (__dummyScrutVar0.equals("TBD_Accepted"))
        {
            return "TBD Accepted";
        }
        else if (__dummyScrutVar0.equals("External"))
        {
            return "External";
        }
        else if (__dummyScrutVar0.equals("Built_in"))
        {
            return "Built in";
        }
        else if (__dummyScrutVar0.equals("Simple"))
        {
            return "Simple";
        }
        else if (__dummyScrutVar0.equals("Round"))
        {
            return "Round";
        }
        else if (__dummyScrutVar0.equals("Top"))
        {
            return "Top";
        }
        else if (__dummyScrutVar0.equals("Bottom"))
        {
            return "Bottom";
        }
        else if (__dummyScrutVar0.equals("Polygonal"))
        {
            return "Polygonal";
        }
        else if (__dummyScrutVar0.equals("Height"))
        {
            return "Height";
        }
        else if (__dummyScrutVar0.equals("Radius"))
        {
            return "Radius";
        }
        else if (__dummyScrutVar0.equals("Area"))
        {
            return "Area";
        }
        else if (__dummyScrutVar0.equals("Area_Squared"))
        {
            return "Area Squared";
        }
        else if (__dummyScrutVar0.equals("By_Specs"))
        {
            return "By Specs";
        }
        else if (__dummyScrutVar0.equals("Tangent"))
        {
            return "Tangent";
        }
        else if (__dummyScrutVar0.equals("Angle"))
        {
            return "Angle";
        }
        else if (__dummyScrutVar0.equals("Deadend"))
        {
            return "Deadend";
        }
        else if (__dummyScrutVar0.equals("Junction"))
        {
            return "Junction";
        }
        else if (__dummyScrutVar0.equals("Measured"))
        {
            return "Measured";
        }
        else if (__dummyScrutVar0.equals("Class_0"))
        {
            return "Class 0";
        }
        else if (__dummyScrutVar0.equals("Class_1"))
        {
            return "Class 1";
        }
        else if (__dummyScrutVar0.equals("Class_2"))
        {
            return "Class 2";
        }
        else if (__dummyScrutVar0.equals("Class_3"))
        {
            return "Class 3";
        }
        else if (__dummyScrutVar0.equals("Class_4"))
        {
            return "Class 4";
        }
        else if (__dummyScrutVar0.equals("Class_5"))
        {
            return "Class 5";
        }
        else if (__dummyScrutVar0.equals("Class_6"))
        {
            return "Class 6";
        }
        else if (__dummyScrutVar0.equals("Class_7"))
        {
            return "Class 7";
        }
        else if (__dummyScrutVar0.equals("Class_8"))
        {
            return "Class 8";
        }
        else if (__dummyScrutVar0.equals("Unsset"))
        {
            return "Unsset";
        }
        else if (__dummyScrutVar0.equals("Pedestal"))
        {
            return "Pedestal";
        }
        else if (__dummyScrutVar0.equals("NESC_C2_2007"))
        {
            return "NESC C2-2007";
        }
        else if (__dummyScrutVar0.equals("CSA_C22_3_No__1_10"))
        {
            return "CSA C22.3 No. 1-10";
        }
        else if (__dummyScrutVar0.equals("Embedded"))
        {
            return "Embedded";
        }
        else if (__dummyScrutVar0.equals("Automatic"))
        {
            return "Automatic";
        }
        else if (__dummyScrutVar0.equals("Superposition"))
        {
            return "Superposition";
        }
        else if (__dummyScrutVar0.equals("Wood"))
        {
            return "Wood";
        }
        else if (__dummyScrutVar0.equals("Offset"))
        {
            return "Offset";
        }
        else if (__dummyScrutVar0.equals("Pole_Extension"))
        {
            return "Pole Extension";
        }
        else if (__dummyScrutVar0.equals("Full_Gull"))
        {
            return "Full Gull";
        }
        else if (__dummyScrutVar0.equals("Half_Gull"))
        {
            return "Half Gull";
        }
        else if (__dummyScrutVar0.equals("Standoff"))
        {
            return "Standoff";
        }
        else if (__dummyScrutVar0.equals("Double"))
        {
            return "Double";
        }
        else if (__dummyScrutVar0.equals("Single"))
        {
            return "Single";
        }
        else if (__dummyScrutVar0.equals("Interaction"))
        {
            return "Interaction";
        }
        else if (__dummyScrutVar0.equals("Worst_Axis"))
        {
            return "Worst Axis";
        }
        else if (__dummyScrutVar0.equals("Steel"))
        {
            return "Steel";
        }
        else if (__dummyScrutVar0.equals("Composite"))
        {
            return "Composite";
        }
        else if (__dummyScrutVar0.equals("Other"))
        {
            return "Other";
        }
        else if (__dummyScrutVar0.equals("Pin"))
        {
            return "Pin";
        }
        else if (__dummyScrutVar0.equals("Inline"))
        {
            return "Inline";
        }
        else if (__dummyScrutVar0.equals("_Default_"))
        {
            return "<Default>";
        }
        else if (__dummyScrutVar0.equals("Clamped"))
        {
            return "Clamped";
        }
        else if (__dummyScrutVar0.equals("Post"))
        {
            return "Post";
        }
        else if (__dummyScrutVar0.equals("Davit"))
        {
            return "Davit";
        }
        else if (__dummyScrutVar0.equals("Spool"))
        {
            return "Spool";
        }
        else if (__dummyScrutVar0.equals("Underhung"))
        {
            return "Underhung";
        }
        else if (__dummyScrutVar0.equals("Suspension"))
        {
            return "Suspension";
        }
        else if (__dummyScrutVar0.equals("J_Hook"))
        {
            return "J-Hook";
        }
        else if (__dummyScrutVar0.equals("Bolt"))
        {
            return "Bolt";
        }
        else if (__dummyScrutVar0.equals("Extension"))
        {
            return "Extension";
        }
        else if (__dummyScrutVar0.equals("Street"))
        {
            return "Street";
        }
        else if (__dummyScrutVar0.equals("Field"))
        {
            return "Field";
        }
        else if (__dummyScrutVar0.equals("Front"))
        {
            return "Front";
        }
        else if (__dummyScrutVar0.equals("Back"))
        {
            return "Back";
        }
        else if (__dummyScrutVar0.equals("Both"))
        {
            return "Both";
        }
        else if (__dummyScrutVar0.equals("Split"))
        {
            return "Split";
        }
        else if (__dummyScrutVar0.equals("Sheds_1"))
        {
            return "1";
        }
        else if (__dummyScrutVar0.equals("Sheds_2"))
        {
            return "2";
        }
        else if (__dummyScrutVar0.equals("Sheds_3"))
        {
            return "3";
        }
        else if (__dummyScrutVar0.equals("Sheds_4"))
        {
            return "4";
        }
        else if (__dummyScrutVar0.equals("Sheds_5"))
        {
            return "5";
        }
        else if (__dummyScrutVar0.equals("Sheds_6"))
        {
            return "6";
        }
        else if (__dummyScrutVar0.equals("Sheds_7"))
        {
            return "7";
        }
        else if (__dummyScrutVar0.equals("Sheds_8"))
        {
            return "8";
        }
        else if (__dummyScrutVar0.equals("Free"))
        {
            return "Free";
        }
        else if (__dummyScrutVar0.equals("Primary"))
        {
            return "Primary";
        }
        else if (__dummyScrutVar0.equals("Static"))
        {
            return "Static";
        }
        else if (__dummyScrutVar0.equals("Secondary"))
        {
            return "Secondary";
        }
        else if (__dummyScrutVar0.equals("Service"))
        {
            return "Service";
        }
        else if (__dummyScrutVar0.equals("Neutral"))
        {
            return "Neutral";
        }
        else if (__dummyScrutVar0.equals("Telco"))
        {
            return "Telco";
        }
        else if (__dummyScrutVar0.equals("CATV"))
        {
            return "CATV";
        }
        else if (__dummyScrutVar0.equals("Fiber"))
        {
            return "Fiber";
        }
        else if (__dummyScrutVar0.equals("Sub_Transmission"))
        {
            return "Sub-Transmission";
        }
        else if (__dummyScrutVar0.equals("Slack"))
        {
            return "Slack";
        }
        else if (__dummyScrutVar0.equals("Table"))
        {
            return "Table";
        }
        else if (__dummyScrutVar0.equals("Sag_to_Tension"))
        {
            return "Sag to Tension";
        }
        else if (__dummyScrutVar0.equals("Tension_to_Sag"))
        {
            return "Tension to Sag";
        }
        else if (__dummyScrutVar0.equals("Drop"))
        {
            return "Drop";
        }
        else if (__dummyScrutVar0.equals("Overlashed"))
        {
            return "Overlashed";
        }
        else if (__dummyScrutVar0.equals("Bundled"))
        {
            return "Bundled";
        }
        else if (__dummyScrutVar0.equals("Corrugated"))
        {
            return "Corrugated";
        }
        else if (__dummyScrutVar0.equals("Flexpipe"))
        {
            return "Flexpipe";
        }
        else if (__dummyScrutVar0.equals("Irregular"))
        {
            return "Irregular";
        }
        else if (__dummyScrutVar0.equals("_See_Note_"))
        {
            return "(See Note)";
        }
        else if (__dummyScrutVar0.equals("Individual"))
        {
            return "Individual";
        }
        else if (__dummyScrutVar0.equals("Spacers"))
        {
            return "Spacers";
        }
        else if (__dummyScrutVar0.equals("Bonded"))
        {
            return "Bonded";
        }
        else if (__dummyScrutVar0.equals("Twist_Braid"))
        {
            return "Twist/Braid";
        }
        else if (__dummyScrutVar0.equals("Wrapped"))
        {
            return "Wrapped";
        }
        else if (__dummyScrutVar0.equals("Min_Circle"))
        {
            return "Min Circle";
        }
        else if (__dummyScrutVar0.equals("Convex_Hull"))
        {
            return "Convex Hull";
        }
        else if (__dummyScrutVar0.equals("Concave_Hull"))
        {
            return "Concave Hull";
        }
        else if (__dummyScrutVar0.equals("Transformer"))
        {
            return "Transformer";
        }
        else if (__dummyScrutVar0.equals("Pole"))
        {
            return "Pole";
        }
        else if (__dummyScrutVar0.equals("Regulator"))
        {
            return "Regulator";
        }
        else if (__dummyScrutVar0.equals("Capacitor"))
        {
            return "Capacitor";
        }
        else if (__dummyScrutVar0.equals("Switch"))
        {
            return "Switch";
        }
        else if (__dummyScrutVar0.equals("Fuse"))
        {
            return "Fuse";
        }
        else if (__dummyScrutVar0.equals("Box"))
        {
            return "Box";
        }
        else if (__dummyScrutVar0.equals("Rack"))
        {
            return "Rack";
        }
        else if (__dummyScrutVar0.equals("General"))
        {
            return "General";
        }
        else if (__dummyScrutVar0.equals("Decorative"))
        {
            return "Decorative";
        }
        else if (__dummyScrutVar0.equals("Spot_Light"))
        {
            return "Spot Light";
        }
        else if (__dummyScrutVar0.equals("Flood_Light"))
        {
            return "Flood Light";
        }
        else if (__dummyScrutVar0.equals("Traffic_Signal"))
        {
            return "Traffic Signal";
        }
        else if (__dummyScrutVar0.equals("Down"))
        {
            return "Down";
        }
        else if (__dummyScrutVar0.equals("Calculated"))
        {
            return "Calculated";
        }
        else if (__dummyScrutVar0.equals("Span_Head"))
        {
            return "Span/Head";
        }
        else if (__dummyScrutVar0.equals("Sidewalk"))
        {
            return "Sidewalk";
        }
        else if (__dummyScrutVar0.equals("Crossarm"))
        {
            return "Crossarm";
        }
        else if (__dummyScrutVar0.equals("Pushbrace"))
        {
            return "Pushbrace";
        }
        else if (__dummyScrutVar0.equals("Cylinder"))
        {
            return "Cylinder";
        }
        else if (__dummyScrutVar0.equals("Imported"))
        {
            return "Imported";
        }
        else if (__dummyScrutVar0.equals("C2"))
        {
            return "C2";
        }
        else if (__dummyScrutVar0.equals("ET"))
        {
            return "ET";
        }
        else if (__dummyScrutVar0.equals("FiberWrap"))
        {
            return "FiberWrap";
        }
        else if (__dummyScrutVar0.equals("FiberWrap_II"))
        {
            return "FiberWrap II";
        }
        else if (__dummyScrutVar0.equals("Truss"))
        {
            return "Truss";
        }
        else if (__dummyScrutVar0.equals("Wrap"))
        {
            return "Wrap";
        }
        else if (__dummyScrutVar0.equals("Aviation_Ball"))
        {
            return "Aviation Ball";
        }
        else if (__dummyScrutVar0.equals("Vertical"))
        {
            return "Vertical";
        }
        else if (__dummyScrutVar0.equals("Minus"))
        {
            return "Minus";
        }
        else if (__dummyScrutVar0.equals("Plus"))
        {
            return "Plus";
        }
        else if (__dummyScrutVar0.equals("Cut_Out"))
        {
            return "Cut-Out";
        }
        else if (__dummyScrutVar0.equals("Splice"))
        {
            return "Splice";
        }
        else if (__dummyScrutVar0.equals("Damper"))
        {
            return "Damper";
        }
        else if (__dummyScrutVar0.equals("Perch_Stopper"))
        {
            return "Perch Stopper";
        }
        else if (__dummyScrutVar0.equals("Maintenance_Loop"))
        {
            return "Maintenance Loop";
        }
        else if (__dummyScrutVar0.equals("Horizontal"))
        {
            return "Horizontal";
        }
        else if (__dummyScrutVar0.equals("Center"))
        {
            return "Center";
        }
        else if (__dummyScrutVar0.equals("Void"))
        {
            return "Void";
        }
        else if (__dummyScrutVar0.equals("Vehicle_Scrape"))
        {
            return "Vehicle Scrape";
        }
        else if (__dummyScrutVar0.equals("Saw_Cut"))
        {
            return "Saw Cut";
        }
        else if (__dummyScrutVar0.equals("Mower_Cut"))
        {
            return "Mower Cut";
        }
        else if (__dummyScrutVar0.equals("Exposed_Pocket"))
        {
            return "Exposed Pocket";
        }
        else if (__dummyScrutVar0.equals("Enclosed_Pocket"))
        {
            return "Enclosed Pocket";
        }
        else if (__dummyScrutVar0.equals("Heart_Rot"))
        {
            return "Heart Rot";
        }
        else if (__dummyScrutVar0.equals("Shell_Reduction"))
        {
            return "Shell Reduction";
        }
        else if (__dummyScrutVar0.equals("Woodpecker_Hole"))
        {
            return "Woodpecker Hole";
        }
        else if (__dummyScrutVar0.equals("Woodpecker_Nest"))
        {
            return "Woodpecker Nest";
        }
        else if (__dummyScrutVar0.equals("Active_Leg"))
        {
            return "Active Leg";
        }
        else if (__dummyScrutVar0.equals("Worst_Leg"))
        {
            return "Worst Leg";
        }
        else if (__dummyScrutVar0.equals("X_Y_Z"))
        {
            return "X,Y,Z";
        }
        else if (__dummyScrutVar0.equals("XX_YY_ZZ"))
        {
            return "XX,YY,ZZ";
        }
        else if (__dummyScrutVar0.equals("X"))
        {
            return "X";
        }
        else if (__dummyScrutVar0.equals("Y"))
        {
            return "Y";
        }
        else if (__dummyScrutVar0.equals("Z"))
        {
            return "Z";
        }
        else if (__dummyScrutVar0.equals("X_Y"))
        {
            return "X,Y";
        }
        else if (__dummyScrutVar0.equals("X_Z"))
        {
            return "X,Z";
        }
        else if (__dummyScrutVar0.equals("Y_Z"))
        {
            return "Y,Z";
        }
        else if (__dummyScrutVar0.equals("XX"))
        {
            return "XX";
        }
        else if (__dummyScrutVar0.equals("YY"))
        {
            return "YY";
        }
        else if (__dummyScrutVar0.equals("ZZ"))
        {
            return "ZZ";
        }
        else if (__dummyScrutVar0.equals("XX_YY"))
        {
            return "XX,YY";
        }
        else if (__dummyScrutVar0.equals("XX_ZZ"))
        {
            return "XX,ZZ";
        }
        else if (__dummyScrutVar0.equals("YY_ZZ"))
        {
            return "YY,ZZ";
        }
        else if (__dummyScrutVar0.equals("Frame"))
        {
            return "Frame";
        }
        else if (__dummyScrutVar0.equals("Compression_Only"))
        {
            return "Compression Only";
        }
        else if (__dummyScrutVar0.equals("Tension_Only"))
        {
            return "Tension Only";
        }
        else if (__dummyScrutVar0.equals("Uniform"))
        {
            return "Uniform";
        }
        else if (__dummyScrutVar0.equals("Point"))
        {
            return "Point";
        }
                                                                                                                                                                                                                                                
        return "";
    }

}


