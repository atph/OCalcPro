//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:41 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.Anchor;
import PPL_Model_Wrapper.Crossarm;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.Insulator;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.LoadCase;
import PPL_Model_Wrapper.NodeJunction;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.PoleRestoration;
import PPL_Model_Wrapper.PowerEquipment;
import PPL_Model_Wrapper.Riser;
import PPL_Model_Wrapper.Streetlight;
import PPL_Model_Wrapper.ValTable;
import PPL_Model_Wrapper.WoodPoleDamageOrDecay;

//--------------------------------------------------------------------------------------------
//   Class: WoodPole
// Mirrors: PPLWoodPole : PPLElement
//--------------------------------------------------------------------------------------------
public class WoodPole  extends ElementBase 
{
    public static String gXMLkey = "WoodPole";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public WoodPole(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Pole_Number = "Unset";
            m_Owner = "Pole";
            m_Structure_Type = Structure_Type_val.Auto;
            m_Class = "4";
            m_LengthInInches = 480;
            m_Species = "SOUTHERN PINE";
            m_Species_Code = "NESC Standard";
            m_BuryDepthInInches = 72;
            m_LineOfLead = 0;
            m_LeanDirection = 0;
            m_LeanAmount = 0;
            m_RadiusAtTipInInches = 3.3422538049298;
            m_GLCircumMethod = GLCircumMethod_val.By_Specs;
            m_Circum6ft = 33.5;
            m_MeasuredRadiusGL = 5.33169059357849;
            m_ApplyEffectiveRadiusGL = false;
            m_EffectiveRadiusGL = 5.33169059357849;
            m_StrengthRemainingGL = 1;
            m_OverturnMoment = 0;
            m_Modulus_of_Rupture = 8000;
            m_Modulus_of_Elasticity = 1600000;
            m_PoissonsRatio = 0.3;
            m_WindDragCoef = 0;
            m_ThermalCoefficient = 2.7E-06;
            m_Density = 0.0347222222222222;
            m_Characteristic_Shear_Strength = 450;
            m_Characteristic_Compression_Strength = 3500;
            m_Effective_Length = -1;
            m_Material_Constant = 1.24;
            m_PoleMfgLength = 480;
            m_Table_No = "ANSI8";
            m_Offset = 0;
            m_Aux_Data_1 = "Unset";
            m_Aux_Data_2 = "Unset";
            m_Aux_Data_3 = "Unset";
            m_Aux_Data_4 = "Unset";
            m_Aux_Data_5 = "Unset";
            m_Aux_Data_6 = "Unset";
            m_Aux_Data_7 = "Unset";
            m_Aux_Data_8 = "Unset";
            m_BucklingConstant = 0;
            m_UseMomentCapacityTable = false;
            m_MomentCapacityTable = new ValTable("Moment;0,50000;");
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Crossarm)
            return true;
         
        if (pChildCandidate instanceof PowerEquipment)
            return true;
         
        if (pChildCandidate instanceof Streetlight)
            return true;
         
        if (pChildCandidate instanceof Insulator)
            return true;
         
        if (pChildCandidate instanceof NodeJunction)
            return true;
         
        if (pChildCandidate instanceof Riser)
            return true;
         
        if (pChildCandidate instanceof GenericEquipment)
            return true;
         
        if (pChildCandidate instanceof Anchor)
            return true;
         
        if (pChildCandidate instanceof PoleRestoration)
            return true;
         
        if (pChildCandidate instanceof LoadCase)
            return true;
         
        if (pChildCandidate instanceof WoodPoleDamageOrDecay)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Pole Number
    //   Attr Group:Standard
    //   Description:   Pole identification
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Pole_Number;
    public String getPole_Number() throws Exception {
        return m_Pole_Number;
    }

    public void setPole_Number(String value) throws Exception {
        m_Pole_Number = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Pole
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Structure_Type_val
    {
        //   Attr Name:   Structure Type
        //   Attr Group:Standard
        //   Description:   Pole structure type specification
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Auto
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Tangent  (Pole with all wires running in line with each other)
        //        Angle  (Pole with at least one wire that is at an angle relative to the others)
        //        Deadend  (Pole with wires ending at the pole)
        //        Junction  (Pole with wires crossing at or near the pole)
        Auto,
        //Automatically determine the structure type from attached equipment
        Tangent,
        //Pole with all wires running in line with each other
        Angle,
        //Pole with at least one wire that is at an angle relative to the others
        Deadend,
        //Pole with wires ending at the pole
        Junction
    }
    //Pole with wires crossing at or near the pole
    private Structure_Type_val m_Structure_Type = Structure_Type_val.Auto;
    public Structure_Type_val getStructure_Type() throws Exception {
        return m_Structure_Type;
    }

    public void setStructure_Type(Structure_Type_val value) throws Exception {
        m_Structure_Type = value;
    }

    public Structure_Type_val string_to_Structure_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Auto"))
        {
            return Structure_Type_val.Auto;
        }
        else //Automatically determine the structure type from attached equipment
        if (__dummyScrutVar0.equals("Tangent"))
        {
            return Structure_Type_val.Tangent;
        }
        else //Pole with all wires running in line with each other
        if (__dummyScrutVar0.equals("Angle"))
        {
            return Structure_Type_val.Angle;
        }
        else //Pole with at least one wire that is at an angle relative to the others
        if (__dummyScrutVar0.equals("Deadend"))
        {
            return Structure_Type_val.Deadend;
        }
        else //Pole with wires ending at the pole
        if (__dummyScrutVar0.equals("Junction"))
        {
            return Structure_Type_val.Junction;
        }
        else
        {
        }     
        throw new Exception("string does not match enum value");
    }

    //Pole with wires crossing at or near the pole
    public String structure_Type_val_to_String(Structure_Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Auto: 
                return "Auto";
            case Tangent: 
                return "Tangent";
            case Angle: 
                return "Angle";
            case Deadend: 
                return "Deadend";
            case Junction: 
                return "Junction";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Automatically determine the structure type from attached equipment
    //Pole with all wires running in line with each other
    //Pole with at least one wire that is at an angle relative to the others
    //Pole with wires ending at the pole
    //Pole with wires crossing at or near the pole
    //   Attr Name:   Class
    //   Attr Group:Standard
    //   Alt Display Name:Pole Class
    //   Description:   Pole class specification
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   4
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Class;
    public String getClass() throws Exception {
        return m_Class;
    }

    public void setClass(String value) throws Exception {
        m_Class = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Pole Length (ft)
    //   Description:   Pole length in inches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   480
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   Species
    //   Attr Group:Standard
    //   Description:   Wood species of the pole
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   SOUTHERN PINE
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Species;
    public String getSpecies() throws Exception {
        return m_Species;
    }

    public void setSpecies(String value) throws Exception {
        m_Species = value;
    }

    //   Attr Name:   Species Code
    //   Attr Group:Standard
    //   Alt Display Name:Code
    //   Description:   Code Standard
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   NESC Standard
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Species_Code;
    public String getSpecies_Code() throws Exception {
        return m_Species_Code;
    }

    public void setSpecies_Code(String value) throws Exception {
        m_Species_Code = value;
    }

    //   Attr Name:   BuryDepthInInches
    //   Attr Group:Standard
    //   Alt Display Name:Setting Depth (ft)
    //   Description:   Bury depth in inches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   72
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_BuryDepthInInches;
    public double getBuryDepthInInches() throws Exception {
        return m_BuryDepthInInches;
    }

    public void setBuryDepthInInches(double value) throws Exception {
        m_BuryDepthInInches = value;
    }

    //   Attr Name:   LineOfLead
    //   Attr Group:Standard
    //   Alt Display Name:Line of Lead (Â°)
    //   Description:   The overall line of lead of the entire pole assembly
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LineOfLead;
    public double getLineOfLead() throws Exception {
        return m_LineOfLead;
    }

    public void setLineOfLead(double value) throws Exception {
        m_LineOfLead = value;
    }

    //   Attr Name:   LeanDirection
    //   Attr Group:Standard
    //   Alt Display Name:Lean Direction (Â°)
    //   Description:   Pole lean direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanDirection;
    public double getLeanDirection() throws Exception {
        return m_LeanDirection;
    }

    public void setLeanDirection(double value) throws Exception {
        m_LeanDirection = value;
    }

    //   Attr Name:   LeanAmount
    //   Attr Group:Standard
    //   Alt Display Name:Lean Amount (Â°)
    //   Description:   Pole amount direction in radians
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_LeanAmount;
    public double getLeanAmount() throws Exception {
        return m_LeanAmount;
    }

    public void setLeanAmount(double value) throws Exception {
        m_LeanAmount = value;
    }

    //   Attr Name:   RadiusAtTipInInches
    //   Attr Group:Circumference
    //   Alt Display Name:Tip Circum (in)
    //   Description:
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.3422538049298
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_RadiusAtTipInInches;
    public double getRadiusAtTipInInches() throws Exception {
        return m_RadiusAtTipInInches;
    }

    public void setRadiusAtTipInInches(double value) throws Exception {
        m_RadiusAtTipInInches = value;
    }

    public enum GLCircumMethod_val
    {
        //   Attr Name:   GLCircumMethod
        //   Attr Group:Circumference
        //   Alt Display Name:GL Circum Method
        //   Description:   Groundline method.
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   By Specs
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Measured  (Measured)
        By_Specs,
        //By Specs
        Measured
    }
    //Measured
    private GLCircumMethod_val m_GLCircumMethod = GLCircumMethod_val.By_Specs;
    public GLCircumMethod_val getGLCircumMethod() throws Exception {
        return m_GLCircumMethod;
    }

    public void setGLCircumMethod(GLCircumMethod_val value) throws Exception {
        m_GLCircumMethod = value;
    }

    public GLCircumMethod_val string_to_GLCircumMethod_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("By Specs"))
        {
            return GLCircumMethod_val.By_Specs;
        }
        else //By Specs
        if (__dummyScrutVar2.equals("Measured"))
        {
            return GLCircumMethod_val.Measured;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Measured
    public String gLCircumMethod_val_to_String(GLCircumMethod_val pKey) throws Exception {
        switch(pKey)
        {
            case By_Specs: 
                return "By Specs";
            case Measured: 
                return "Measured";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //By Specs
    //Measured
    //   Attr Name:   Circum6ft
    //   Attr Group:Circumference
    //   Alt Display Name:6ft Circum (in)
    //   Description:   The pole circumference at the 6 foot point
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   33.5
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   Yes
    private double m_Circum6ft;
    public double getCircum6ft() throws Exception {
        return m_Circum6ft;
    }

    public void setCircum6ft(double value) throws Exception {
        m_Circum6ft = value;
    }

    //   Attr Name:   MeasuredRadiusGL
    //   Attr Group:Circumference
    //   Alt Display Name:GL Circum (in)
    //   Description:   Measured radius at the groundline
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   5.33169059357849
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_MeasuredRadiusGL;
    public double getMeasuredRadiusGL() throws Exception {
        return m_MeasuredRadiusGL;
    }

    public void setMeasuredRadiusGL(double value) throws Exception {
        m_MeasuredRadiusGL = value;
    }

    //   Attr Name:   ApplyEffectiveRadiusGL
    //   Attr Group:Circumference
    //   Alt Display Name:Apply Eff. GL Reduction
    //   Description:   Apply Effective radius at the groundline
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_ApplyEffectiveRadiusGL;
    public boolean getApplyEffectiveRadiusGL() throws Exception {
        return m_ApplyEffectiveRadiusGL;
    }

    public void setApplyEffectiveRadiusGL(boolean value) throws Exception {
        m_ApplyEffectiveRadiusGL = value;
    }

    //   Attr Name:   EffectiveRadiusGL
    //   Attr Group:Circumference
    //   Alt Display Name:Eff. GL Circ (in)
    //   Description:   Effective radius at the groundline
    //   Displayed Units:   store as RADIUS IN INCHES display as CIRCUMFERENCE IN INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   5.33169059357849
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_EffectiveRadiusGL;
    public double getEffectiveRadiusGL() throws Exception {
        return m_EffectiveRadiusGL;
    }

    public void setEffectiveRadiusGL(double value) throws Exception {
        m_EffectiveRadiusGL = value;
    }

    //   Attr Name:   StrengthRemainingGL
    //   Attr Group:Circumference
    //   Alt Display Name:GL Remaining Strength (%)
    //   Description:   % remaining strength at the groundline
    //   Displayed Units:   store as PERCENT 0 TO 1 display as PERCENT 0 TO 100
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_StrengthRemainingGL;
    public double getStrengthRemainingGL() throws Exception {
        return m_StrengthRemainingGL;
    }

    public void setStrengthRemainingGL(double value) throws Exception {
        m_StrengthRemainingGL = value;
    }

    public enum SoilClass_val
    {
        //   Attr Name:   SoilClass
        //   Attr Group:Overturn
        //   Alt Display Name:Soil Class
        //   Description:   The class of soil at the site of the anchor
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Unset
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Class 1  (Very dense and/or cemented sands, coarse gravel and cobbles)
        //        Class 2  (Dense fine sand, very hard silts and clays (may be preloaded))
        //        Class 3  (Dense sands and gravel, hard silts and clays)
        //        Class 4  (Medium dense sandy gravel, very stiff to hard silts and clays)
        //        Class 5  (Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays)
        //        Class 6  (Loose to medium dense fine to coarse sand, firm to stiff clays and silts)
        //        Class 7  (Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill)
        //        Class 8  (Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays)
        //        Unsset  (Unset)
        Class_0,
        //Sound hard rock, bedrock, unweathered
        Class_1,
        //Very dense and/or cemented sands, coarse gravel and cobbles
        Class_2,
        //Dense fine sand, very hard silts and clays (may be preloaded)
        Class_3,
        //Dense sands and gravel, hard silts and clays
        Class_4,
        //Medium dense sandy gravel, very stiff to hard silts and clays
        Class_5,
        //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        Class_6,
        //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        Class_7,
        //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        Class_8,
        //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        Unsset
    }
    //Unset
    private SoilClass_val m_SoilClass = SoilClass_val.Class_0;
    public SoilClass_val getSoilClass() throws Exception {
        return m_SoilClass;
    }

    public void setSoilClass(SoilClass_val value) throws Exception {
        m_SoilClass = value;
    }

    public SoilClass_val string_to_SoilClass_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("Class 0"))
        {
            return SoilClass_val.Class_0;
        }
        else //Sound hard rock, bedrock, unweathered
        if (__dummyScrutVar4.equals("Class 1"))
        {
            return SoilClass_val.Class_1;
        }
        else //Very dense and/or cemented sands, coarse gravel and cobbles
        if (__dummyScrutVar4.equals("Class 2"))
        {
            return SoilClass_val.Class_2;
        }
        else //Dense fine sand, very hard silts and clays (may be preloaded)
        if (__dummyScrutVar4.equals("Class 3"))
        {
            return SoilClass_val.Class_3;
        }
        else //Dense sands and gravel, hard silts and clays
        if (__dummyScrutVar4.equals("Class 4"))
        {
            return SoilClass_val.Class_4;
        }
        else //Medium dense sandy gravel, very stiff to hard silts and clays
        if (__dummyScrutVar4.equals("Class 5"))
        {
            return SoilClass_val.Class_5;
        }
        else //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
        if (__dummyScrutVar4.equals("Class 6"))
        {
            return SoilClass_val.Class_6;
        }
        else //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
        if (__dummyScrutVar4.equals("Class 7"))
        {
            return SoilClass_val.Class_7;
        }
        else //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
        if (__dummyScrutVar4.equals("Class 8"))
        {
            return SoilClass_val.Class_8;
        }
        else //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
        if (__dummyScrutVar4.equals("Unsset"))
        {
            return SoilClass_val.Unsset;
        }
        else
        {
        }          
        throw new Exception("string does not match enum value");
    }

    //Unset
    public String soilClass_val_to_String(SoilClass_val pKey) throws Exception {
        switch(pKey)
        {
            case Class_0: 
                return "Class 0";
            case Class_1: 
                return "Class 1";
            case Class_2: 
                return "Class 2";
            case Class_3: 
                return "Class 3";
            case Class_4: 
                return "Class 4";
            case Class_5: 
                return "Class 5";
            case Class_6: 
                return "Class 6";
            case Class_7: 
                return "Class 7";
            case Class_8: 
                return "Class 8";
            case Unsset: 
                return "Unsset";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Sound hard rock, bedrock, unweathered
    //Very dense and/or cemented sands, coarse gravel and cobbles
    //Dense fine sand, very hard silts and clays (may be preloaded)
    //Dense sands and gravel, hard silts and clays
    //Medium dense sandy gravel, very stiff to hard silts and clays
    //Medium dense coarse sand and sandy gravels, stiff to very stiff silts and clays
    //Loose to medium dense fine to coarse sand, firm to stiff clays and silts
    //Loose fine sand, alluvium, loess clays, soft-firm clays, varied clays, fill
    //Peat, organic silts, inundated silts, fly ash, very loose sands, very soft to soft clays
    //Unset
    //   Attr Name:   OverturnMoment
    //   Attr Group:Overturn
    //   Alt Display Name:Overturn Moment (ft-lbs)
    //   Description:   Overturn Moment
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.#
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_OverturnMoment;
    public double getOverturnMoment() throws Exception {
        return m_OverturnMoment;
    }

    public void setOverturnMoment(double value) throws Exception {
        m_OverturnMoment = value;
    }

    //   Attr Name:   Modulus of Rupture
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Modulus of Rupture (psi)
    //   Description:   Modulus of rupture for the given species
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   FLOAT
    //   Default Value:   8000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Rupture;
    public double getModulus_of_Rupture() throws Exception {
        return m_Modulus_of_Rupture;
    }

    public void setModulus_of_Rupture(double value) throws Exception {
        m_Modulus_of_Rupture = value;
    }

    //   Attr Name:   Modulus of Elasticity
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Modulus of Elasticity (psi)
    //   Description:   Modulus of elasticty for the material
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   1600000
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Modulus_of_Elasticity;
    public double getModulus_of_Elasticity() throws Exception {
        return m_Modulus_of_Elasticity;
    }

    public void setModulus_of_Elasticity(double value) throws Exception {
        m_Modulus_of_Elasticity = value;
    }

    //   Attr Name:   PoissonsRatio
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Poisson's Ratio
    //   Description:   Poisson's Ratio
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0####
    //   Attribute Type:   FLOAT
    //   Default Value:   0.3
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoissonsRatio;
    public double getPoissonsRatio() throws Exception {
        return m_PoissonsRatio;
    }

    public void setPoissonsRatio(double value) throws Exception {
        m_PoissonsRatio = value;
    }

    //   Attr Name:   WindDragCoef
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    //   Attr Name:   ThermalCoefficient
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Thermal Coef ((in/in)/Â°f)
    //   Description:   ThermalCoefficient
    //   Displayed Units:   store as THERMAL COEFFICIENT
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0000027
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_ThermalCoefficient;
    public double getThermalCoefficient() throws Exception {
        return m_ThermalCoefficient;
    }

    public void setThermalCoefficient(double value) throws Exception {
        m_ThermalCoefficient = value;
    }

    //   Attr Name:   Density
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Density (lb/ft^3)
    //   Description:   Density for the given species in lbs per cubic inch
    //   Displayed Units:   store as POUNDS PER CUBIC INCH display as POUNDS PER CUBIC FOOT or KILOGRAMS PER CUBIC METER
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.00###E+0
    //   Attribute Type:   FLOAT
    //   Default Value:   0.0347222222222222
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Density;
    public double getDensity() throws Exception {
        return m_Density;
    }

    public void setDensity(double value) throws Exception {
        m_Density = value;
    }

    //   Attr Name:   Characteristic Shear Strength
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Char Shear Str (psi)
    //   Description:   Characteristic Shear Strength
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   450
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Characteristic_Shear_Strength;
    public double getCharacteristic_Shear_Strength() throws Exception {
        return m_Characteristic_Shear_Strength;
    }

    public void setCharacteristic_Shear_Strength(double value) throws Exception {
        m_Characteristic_Shear_Strength = value;
    }

    //   Attr Name:   Characteristic Compression Strength
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Char Compression Str (psi)
    //   Description:   Characteristic Compression Strength
    //   Displayed Units:   store as PSI display as PSI or KILOPASCAL
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   3500
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Characteristic_Compression_Strength;
    public double getCharacteristic_Compression_Strength() throws Exception {
        return m_Characteristic_Compression_Strength;
    }

    public void setCharacteristic_Compression_Strength(double value) throws Exception {
        m_Characteristic_Compression_Strength = value;
    }

    //   Attr Name:   Effective Length
    //   Attr Group:AS/NZS 7000
    //   Alt Display Name:Effective Length (ft)
    //   Description:   Effective Length
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0#
    //   Attribute Type:   FLOAT
    //   Default Value:   -1
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Effective_Length;
    public double getEffective_Length() throws Exception {
        return m_Effective_Length;
    }

    public void setEffective_Length(double value) throws Exception {
        m_Effective_Length = value;
    }

    //   Attr Name:   Material Constant
    //   Attr Group:AS/NZS 7000
    //   Description:   Material Constant
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   1.24
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Material_Constant;
    public double getMaterial_Constant() throws Exception {
        return m_Material_Constant;
    }

    public void setMaterial_Constant(double value) throws Exception {
        m_Material_Constant = value;
    }

    //   Attr Name:   PoleMfgLength
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Pole Mfg Length (ft)
    //   Description:   Pole manufactured length in inches
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   480
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_PoleMfgLength;
    public double getPoleMfgLength() throws Exception {
        return m_PoleMfgLength;
    }

    public void setPoleMfgLength(double value) throws Exception {
        m_PoleMfgLength = value;
    }

    //   Attr Name:   Table No
    //   Attr Group:Phys. Consts
    //   Description:   Table Designation
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   ANSI8
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Table_No;
    public String getTable_No() throws Exception {
        return m_Table_No;
    }

    public void setTable_No(String value) throws Exception {
        m_Table_No = value;
    }

    //   Attr Name:   Offset
    //   Attr Group:Multi Pole
    //   Alt Display Name:Offset (ft)
    //   Description:   Pole offset in feet
    //   Displayed Units:   store as INCHES display as FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_Offset;
    public double getOffset() throws Exception {
        return m_Offset;
    }

    public void setOffset(double value) throws Exception {
        m_Offset = value;
    }

    //   Attr Name:   Aux Data 1
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_1;
    public String getAux_Data_1() throws Exception {
        return m_Aux_Data_1;
    }

    public void setAux_Data_1(String value) throws Exception {
        m_Aux_Data_1 = value;
    }

    //   Attr Name:   Aux Data 2
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_2;
    public String getAux_Data_2() throws Exception {
        return m_Aux_Data_2;
    }

    public void setAux_Data_2(String value) throws Exception {
        m_Aux_Data_2 = value;
    }

    //   Attr Name:   Aux Data 3
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_3;
    public String getAux_Data_3() throws Exception {
        return m_Aux_Data_3;
    }

    public void setAux_Data_3(String value) throws Exception {
        m_Aux_Data_3 = value;
    }

    //   Attr Name:   Aux Data 4
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_4;
    public String getAux_Data_4() throws Exception {
        return m_Aux_Data_4;
    }

    public void setAux_Data_4(String value) throws Exception {
        m_Aux_Data_4 = value;
    }

    //   Attr Name:   Aux Data 5
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_5;
    public String getAux_Data_5() throws Exception {
        return m_Aux_Data_5;
    }

    public void setAux_Data_5(String value) throws Exception {
        m_Aux_Data_5 = value;
    }

    //   Attr Name:   Aux Data 6
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_6;
    public String getAux_Data_6() throws Exception {
        return m_Aux_Data_6;
    }

    public void setAux_Data_6(String value) throws Exception {
        m_Aux_Data_6 = value;
    }

    //   Attr Name:   Aux Data 7
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_7;
    public String getAux_Data_7() throws Exception {
        return m_Aux_Data_7;
    }

    public void setAux_Data_7(String value) throws Exception {
        m_Aux_Data_7 = value;
    }

    //   Attr Name:   Aux Data 8
    //   Attr Group:User Data
    //   Description:
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Unset
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Aux_Data_8;
    public String getAux_Data_8() throws Exception {
        return m_Aux_Data_8;
    }

    public void setAux_Data_8(String value) throws Exception {
        m_Aux_Data_8 = value;
    }

    //   Attr Name:   BucklingConstant
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Buckling Constant
    //   Description:   Column buckling constant
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.####
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_BucklingConstant;
    public double getBucklingConstant() throws Exception {
        return m_BucklingConstant;
    }

    public void setBucklingConstant(double value) throws Exception {
        m_BucklingConstant = value;
    }

    //   Attr Name:   UseMomentCapacityTable
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Override Moment Cap
    //   Description:   Use the moment capacity table
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   BOOLEAN
    //   Default Value:   No
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private boolean m_UseMomentCapacityTable;
    public boolean getUseMomentCapacityTable() throws Exception {
        return m_UseMomentCapacityTable;
    }

    public void setUseMomentCapacityTable(boolean value) throws Exception {
        m_UseMomentCapacityTable = value;
    }

    //   Attr Name:   MomentCapacityTable
    //   Attr Group:Phys. Consts
    //   Alt Display Name:Moment Cap (ft-lb)
    //   Description:   The moment capacity table
    //   Displayed Units:   store as FTLBS display as FTLBS or NEWTONMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   MOMENT_TABLE
    //   Default Value:   Moment;0,50000;
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private ValTable m_MomentCapacityTable = new ValTable();
    public ValTable getMomentCapacityTable() throws Exception {
        return m_MomentCapacityTable;
    }

    public void setMomentCapacityTable(ValTable value) throws Exception {
        m_MomentCapacityTable = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


