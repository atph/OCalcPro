//
// Translated by CS2J (http://www.cs2j.com): 5/23/2016 8:21:42 AM
//

package PPL_Model_Wrapper;

import CS2JNet.System.LCC.Disposable;
import PPL_Model_Wrapper.ElementBase;
import PPL_Model_Wrapper.GenericEquipment;
import PPL_Model_Wrapper.LinkedURI;
import PPL_Model_Wrapper.Material;
import PPL_Model_Wrapper.Notes;
import PPL_Model_Wrapper.Span;
import PPL_Model_Wrapper.SpanBundle;

//--------------------------------------------------------------------------------------------
//   Class: Insulator
// Mirrors: PPLInsulator : PPLElement
//--------------------------------------------------------------------------------------------
public class Insulator  extends ElementBase 
{
    public static String gXMLkey = "Insulator";
    public String xMLkey() throws Exception {
        return gXMLkey;
    }

    public Insulator(boolean pInitialize) throws Exception {
        if (pInitialize)
        {
            m_Description = "Insulator";
            m_Owner = "<Undefined>";
            m_Type = Type_val.Pin;
            m_CoordinateZ = 300;
            m_CoordinateA = 0;
            m_Side = Side_val.Inline;
            m_CoordinateX = 0;
            m_LengthInInches = 8;
            m_DavitAngle = 1.18682389135614;
            m_Pitch = 0;
            m_Crab = 0;
            m_WidthInInches = 3;
            m_Weight = 8.99;
            m_Sheds = Sheds_val._Default_;
            m_WindDragCoef = 0;
            m_EndFitting = EndFitting_val.Clamped;
            m_StalkMaterial = "<Default>";
            m_WorkingDataStore = "";
        }
         
    }

    public boolean isLegalChild(ElementBase pChildCandidate) throws Exception {
        if (pChildCandidate instanceof Span)
            return true;
         
        if (pChildCandidate instanceof SpanBundle)
            return true;
         
        if (pChildCandidate instanceof GenericEquipment)
            return true;
         
        if (pChildCandidate instanceof Material)
            return true;
         
        if (pChildCandidate instanceof Notes)
            return true;
         
        if (pChildCandidate instanceof LinkedURI)
            return true;
         
        return false;
    }

    //   Attr Name:   Description
    //   Attr Group:Standard
    //   Description:   Description of the insulator.
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   Insulator
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_Description;
    public String getDescription() throws Exception {
        return m_Description;
    }

    public void setDescription(String value) throws Exception {
        m_Description = value;
    }

    //   Attr Name:   Owner
    //   Attr Group:Standard
    //   Description:   Owner
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   STRING
    //   Default Value:   <Undefined>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private String m_Owner;
    public String getOwner() throws Exception {
        return m_Owner;
    }

    public void setOwner(String value) throws Exception {
        m_Owner = value;
    }

    public enum Type_val
    {
        //   Attr Name:   Type
        //   Attr Group:Standard
        //   Description:   The span connector type.  This may be a style of insulator, j-hook, or other hardware used to attach spans to the pole.
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Pin
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Post  (Post)
        //        Davit  (Davit)
        //        Spool  (Spool)
        //        Underhung  (Underhung)
        //        Suspension  (Suspension)
        //        Deadend  (Deadend)
        //        J-Hook  (J-Hook)
        //        Bolt  (Bolt)
        //        Extension  (Extension)
        Pin,
        //Pin
        Post,
        //Post
        Davit,
        //Davit
        Spool,
        //Spool
        Underhung,
        //Underhung
        Suspension,
        //Suspension
        Deadend,
        //Deadend
        J_Hook,
        //J-Hook
        Bolt,
        //Bolt
        Extension
    }
    //Extension
    private Type_val m_Type = Type_val.Pin;
    public Type_val getType() throws Exception {
        return m_Type;
    }

    public void setType(Type_val value) throws Exception {
        m_Type = value;
    }

    public Type_val string_to_Type_val(String pKey) throws Exception {
        String __dummyScrutVar0 = pKey;
        if (__dummyScrutVar0.equals("Pin"))
        {
            return Type_val.Pin;
        }
        else //Pin
        if (__dummyScrutVar0.equals("Post"))
        {
            return Type_val.Post;
        }
        else //Post
        if (__dummyScrutVar0.equals("Davit"))
        {
            return Type_val.Davit;
        }
        else //Davit
        if (__dummyScrutVar0.equals("Spool"))
        {
            return Type_val.Spool;
        }
        else //Spool
        if (__dummyScrutVar0.equals("Underhung"))
        {
            return Type_val.Underhung;
        }
        else //Underhung
        if (__dummyScrutVar0.equals("Suspension"))
        {
            return Type_val.Suspension;
        }
        else //Suspension
        if (__dummyScrutVar0.equals("Deadend"))
        {
            return Type_val.Deadend;
        }
        else //Deadend
        if (__dummyScrutVar0.equals("J-Hook"))
        {
            return Type_val.J_Hook;
        }
        else //J-Hook
        if (__dummyScrutVar0.equals("Bolt"))
        {
            return Type_val.Bolt;
        }
        else //Bolt
        if (__dummyScrutVar0.equals("Extension"))
        {
            return Type_val.Extension;
        }
        else
        {
        }          
        throw new Exception("string does not match enum value");
    }

    //Extension
    public String type_val_to_String(Type_val pKey) throws Exception {
        switch(pKey)
        {
            case Pin: 
                return "Pin";
            case Post: 
                return "Post";
            case Davit: 
                return "Davit";
            case Spool: 
                return "Spool";
            case Underhung: 
                return "Underhung";
            case Suspension: 
                return "Suspension";
            case Deadend: 
                return "Deadend";
            case J_Hook: 
                return "J-Hook";
            case Bolt: 
                return "Bolt";
            case Extension: 
                return "Extension";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Pin
    //Post
    //Davit
    //Spool
    //Underhung
    //Suspension
    //Deadend
    //J-Hook
    //Bolt
    //Extension
    //   Attr Name:   CoordinateZ
    //   Attr Group:Standard
    //   Alt Display Name:Install Height (ft)
    //   Description:   The Z coordinate relative to the parent.  This value is frequently set by SnapToParent
    //   Displayed Units:   store as HEIGHT from BUTT in INCHES display as HEIGHT from GL in FEET or METERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERZ
    //   Default Value:   300.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateZ;
    public double getCoordinateZ() throws Exception {
        return m_CoordinateZ;
    }

    public void setCoordinateZ(double value) throws Exception {
        m_CoordinateZ = value;
    }

    //   Attr Name:   CoordinateA
    //   Attr Group:Standard
    //   Alt Display Name:Rotation (Â°)
    //   Description:   The rotation of the insulator / span holder relative to its parent.  If the orientation is non-zero the stalk with lean alone this axis
    //   Displayed Units:   store as RADIANS display as DEGREES
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateA;
    public double getCoordinateA() throws Exception {
        return m_CoordinateA;
    }

    public void setCoordinateA(double value) throws Exception {
        m_CoordinateA = value;
    }

    public enum Side_val
    {
        //   Attr Name:   Side
        //   Attr Group:Standard
        //   Description:   The span connector pole side (for insulators on a pole only).
        //   User Level Required:   All user levels may access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Inline
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   No
        //   Enum Values:
        //        Field  (Field)
        //        Inline  (Inline)
        //        Front  (Front)
        //        Back  (Back)
        //        Both  (Both)
        //        Split  (Split)
        Street,
        //Street
        Field,
        //Field
        Inline,
        //Inline
        Front,
        //Front
        Back,
        //Back
        Both,
        //Both
        Split
    }
    //Split
    private Side_val m_Side = Side_val.Street;
    public Side_val getSide() throws Exception {
        return m_Side;
    }

    public void setSide(Side_val value) throws Exception {
        m_Side = value;
    }

    public Side_val string_to_Side_val(String pKey) throws Exception {
        String __dummyScrutVar2 = pKey;
        if (__dummyScrutVar2.equals("Street"))
        {
            return Side_val.Street;
        }
        else //Street
        if (__dummyScrutVar2.equals("Field"))
        {
            return Side_val.Field;
        }
        else //Field
        if (__dummyScrutVar2.equals("Inline"))
        {
            return Side_val.Inline;
        }
        else //Inline
        if (__dummyScrutVar2.equals("Front"))
        {
            return Side_val.Front;
        }
        else //Front
        if (__dummyScrutVar2.equals("Back"))
        {
            return Side_val.Back;
        }
        else //Back
        if (__dummyScrutVar2.equals("Both"))
        {
            return Side_val.Both;
        }
        else //Both
        if (__dummyScrutVar2.equals("Split"))
        {
            return Side_val.Split;
        }
        else
        {
        }       
        throw new Exception("string does not match enum value");
    }

    //Split
    public String side_val_to_String(Side_val pKey) throws Exception {
        switch(pKey)
        {
            case Street: 
                return "Street";
            case Field: 
                return "Field";
            case Inline: 
                return "Inline";
            case Front: 
                return "Front";
            case Back: 
                return "Back";
            case Both: 
                return "Both";
            case Split: 
                return "Split";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Street
    //Field
    //Inline
    //Front
    //Back
    //Both
    //Split
    //   Attr Name:   CoordinateX
    //   Attr Group:Standard
    //   Alt Display Name:Horizontal Offset (in)
    //   Description:   Distance from the center of the parent.  In the case of a crossarm this is the position along the arm.  In the case of poles this is typically set by SnapToParent
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   0.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   No
    private double m_CoordinateX;
    public double getCoordinateX() throws Exception {
        return m_CoordinateX;
    }

    public void setCoordinateX(double value) throws Exception {
        m_CoordinateX = value;
    }

    //   Attr Name:   LengthInInches
    //   Attr Group:Properties
    //   Alt Display Name:Unit Length (in)
    //   Description:   The total length of the insulator structure
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   TRACKERX
    //   Default Value:   8.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_LengthInInches;
    public double getLengthInInches() throws Exception {
        return m_LengthInInches;
    }

    public void setLengthInInches(double value) throws Exception {
        m_LengthInInches = value;
    }

    //   Attr Name:   DavitAngle
    //   Attr Group:Standard
    //   Alt Display Name:Davit Angle (Â°)
    //   Description:   Davit angle in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   1.18682389135614
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_DavitAngle;
    public double getDavitAngle() throws Exception {
        return m_DavitAngle;
    }

    public void setDavitAngle(double value) throws Exception {
        m_DavitAngle = value;
    }

    //   Attr Name:   Pitch
    //   Attr Group:Properties
    //   Alt Display Name:Tilt (Â°)
    //   Description:   Pitch in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Pitch;
    public double getPitch() throws Exception {
        return m_Pitch;
    }

    public void setPitch(double value) throws Exception {
        m_Pitch = value;
    }

    //   Attr Name:   Crab
    //   Attr Group:Properties
    //   Alt Display Name:Crab Angle (Â°)
    //   Description:   Crab angle in radians.
    //   Displayed Units:   store as RADIANS display as DEGREES SIGNED
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.0
    //   Attribute Type:   TRACKERA
    //   Default Value:   0.0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Crab;
    public double getCrab() throws Exception {
        return m_Crab;
    }

    public void setCrab(double value) throws Exception {
        m_Crab = value;
    }

    //   Attr Name:   WidthInInches
    //   Attr Group:Properties
    //   Alt Display Name:Unit Width (in)
    //   Description:   The effective width for wind area of the insulator structure
    //   Displayed Units:   store as INCHES display as INCHES or CENTIMETERS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   3.00
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WidthInInches;
    public double getWidthInInches() throws Exception {
        return m_WidthInInches;
    }

    public void setWidthInInches(double value) throws Exception {
        m_WidthInInches = value;
    }

    //   Attr Name:   Weight
    //   Attr Group:Properties
    //   Alt Display Name:Unit Weight (lbs)
    //   Description:   Weight of the insulator / span holder in pounds
    //   Displayed Units:   store as POUNDS display as POUNDS or KILOGRAMS
    //   User Level Required:   All user levels may access this attribute
    //   Format Expression:   0.00
    //   Attribute Type:   FLOAT
    //   Default Value:   8.99
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_Weight;
    public double getWeight() throws Exception {
        return m_Weight;
    }

    public void setWeight(double value) throws Exception {
        m_Weight = value;
    }

    public enum Sheds_val
    {
        //   Attr Name:   Sheds
        //   Attr Group:Properties
        //   Alt Display Name:Shed Count
        //   Description:   Number of sheds
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   <Default>
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        1  (1)
        //        2  (2)
        //        3  (3)
        //        4  (4)
        //        5  (5)
        //        6  (6)
        //        7  (7)
        //        8  (8)
        _Default_,
        //<Default>
        Sheds_1,
        //1
        Sheds_2,
        //2
        Sheds_3,
        //3
        Sheds_4,
        //4
        Sheds_5,
        //5
        Sheds_6,
        //6
        Sheds_7,
        //7
        Sheds_8
    }
    //8
    private Sheds_val m_Sheds = Sheds_val._Default_;
    public Sheds_val getSheds() throws Exception {
        return m_Sheds;
    }

    public void setSheds(Sheds_val value) throws Exception {
        m_Sheds = value;
    }

    public Sheds_val string_to_Sheds_val(String pKey) throws Exception {
        String __dummyScrutVar4 = pKey;
        if (__dummyScrutVar4.equals("<Default>"))
        {
            return Sheds_val._Default_;
        }
        else //<Default>
        if (__dummyScrutVar4.equals("1"))
        {
            return Sheds_val.Sheds_1;
        }
        else //1
        if (__dummyScrutVar4.equals("2"))
        {
            return Sheds_val.Sheds_2;
        }
        else //2
        if (__dummyScrutVar4.equals("3"))
        {
            return Sheds_val.Sheds_3;
        }
        else //3
        if (__dummyScrutVar4.equals("4"))
        {
            return Sheds_val.Sheds_4;
        }
        else //4
        if (__dummyScrutVar4.equals("5"))
        {
            return Sheds_val.Sheds_5;
        }
        else //5
        if (__dummyScrutVar4.equals("6"))
        {
            return Sheds_val.Sheds_6;
        }
        else //6
        if (__dummyScrutVar4.equals("7"))
        {
            return Sheds_val.Sheds_7;
        }
        else //7
        if (__dummyScrutVar4.equals("8"))
        {
            return Sheds_val.Sheds_8;
        }
        else
        {
        }         
        throw new Exception("string does not match enum value");
    }

    //8
    public String sheds_val_to_String(Sheds_val pKey) throws Exception {
        switch(pKey)
        {
            case _Default_: 
                return "<Default>";
            case Sheds_1: 
                return "1";
            case Sheds_2: 
                return "2";
            case Sheds_3: 
                return "3";
            case Sheds_4: 
                return "4";
            case Sheds_5: 
                return "5";
            case Sheds_6: 
                return "6";
            case Sheds_7: 
                return "7";
            case Sheds_8: 
                return "8";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //<Default>
    //1
    //2
    //3
    //4
    //5
    //6
    //7
    //8
    //   Attr Name:   WindDragCoef
    //   Attr Group:Properties
    //   Alt Display Name:Wind Drag Coef.
    //   Description:   Wind Drag Coefficient
    //   User Level Required:   Limited users can NOT access this attribute
    //   Format Expression:   0.0###
    //   Attribute Type:   FLOAT
    //   Default Value:   0
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private double m_WindDragCoef;
    public double getWindDragCoef() throws Exception {
        return m_WindDragCoef;
    }

    public void setWindDragCoef(double value) throws Exception {
        m_WindDragCoef = value;
    }

    public enum EndFitting_val
    {
        //   Attr Name:   EndFitting
        //   Attr Group:Properties
        //   Alt Display Name:Line End Fitting
        //   Description:   Line End Fitting
        //   User Level Required:   Limited users can NOT access this attribute
        //   Attribute Type:   ENUMERATED
        //   Default Value:   Clamped
        //   ReadOnly Value:   No
        //   Visible in Data Entry Panel:   Yes
        //   Include When Substituting:   Yes
        //   Enum Values:
        //        Free  (Free)
        Clamped,
        //Clamped
        Free
    }
    //Free
    private EndFitting_val m_EndFitting = EndFitting_val.Clamped;
    public EndFitting_val getEndFitting() throws Exception {
        return m_EndFitting;
    }

    public void setEndFitting(EndFitting_val value) throws Exception {
        m_EndFitting = value;
    }

    public EndFitting_val string_to_EndFitting_val(String pKey) throws Exception {
        String __dummyScrutVar6 = pKey;
        if (__dummyScrutVar6.equals("Clamped"))
        {
            return EndFitting_val.Clamped;
        }
        else //Clamped
        if (__dummyScrutVar6.equals("Free"))
        {
            return EndFitting_val.Free;
        }
        else
        {
        }  
        throw new Exception("string does not match enum value");
    }

    //Free
    public String endFitting_val_to_String(EndFitting_val pKey) throws Exception {
        switch(pKey)
        {
            case Clamped: 
                return "Clamped";
            case Free: 
                return "Free";
            default: 
                break;
        
        }
        throw new Exception("enum value unexpected");
    }

    //Clamped
    //Free
    //   Attr Name:   StalkMaterial
    //   Attr Group:Material
    //   Alt Display Name:Stalk Material
    //   Description:   Stalk Material
    //   User Level Required:   All user levels may access this attribute
    //   Attribute Type:   CHILD_MATERIAL_NAME
    //   Default Value:   <Default>
    //   ReadOnly Value:   No
    //   Visible in Data Entry Panel:   Yes
    //   Include When Substituting:   Yes
    private String m_StalkMaterial;
    public String getStalkMaterial() throws Exception {
        return m_StalkMaterial;
    }

    public void setStalkMaterial(String value) throws Exception {
        m_StalkMaterial = value;
    }

    //   Attr Name:   WorkingDataStore
    //   Attr Group:Standard
    //   Description:   Working Data
    //   User Level Required:   Administrative access only
    //   Attribute Type:   STRING
    //   Default Value:
    //   ReadOnly Value:   Yes
    //   Visible in Data Entry Panel:   No
    //   Include When Substituting:   No
    private String m_WorkingDataStore;
    public String getWorkingDataStore() throws Exception {
        return m_WorkingDataStore;
    }

    public void setWorkingDataStore(String value) throws Exception {
        m_WorkingDataStore = value;
    }

}


